import discord
from discord.ext import commands
from discord import app_commands
from utils.menu_ui import HomeView, open_home, open_category, server_allowed

# Name bleibt fuer bestehende Imports erhalten.
HubView = HomeView


class LegacyMenuView(discord.ui.View):
    """Schon gepostete Hauptbuttons oeffnen ebenfalls die reparierten Bereiche."""
    def __init__(self):
        super().__init__(timeout=None)
        for prefix in ('menu_', 'ushero_'):
            for area in ('verkauf', 'warehouse', 'vip', 'taenzer', 'security'):
                button=discord.ui.Button(label=area,custom_id=prefix+area)
                async def open_area(interaction,area=area): await open_category(interaction,area)
                button.callback=open_area
                self.add_item(button)
        for name in ('ushero_panel','menu_summen','panel_help','panel_arbeit'):
            button=discord.ui.Button(label='Hauptmenü',custom_id=name)
            button.callback=open_home
            self.add_item(button)

    async def interaction_check(self,interaction):
        return server_allowed(interaction.client,interaction.guild)

    async def on_error(self,interaction,error,item):
        from utils.menu_ui import show_error
        await show_error(interaction,error)


class MenuCog(commands.Cog):
    def __init__(self,bot):
        self.bot=bot

    async def cog_load(self):
        self.bot.add_view(HomeView())
        self.bot.add_view(LegacyMenuView())

    @app_commands.command(name='menu',description='USHERO-Hauptmenü öffnen')
    async def menu(self,interaction: discord.Interaction):
        await open_home(interaction)


async def setup(bot):
    await bot.add_cog(MenuCog(bot))
