// USHERO Sheets V2 · Dunkles Neon-Design und wiederholbarer Datenabgleich
const SCHEMA = [{"key": "sales", "name": "Verkäufe", "headers": ["ID", "Mitarbeiter-ID", "Artikel", "Menge", "Einzelpreis", "Gesamt", "Käufer-ID", "Bereich", "Zeit (UTC)", "Abrechnung-ID"], "text": [1, 2, 3, 7, 8, 9, 10], "money": [5, 6], "color": "#00D9E8"}, {"key": "vip", "name": "VIP", "headers": ["ID", "Mitarbeiter-ID", "Gast-ID", "Betrag", "Beschreibung", "Zeit (UTC)"], "text": [1, 2, 3, 5, 6], "money": [4], "color": "#F4C95D"}, {"key": "dance", "name": "Tanz-Sessions", "headers": ["ID", "Tänzer-ID", "Gast-ID", "Minuten", "Preis", "Start (UTC)", "Ende (UTC)", "Status"], "text": [1, 2, 3, 6, 7, 8], "money": [5], "color": "#EB459E"}, {"key": "security", "name": "Security", "headers": ["ID", "Mitarbeiter-ID", "Start (UTC)", "Ende (UTC)", "Lohn", "Status", "Notiz"], "text": [1, 2, 3, 4, 6, 7], "money": [5], "color": "#68A7FF"}, {"key": "duty", "name": "Dienstzeiten", "headers": ["ID", "Mitarbeiter-ID", "Start (UTC)", "Ende (UTC)", "Minuten", "Status"], "text": [1, 2, 3, 4, 6], "money": [], "color": "#57F287"}, {"key": "plan", "name": "Dienstplan", "headers": ["ID", "Mitarbeiter-ID", "Datum", "Bereich", "Von", "Bis", "Notiz"], "text": [1, 2, 3, 4, 5, 6, 7], "money": [], "color": "#B794F6"}, {"key": "settlements", "name": "Abrechnungen", "headers": ["ID", "Mitarbeiter-ID", "Brutto", "Firma (%)", "Firma", "Mitarbeiter", "Details", "Zeit (UTC)"], "text": [1, 2, 7, 8], "money": [3, 5, 6], "color": "#F29D58"}, {"key": "cash", "name": "Firmenkasse", "headers": ["ID", "Saldo", "Aktualisiert (UTC)"], "text": [1, 3], "money": [2], "color": "#E4B95B"}, {"key": "stock", "name": "Lagerbestand", "headers": ["Artikel", "Bestand", "Aktualisiert (UTC)"], "text": [1, 3], "money": [], "color": "#00C5B9"}, {"key": "orders", "name": "Bestellungen", "headers": ["ID", "Artikel", "Menge", "Gesamt", "Einzelpreis", "Status", "Mitarbeiter-ID", "Bestellt (UTC)", "Eingang (UTC)", "Notiz"], "text": [1, 2, 6, 7, 8, 9, 10], "money": [4, 5], "color": "#8E8CFF"}, {"key": "team", "name": "Team", "headers": ["Mitarbeiter-ID", "Name", "Rollen"], "text": [1, 2, 3], "money": [], "color": "#F7A5D0"}];
const THEME = {"bg": "#11131F", "body": "#1B1F33", "alternate": "#242A43", "text": "#E9ECF5", "muted": "#A8B0C7", "pink": "#EB459E", "cyan": "#00D9E8", "green": "#57F287", "amber": "#F4C95D", "red": "#FF6B7D"};
// Einmal USHERO_einrichten ausfuehren. Zugangsschluessel nur in Script Properties speichern.
function onOpen() {
  SpreadsheetApp.getUi().createMenu('✦ USHERO')
    .addItem('Dashboard & Farben einrichten', 'USHERO_einrichten')
    .addItem('Verbindungsschlüssel einrichten', 'USHERO_verbindung')
    .addItem('Andere Bot-Datenquelle erlauben (mit Archiv)', 'USHERO_neueDatenquelle')
    .addToUi();
}

function USHERO_einrichten() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Dieses Script in Erweiterungen → Apps Script deiner Google-Tabelle einfügen.');
  PropertiesService.getScriptProperties().setProperty('USHERO_SHEET_ID', ss.getId());
  PropertiesService.getScriptProperties().deleteProperty('USHERO_REVISION');
  SCHEMA.forEach(spec => styleTable(ensureTable(ss, spec), spec));
  dashboard(ss);
  SpreadsheetApp.flush();
  ss.setActiveSheet(ss.getSheetByName('Dashboard'));
}

function USHERO_verbindung() {
  const ui = SpreadsheetApp.getUi();
  const result = ui.prompt('USHERO-Verbindung', 'Eigenen langen Schlüssel eingeben oder leer lassen für einen neuen. Nicht in Tabellenzellen eintragen.', ui.ButtonSet.OK_CANCEL);
  if (result.getSelectedButton() !== ui.Button.OK) return;
  const key = result.getResponseText().trim() || Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
  if (!/^[A-Za-z0-9_.-]{24,200}$/.test(key)) throw new Error('Bitte 24 bis 200 Buchstaben/Ziffern verwenden oder leer für einen automatisch erzeugten Schlüssel.');
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  PropertiesService.getScriptProperties().setProperties({USHERO_SHARED_KEY: key, USHERO_SHEET_ID: ss.getId()});
  ui.alert('Schlüssel nur lokal als SHEETS_SHARED_KEY speichern.\n\n' + key + '\n\nDanach Web-App bereitstellen und deren /exec-URL als SHEETS_URL verwenden.');
}

function USHERO_neueDatenquelle() {
  const ui = SpreadsheetApp.getUi();
  if (ui.alert('Datenquelle wechseln?', 'Die bisherigen verwalteten Datentabellen werden vor dem nächsten Abgleich archiviert. Lokale Bot-Daten werden nicht gelöscht.', ui.ButtonSet.YES_NO) !== ui.Button.YES) return;
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try {
    const ss = target();
    SCHEMA.forEach(spec => { const old = ss.getSheetByName(spec.name); if (old && old.getLastRow() > 1) archive(ss, old); });
    const props = PropertiesService.getScriptProperties();
    props.deleteProperty('USHERO_SOURCE'); props.deleteProperty('USHERO_REVISION'); props.deleteProperty('USHERO_LAST_SYNC');
    SCHEMA.forEach(spec => styleTable(ensureTable(ss, spec), spec));
    updateTime(ss);
  } finally { lock.releaseLock(); }
}

function target() {
  const id = PropertiesService.getScriptProperties().getProperty('USHERO_SHEET_ID');
  if (!id) throw new Error('Zuerst USHERO_einrichten in der gebundenen Tabelle ausführen.');
  return SpreadsheetApp.openById(id);
}

function authorized(key) {
  const expected = PropertiesService.getScriptProperties().getProperty('USHERO_SHARED_KEY');
  return !!expected && expected.length >= 24 && typeof key === 'string' && key === expected;
}
function response(value) { return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON); }
function denied() { return response({ok: false, error: 'Verbindungsschlüssel ungültig oder nicht eingerichtet.'}); }
function doGet(e) {
  if (!authorized((e && e.parameter || {}).shared_key)) return denied();
  return response({ok: true, version: 2, revision: PropertiesService.getScriptProperties().getProperty('USHERO_REVISION') || ''});
}

function validateSnapshot(data) {
  if (data.type !== 'snapshot' || data.version !== 2) throw new Error('Bot und Apps Script auf Version 2 aktualisieren.');
  if (typeof data.source !== 'string' || !/^[a-zA-Z0-9-]{24,64}$/.test(data.source)) throw new Error('Datenquellen-ID ungültig.');
  if (typeof data.revision !== 'string' || !/^[a-f0-9]{64}$/.test(data.revision)) throw new Error('Datenstand ungültig.');
  if (!data.tables || Object.keys(data.tables).sort().join('|') !== SCHEMA.map(s => s.key).sort().join('|')) throw new Error('Unvollständiger Datenstand; keine Tabellen geändert.');
  SCHEMA.forEach(spec => {
    const table = data.tables[spec.key];
    if (!table || JSON.stringify(table.columns) !== JSON.stringify(spec.headers) || !Array.isArray(table.rows) || table.rows.length > 10000) throw new Error('Ungültige Tabelle: ' + spec.name);
    table.rows.forEach(row => {
      if (!Array.isArray(row) || row.length !== spec.headers.length) throw new Error('Falsche Spaltenzahl: ' + spec.name);
      row.forEach(value => {
        if (typeof value === 'number') { if (!Number.isFinite(value)) throw new Error('Ungültige Zahl.'); }
        else if (typeof value !== 'string' || value.length > 2000) throw new Error('Ungültiger Zellinhalt.');
      });
    });
  });
}
function safeCell(value) { return typeof value === 'string' && /^[\s]*[=+@-]/.test(value) ? "'" + value : value; }

function doPost(e) {
  let data;
  try {
    const raw = e && e.postData && e.postData.contents;
    if (!raw || raw.length > 8 * 1024 * 1024) return response({ok: false, error: 'Anfrage leer oder zu groß.'});
    data = JSON.parse(raw);
  } catch (_) { return response({ok: false, error: 'Ungültiges JSON.'}); }
  if (!authorized(data.shared_key)) return denied();
  try { validateSnapshot(data); } catch (error) { return response({ok: false, error: error.message}); }
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) return response({ok: false, error: 'Ein Abgleich läuft bereits. Später erneut versuchen.'});
  try {
    const props = PropertiesService.getScriptProperties();
    const bound = props.getProperty('USHERO_SOURCE');
    if (bound && bound !== data.source) return response({ok: false, error: 'Andere Bot-Datenquelle erkannt. Bisherige Daten bleiben erhalten; Wechsel im USHERO-Menü der Tabelle freigeben.'});
    const ss = target();
    if (!data.force && props.getProperty('USHERO_REVISION') === data.revision) {
      props.setProperty('USHERO_LAST_SYNC',new Date().toISOString());
      updateTime(ss); return response({ok: true, unchanged: true, revision: data.revision});
    }
    SCHEMA.forEach(spec => {
      const sheet = ensureTable(ss, spec);
      const rows = data.tables[spec.key].rows.map(row => row.map(safeCell));
      if (sheet.getMaxRows() < rows.length + 1) sheet.insertRowsAfter(sheet.getMaxRows(), rows.length + 1 - sheet.getMaxRows());
      const previous = sheet.getLastRow();
      if (previous > 1) sheet.getRange(2, 1, previous - 1, spec.headers.length).clearContent();
      spec.text.forEach(col => sheet.getRange(2, col, Math.max(1, rows.length), 1).setNumberFormat('@'));
      if (rows.length) sheet.getRange(2, 1, rows.length, spec.headers.length).setValues(rows);
      // Neue, über den Vorlagenbereich hinausgehende Zeilen ebenfalls gestalten.
      if (rows.length > 299) styleTable(sheet, spec);
    });
    SpreadsheetApp.flush();
    props.setProperties({USHERO_SOURCE: data.source, USHERO_REVISION: data.revision, USHERO_LAST_SYNC:new Date().toISOString()});
    updateTime(ss);
    return response({ok: true, revision: data.revision, rows: SCHEMA.reduce((n, spec) => n + data.tables[spec.key].rows.length, 0)});
  } catch (_) { return response({ok: false, error: 'Abgleich nicht vollständig bestätigt. Datenstand wird beim nächsten Versuch erneut übertragen; lokale Buchungen bleiben erhalten.'}); }
  finally { lock.releaseLock(); }
}

function archive(ss, sheet) {
  const stamp = Utilities.formatDate(new Date(), 'UTC', 'yyyyMMdd-HHmmss');
  const base = ('Archiv ' + sheet.getName()).slice(0, 65) + ' ' + stamp;
  let name = base, counter = 2;
  while (ss.getSheetByName(name)) name = base + '-' + counter++;
  sheet.setName(name); sheet.setTabColor(THEME.muted);
}
function ensureTable(ss, spec) {
  let sheet = ss.getSheetByName(spec.name);
  if (sheet && sheet.getLastRow() > 0) {
    const current = sheet.getRange(1, 1, 1, spec.headers.length).getValues()[0];
    if (JSON.stringify(current) !== JSON.stringify(spec.headers)) { archive(ss, sheet); sheet = null; }
  }
  if (!sheet) {
    sheet = ss.insertSheet(spec.name);
    sheet.getRange(1, 1, 1, spec.headers.length).setValues([spec.headers]);
    styleTable(sheet, spec);
  }
  return sheet;
}

function styleTable(sheet, spec) {
  if(sheet.getMaxRows()<2) sheet.insertRowsAfter(1,1);
  const count = sheet.getMaxRows(), width = sheet.getMaxColumns();
  sheet.getRange(1, 1, count, width).setBackground(THEME.bg).setFontColor(THEME.text).setFontFamily('Arial').setFontSize(10);
  sheet.setHiddenGridlines(true).setFrozenRows(1).setFrozenColumns(1).setTabColor(spec.color);
  sheet.setRowHeight(1, 38);
  sheet.getRange(1, 1, 1, spec.headers.length).setBackground(spec.color).setFontColor(THEME.bg).setFontWeight('bold').setWrap(true);
  const bodyRows = Math.max(1, count - 1);
  sheet.getBandings().forEach(b => b.remove());
  sheet.getRange(1, 1, count, spec.headers.length).applyRowBanding(SpreadsheetApp.BandingTheme.LIGHT_GREY)
    .setHeaderRowColor(spec.color).setFirstRowColor(THEME.body).setSecondRowColor(THEME.alternate);
  sheet.getRange(2, 1, bodyRows, spec.headers.length).setVerticalAlignment('middle');
  spec.headers.forEach((header, i) => sheet.setColumnWidth(i + 1, /Notiz|Details|Beschreibung|Artikel|Rollen/.test(header) ? 280 : 170));
  spec.text.forEach(col => sheet.getRange(2, col, bodyRows, 1).setNumberFormat('@'));
  spec.money.forEach(col => sheet.getRange(2, col, bodyRows, 1).setNumberFormat('#,##0.00" $"'));
  if (sheet.getFilter()) sheet.getFilter().remove();
  sheet.getRange(1, 1, count, spec.headers.length).createFilter();
  const rules = [];
  if (spec.key === 'stock') {
    const range = sheet.getRange(2, 2, bodyRows, 1);
    rules.push(SpreadsheetApp.newConditionalFormatRule().whenNumberLessThanOrEqualTo(0).setBackground('#6B2434').setFontColor('#FFD5DC').setRanges([range]).build());
    rules.push(SpreadsheetApp.newConditionalFormatRule().whenNumberBetween(1, 10).setBackground('#654D23').setFontColor('#FFEAB3').setRanges([range]).build());
    rules.push(SpreadsheetApp.newConditionalFormatRule().whenNumberGreaterThan(10).setBackground('#174C3C').setFontColor('#B6FFE0').setRanges([range]).build());
  }
  const statusIndex = spec.headers.indexOf('Status');
  if (statusIndex >= 0) {
    const range = sheet.getRange(2, statusIndex + 1, bodyRows, 1);
    [['aktiv','#174C3C'],['active','#174C3C'],['beendet','#173E61'],['finished','#173E61'],['erledigt','#174C3C'],['offen','#654D23'],['auto_logout','#6B2434']].forEach(([status, color]) =>
      rules.push(SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo(status).setBackground(color).setFontColor(THEME.text).setRanges([range]).build()));
  }
  sheet.setConditionalFormatRules(rules);
}

function dashboard(ss) {
  let sheet = ss.getSheetByName('Dashboard');
  if (sheet && sheet.getLastRow() && sheet.getRange('A1').getValue() !== 'USHERO · CONTROL ROOM') { archive(ss, sheet); sheet = null; }
  if (!sheet) sheet = ss.insertSheet('Dashboard', 0);
  sheet.getRange(1, 1, sheet.getMaxRows(), sheet.getMaxColumns()).setBackground(THEME.bg).setFontColor(THEME.text).setFontFamily('Arial');
  sheet.setHiddenGridlines(true).setTabColor(THEME.pink); sheet.setFrozenRows(4);
  sheet.getRange('A1:L36').breakApart().clearContent();
  sheet.setColumnWidths(1, 12, 95); sheet.setRowHeights(1, 36, 26);
  sheet.getRange('A1:L2').merge().setValue('USHERO · CONTROL ROOM').setBackground(THEME.pink).setFontColor(THEME.bg).setFontSize(24).setFontWeight('bold');
  sheet.getRange('A3:L3').merge().setValue('Nightclub • Verkauf • Team • Lager • Abrechnung').setFontColor(THEME.muted);
  const cards = [
    ['A5:D5','A6:D8','GESAMTUMSATZ',"=SUM('Verkäufe'!F2:F)+SUM('VIP'!D2:D)",THEME.cyan],
    ['E5:H5','E6:H8','FIRMENKASSE',"=SUM('Firmenkasse'!B2:B)",THEME.pink],
    ['I5:L5','I6:L8','MITARBEITER-ANTEILE',"=SUM('Abrechnungen'!F2:F)",THEME.green],
    ['A10:D10','A11:D13','OFFENE BESTELLUNGEN', '=COUNTIF(Bestellungen!F2:F,"offen")',THEME.amber],
    ['E10:H10','E11:H13','AKTIVE DIENSTE','=COUNTIF(Dienstzeiten!F2:F,"aktiv")',THEME.cyan],
    ['I10:L10','I11:L13','NIEDRIGER LAGERBESTAND','=COUNTIFS(Lagerbestand!A2:A,"<>",Lagerbestand!B2:B,"<=10")',THEME.pink]
  ];
  cards.forEach(([label, value, title, formula, color], index) => {
    sheet.getRange(label).merge().setValue(title).setFontColor(color).setFontWeight('bold').setBackground(THEME.body);
    const range = sheet.getRange(value).merge().setFormula(formula).setFontColor(color).setFontSize(27).setFontWeight('bold').setBackground(THEME.body);
    range.setNumberFormat(index < 3 ? '#,##0.00" $"' : '0');
  });
  sheet.getRange('A16:B20').setValues([['BEREICH','UMSATZ'],['Verkauf',''],['Tänzer',''],['Warehouse',''],['VIP','']]);
  ['verkauf','taenzer','warehouse'].forEach((name, index) => sheet.getRange(17 + index, 2).setFormula('=SUMIF(\'Verkäufe\'!H2:H,"' + name + '",\'Verkäufe\'!F2:F)'));
  sheet.getRange('B20').setFormula("=SUM('VIP'!D2:D)");
  sheet.getRange('A16:B16').setBackground(THEME.cyan).setFontColor(THEME.bg).setFontWeight('bold');
  sheet.getRange('B17:B20').setNumberFormat('#,##0.00" $"');
  sheet.getCharts().forEach(chart => sheet.removeChart(chart));
  sheet.insertChart(sheet.newChart().setChartType(Charts.ChartType.COLUMN).addRange(sheet.getRange('A16:B20')).setPosition(16,4,0,0)
    .setOption('title','Umsatz nach Bereich').setOption('backgroundColor',THEME.body).setOption('titleTextStyle',{color:THEME.text})
    .setOption('hAxis',{textStyle:{color:THEME.text}}).setOption('vAxis',{textStyle:{color:THEME.text}}).setOption('legend',{position:'none'}).setOption('colors',[THEME.pink]).build());
  sheet.getRange('A30:L31').merge().setValue('Datenbank → Sheets. Tabellen sind ein Spiegel; Buchungen im Bot vornehmen. Eigene Notizen bitte auf einem separaten Blatt.').setWrap(true).setFontColor(THEME.muted);
  sheet.getRange('A33:L34').merge().setValue('Verkäufe enthält Tanzumsätze bereits. Sie werden im Gesamtumsatz nicht doppelt addiert.').setWrap(true).setFontColor(THEME.muted);
  sheet.getRange('A4:L4').merge();
  updateTime(ss);
}
function updateTime(ss) {
  const sheet = ss.getSheetByName('Dashboard');
  const props=PropertiesService.getScriptProperties();
  const last=props.getProperty('USHERO_REVISION') && props.getProperty('USHERO_LAST_SYNC');
  if (sheet) sheet.getRange('A4').setValue(last ? 'Letzter bestätigter Abgleich (UTC): '+last : 'Noch kein Bot-Abgleich bestätigt · Verbindung einmal einrichten').setFontColor(THEME.muted);
}
