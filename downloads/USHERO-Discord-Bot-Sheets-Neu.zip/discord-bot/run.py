"""Sichtbarer Windows-/Linux-Starter, ohne PowerShell oder Schutz-Ausnahmen."""
from pathlib import Path
import getpass
import hashlib
import os
import re
import subprocess
import sys
import venv

ROOT=Path(__file__).resolve().parent


def save_env_values(path,values):
    text=path.read_text(encoding='utf-8-sig') if path.exists() else ''
    lines=text.splitlines()
    for key,value in values.items():
        if not re.fullmatch(r'[A-Z_]+',key) or '\n' in value or '\r' in value:raise ValueError('Ungültige Einstellung.')
        lines=[line for line in lines if not re.match(r'^\s*(?:export\s+)?'+re.escape(key)+r'\s*=',line)]
        lines.append(key+'='+value)
    path.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    try:path.chmod(0o600)
    except OSError:pass


def configure_sheets():
    print('Zuerst sheets/Code.gs in deiner Google-Tabelle einrichten und als Web-App bereitstellen.')
    url=input('Web-App-URL (https://script.google.com/macros/s/.../exec): ').strip()
    if not re.fullmatch(r'https://script\.google\.com/macros/s/[A-Za-z0-9_-]+/exec',url):
        raise SystemExit('Bitte die offizielle /exec-URL deiner Apps-Script-Web-App verwenden. Nichts gespeichert.')
    key=getpass.getpass('Generierter USHERO-Verbindungsschluessel (verborgen): ').strip()
    if not re.fullmatch(r'[A-Za-z0-9_.-]{24,200}',key):
        raise SystemExit('Bitte den in Sheets generierten Verbindungsschluessel verwenden. Nichts gespeichert.')
    save_env_values(ROOT/'.env',{'SHEETS_URL':url,'SHEETS_SHARED_KEY':key,'ENABLE_SHEETS':'true'})
    print('Sheets-Verbindung lokal gespeichert. Bot neu starten und Leitung → Sheets-Status oeffnen.')
    return 0


def main():
    if not (3,11)<=sys.version_info[:2]<(3,15):
        raise SystemExit('Bitte Python 3.11 bis 3.14 verwenden. Geprueft wurde Python 3.12.')
    if '--sheets-setup' in sys.argv:return configure_sheets()
    env=ROOT/'.venv'
    python=env/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if not python.exists():
        print('Erstelle lokale Python-Umgebung .venv ...',flush=True)
        venv.EnvBuilder(with_pip=True).create(env)
    requirements=ROOT/'requirements.txt'
    expected=hashlib.sha256(requirements.read_bytes()).hexdigest()
    stamp=env/'.ushero-requirements'
    if not stamp.exists() or stamp.read_text()!=expected:
        print('Die festgelegten Python-Pakete muessen in .venv installiert werden. Dies braucht Internet.')
        if input('Pakete jetzt installieren? [j/N] ').strip().lower() not in ('j','ja','y','yes'):
            raise SystemExit('Installation abgebrochen.')
        subprocess.run([str(python),'-m','pip','install','-r',str(requirements)],cwd=ROOT,check=True)
        stamp.write_text(expected)
    if '--test' in sys.argv:
        return subprocess.call([str(python),'-m','unittest','discover','-s','tests','-v'],cwd=ROOT)
    file=ROOT/'.env'
    contents=file.read_text(encoding='utf-8-sig') if file.exists() else (ROOT/'.env.example').read_text()
    found=re.search(r'^\s*(?:export\s+)?DISCORD_TOKEN\s*=\s*([^\r\n]*)',contents,re.M)
    current=found.group(1).strip().strip('"\'') if found else ''
    if not current or current=='HIER_DEIN_BOT_TOKEN':
        token=getpass.getpass('Discord-Bot-Token (Eingabe bleibt verborgen): ').strip()
        if not re.fullmatch(r'[A-Za-z0-9_.-]{30,250}',token):
            raise SystemExit('Kein gueltiges Tokenformat. Es wurde nichts gespeichert.')
        if found: contents=contents[:found.start()]+f'DISCORD_TOKEN={token}'+contents[found.end():]
        else: contents+='\nDISCORD_TOKEN='+token+'\n'
        file.write_text(contents,encoding='utf-8')
        try: file.chmod(0o600)
        except OSError: pass
    print('Bot startet. Fenster offen lassen; Strg+C beendet den Bot. Kein automatischer Neustart.',flush=True)
    try:
        return subprocess.call([str(python),str(ROOT/'bot.py')],cwd=ROOT)
    except KeyboardInterrupt:
        return 0


if __name__=='__main__':
    raise SystemExit(main())
