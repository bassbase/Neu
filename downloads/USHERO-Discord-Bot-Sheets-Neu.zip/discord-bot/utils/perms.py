"""Rollen-Rechte: Gäste / Mitarbeiter / Leitung / Owner."""
import json
import discord

from utils.config import CONFIG

# Bereiche → erlaubte Rollen
AREA_ROLES = {
    "verkauf": {"Verkauf", "Mitarbeiter", "Schichtleitung", "Leitung", "Admin", "Buchhaltung"},
    "warehouse": {"Warehouse", "Mitarbeiter", "Schichtleitung", "Leitung", "Admin", "Buchhaltung"},
    "vip": {"VIP", "Mitarbeiter", "Schichtleitung", "Leitung", "Admin"},
    "taenzer": {"Tänzer/in", "Mitarbeiter", "Schichtleitung", "Leitung", "Admin"},
    "security": {"Security", "Mitarbeiter", "Schichtleitung", "Leitung", "Admin"},
    "buchhaltung": {"Buchhaltung", "Leitung", "Admin"},
    "lohn": {"Buchhaltung", "Leitung", "Admin", "Schichtleitung"},
    "ki": set(),  # nur Owner
    "stats": {"Mitarbeiter", "Verkauf", "Warehouse", "Tänzer/in", "Security",
              "Schichtleitung", "Leitung", "Admin", "Buchhaltung"},
}

STAFF_ROLES = set()
for s in AREA_ROLES.values():
    STAFF_ROLES |= s
STAFF_ROLES |= {"Mitarbeiter", "Schichtleitung", "Leitung", "Admin", "Buchhaltung", "Geschäftsführung", "Manager", "Aushilfe"}

LEITUNG_ROLES = {"Leitung", "Admin", "Schichtleitung", "Buchhaltung", "Geschäftsführung", "Manager"}


def is_owner(member: discord.Member) -> bool:
    return bool(member and getattr(member, 'guild', None)) and member.id == member.guild.owner_id


def is_admin(member: discord.Member) -> bool:
    return bool(member and getattr(member, 'guild', None)) and (member.guild_permissions.administrator or is_owner(member))


def role_names(member: discord.Member) -> set:
    return {r.name for r in getattr(member, 'roles', [])}


def is_staff(member: discord.Member) -> bool:
    if is_admin(member):
        return True
    return bool(role_names(member) & STAFF_ROLES)


def is_leitung(member: discord.Member) -> bool:
    if is_admin(member):
        return True
    return bool(role_names(member) & LEITUNG_ROLES)


def can_use_area(member: discord.Member, area: str) -> bool:
    if area == "ki":
        return is_owner(member)
    if is_admin(member):
        return True
    if role_names(member) & {"Leitung", "Admin", "Schichtleitung", "Geschäftsführung", "Manager"}:
        return True
    allowed = AREA_ROLES.get(area, set())
    return bool(role_names(member) & allowed)


def primary_areas(member: discord.Member) -> list:
    """Welche Arbeitsbereiche dieser MA öffnen darf (Reihenfolge)."""
    order = ["verkauf", "warehouse", "vip", "taenzer", "security", "buchhaltung", "lohn"]
    return [a for a in order if can_use_area(member, a)]


def deny_guest_message() -> str:
    return "🚫 **Nur für Mitarbeiter.** Gäste können diesen Bereich nicht nutzen."
