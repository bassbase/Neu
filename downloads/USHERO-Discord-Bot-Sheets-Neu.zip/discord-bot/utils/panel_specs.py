"""Feste Zuordnung von Arbeitskanal, Bereich und passenden Direktaktionen."""
from dataclasses import dataclass
import unicodedata
import re


@dataclass(frozen=True)
class PanelSpec:
    key: str
    area: str
    channel: str
    aliases: tuple
    actions: tuple
    clean: bool = True


SPECS = {
    'home': PanelSpec('home','home','hauptmenue',('hauptmenü','hauptmenu','bot-menu','bot-menue','menue','menu'),(),False),
    'verkauf': PanelSpec('verkauf','verkauf','verkauf',('verkauf-kasse',),(
        ('verkauf','Warenkorb öffnen','💰'),('preisliste','Preisliste','📋'),('meine-verkaeufe','Meine Verkäufe','🧾'),('verkauf-summe','Verkaufssumme','📊'))),
    'warehouse': PanelSpec('warehouse','warehouse','warehouse-bestellungen',('warehouse','lager-bestellungen'),(
        ('warehouse bestellen','Bestellen','📦'),('warehouse offen','Offene Bestellungen','📋'),('warehouse eingang','Lieferung eingegangen','✅'),('warehouse historie','Historie','🧾'))),
    'lager': PanelSpec('lager','warehouse','warehouse-lager',('lagerbestand','lager'),(
        ('warehouse lager','Lagerbestand','📦'),('warehouse korrigieren','Bestand korrigieren','📝'))),
    'vip': PanelSpec('vip','vip','vip',('vip-service',),(
        ('vip add','VIP-Service buchen','⭐'),('vip-karte','VIP-Karte','🎫'),('vip summe','VIP-Summe','💵'),('vip-ablauf','Ablaufübersicht','📅'))),
    'taenzer': PanelSpec('taenzer','taenzer','taenzer',('tänzer','taenzerinnen','tänzerinnen','entertainment'),(
        ('taenzer starten','Session starten','💃'),('taenzer aktiv','Aktive Sessions','⏱️'),('taenzer beenden','Session beenden','🏁'))),
    'security': PanelSpec('security','security','security',('sicherheit',),(
        ('security dienst-start','Security-Dienst starten','🟢'),('security dienst-ende','Security-Dienst beenden','🔴'),('security aktiv','Wer ist im Dienst?','👥'),('security summe','Mein Lohnprotokoll','💵'))),
    'dienst': PanelSpec('dienst','dienst','stempeluhr',('dienst','dienst-lohn','arbeitsplatz','mein-lohn'),(
        ('@start','Dienst starten','🟢'),('@end','Dienst beenden','🔴'),('mein-panel','Verdienst & Abrechnen','💵'),('meine-abrechnungen','Meine Abrechnungen','🧾'),('rang','Mein Rang','🎖️'))),
    'dienstplan': PanelSpec('dienstplan','dienstplan','dienstplan',('schichtplan',),(
        ('dienstplan heute','Heute','📅'),('dienstplan eintragen','Schicht eintragen','📝'),('dienstplan zeigen','Datum auswählen','🗓️'),('dienstplan meine','Meine Schichten','👤'),('dienstplan loeschen','Eintrag löschen','🗑️'))),
    'buchhaltung': PanelSpec('buchhaltung','buchhaltung','buchhaltung',('finanzen',),(
        ('firmenkasse','Firmenkasse','🏦'),('abrechnungen','Abrechnungen','📒'),('firma-prozent','Firmenanteil einstellen','⚙️'))),
    'leitung': PanelSpec('leitung','leitung','bot-verwaltung',('leitung','verwaltung','admin-panel'),(
        ('menues-einrichten','Alle Kanalmenüs einrichten','🗂️'),('menues-status','Kanalmenüs prüfen','🔎'),('daily-report','Tagesbericht','📊'),('diagnose check','Diagnose','🩺'),('sheets-status','Sheets-Status','📊'),('sheets-sync','Sheets abgleichen','🔄'))),
    'ki': PanelSpec('ki','ki','ki-panel',('ki','ki-menue'),(
        ('ki status','KI-Status','🧠'),('ki tagesauswertung','Tagesauswertung','📊'),('ki marketing','Marketing','📝'),('ki concierge','Gäste-Antwort','💬'))),
    'info': PanelSpec('info','info','bot-info',('ushero-info',),(
        ('wer-darf-was','Rollenübersicht','👥'),('bewerbung stellen','Bewerbung einreichen','📝'),('rang-liste','Rangübersicht','🎖️')),False),
}


def normalize(name):
    value=name.casefold().replace('ä','ae').replace('ö','oe').replace('ü','ue').replace('ß','ss')
    return re.sub(r'[^a-z0-9]+','',unicodedata.normalize('NFKD',value))


def match_category(guild,spec):
    names={
        'home':('USHERO Info',),'info':('USHERO Info',),'verkauf':('Verkauf & Kasse',),
        'warehouse':('Warehouse',),'vip':('VIP',),'taenzer':('Entertainment',),
        'security':('Security',),'dienst':('Dienst & Personal',),'dienstplan':('Dienst & Personal',),
        'buchhaltung':('Büro',),'leitung':('Leitung privat','Büro'),'ki':('Leitung privat',),
    }.get(spec.area,())
    for name in names:
        matches=[c for c in guild.categories if normalize(c.name)==normalize(name)]
        if len(matches)==1:return matches[0]
        if len(matches)>1:return None
    return None


def match_channel(guild,spec,overrides=None):
    configured=(overrides or {}).get(spec.key)
    if configured is not None:
        try: ident=int(configured)
        except (ValueError,TypeError): raise ValueError(f'{spec.key}: Kanal-ID in panel_channels ist ungültig.') from None
        channel=next((c for c in guild.text_channels if c.id==ident),None)
        if channel is None: raise ValueError(f'{spec.key}: Konfigurierter Kanal gehört nicht zu diesem Server oder fehlt.')
        return channel
    # Der Hauptname hat Vorrang vor Aliasen. Bei Namensduplikaten nie raten.
    for name in (spec.channel,*spec.aliases):
        matches=[c for c in guild.text_channels if normalize(c.name)==normalize(name)]
        if len(matches)>1: raise ValueError(f'{spec.key}: Mehrere passende Kanäle. Bitte panel_channels in config.json mit der Kanal-ID ausfüllen.')
        if matches: return matches[0]
    return None
