"""Optionale Sheets-Kopie. Lokale Buchungen bleiben die massgebliche Datenbasis."""
import os
import aiohttp


async def _request(data=None,params=None):
    if os.getenv('ENABLE_SHEETS','false').lower()!='true':
        return {'ok':False,'error':'Sheets ist deaktiviert'}
    url=os.getenv('SHEETS_URL','').strip()
    key=os.getenv('SHEETS_SHARED_KEY','').strip()
    if not url.startswith('https://') or not key:
        return {'ok':False,'error':'Sheets-URL oder gemeinsamer Schluessel fehlt'}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as session:
            if data is not None:
                request=session.post(url,json={**data,'shared_key':key})
            else:
                request=session.get(url,params={**(params or {}),'shared_key':key})
            async with request as response:
                if response.status!=200:return {'ok':False,'error':'Sheets hat den Aufruf abgelehnt'}
                result=await response.json(content_type=None)
                return result if isinstance(result,dict) else {'ok':False,'error':'Ungueltige Sheets-Antwort'}
    except (aiohttp.ClientError,TimeoutError,ValueError):
        return {'ok':False,'error':'Sheets nicht erreichbar; lokale Buchung bleibt gespeichert'}


async def sheets_post(data):return await _request(data=data)
async def sheets_get(params):return await _request(params=params)
