"""Konsistenter, wiederholbarer Sheets-Spiegel; Google ist nicht die Buchungsdatenbank."""
import asyncio
import hashlib
import json
import os
import uuid
from datetime import datetime,timezone
import aiosqlite
from utils.database import DB_PATH
from utils.sheet_schema import TABLES
from utils.sheets import sheets_post

MAX_ROWS=10000
MAX_PAYLOAD=7*1024*1024


async def build_snapshot(team=()):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT)')
        await db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('sheets_source_id',?)",(str(uuid.uuid4()),))
        await db.commit()
        await db.execute('BEGIN')
        source=(await (await db.execute("SELECT value FROM settings WHERE key='sheets_source_id'")).fetchone())[0]
        tables={}
        for spec in TABLES:
            if spec['sql']:
                rows=await (await db.execute(spec['sql']+' LIMIT 10001')).fetchall()
            else:rows=list(team)
            if len(rows)>MAX_ROWS:raise ValueError(f"{spec['name']}: mehr als 10000 Einträge. Kein unvollständiger Sheets-Abgleich ausgeführt.")
            converted=[]
            for row in rows:
                values=[]
                for column,value in enumerate(row,1):
                    if value is None:value=''
                    if column in spec['text']:value=str(value)
                    if isinstance(value,str) and len(value)>2000:value=value[:1960]+' … [gekürzt]'
                    values.append(value)
                converted.append(values)
            tables[spec['key']]={'columns':spec['headers'],'rows':converted}
    canonical=json.dumps({'source':source,'tables':tables},ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
    digest=hashlib.sha256(canonical.encode()).hexdigest()
    payload={'type':'snapshot','version':2,'source':source,'revision':digest,'tables':tables}
    if len(json.dumps(payload,ensure_ascii=False,allow_nan=False).encode())>MAX_PAYLOAD:
        raise ValueError('Datenumfang für einen vollständigen Sheets-Abgleich zu groß. Es wird kein Teilstand übertragen.')
    return payload


class SheetSync:
    def __init__(self,bot):
        self.bot=bot;self.lock=asyncio.Lock();self.last_attempt=None;self.last_ok=None;self.last_error=None;self.last_revision=None

    def enabled(self):return os.getenv('ENABLE_SHEETS','false').lower()=='true'

    def team(self):
        from utils.menu_ui import server_allowed
        from utils.perms import is_staff
        result=[]
        for guild in self.bot.guilds:
            if not server_allowed(self.bot,guild):continue
            for member in guild.members:
                if not member.bot and is_staff(member):
                    result.append([str(member.id),member.display_name,', '.join(r.name for r in member.roles if r.name!='@everyone')])
        return sorted(result,key=lambda row:row[0])

    async def sync(self,*,force=False):
        if not self.enabled():return {'ok':False,'error':'Sheets ist deaktiviert. Anleitung im Ordner sheets.'}
        async with self.lock:
            self.last_attempt=datetime.now(timezone.utc).isoformat()
            try:
                payload=await build_snapshot(self.team())
                payload['force']=force
                result=await sheets_post(payload)
                if not result.get('ok'):raise ValueError(str(result.get('error','Sheets-Abgleich nicht bestätigt.'))[:300])
                if result.get('revision')!=payload['revision']:
                    raise ValueError('Sheets hat den neuen Datenstand nicht bestätigt. Apps Script auf Version 2 aktualisieren.')
                self.last_ok=self.last_attempt;self.last_error=None;self.last_revision=payload['revision']
                return result
            except (ValueError,aiosqlite.Error) as error:
                self.last_error=str(error)[:300]
                return {'ok':False,'error':self.last_error}
