"""Sheets-Export, Vorlagendesign und genau zwei Discord-Navigationseintraege."""
import asyncio
import json
import os
from pathlib import Path
import shutil
import subprocess
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock,patch
from xml.etree import ElementTree as ET
import zipfile
from test_repair import execute,rows
from utils.database import DB_PATH,init_db,add_sale,add_vip
from utils.sheet_schema import TABLES,THEME
from utils.sheet_sync import build_snapshot,SheetSync
from bot import UsheroBot

ROOT=Path(__file__).resolve().parent.parent
APPS_TEST='const fs=require(\'node:fs\'),vm=require(\'node:vm\'),assert=require(\'node:assert/strict\');\nconst data=JSON.parse(fs.readFileSync(0,\'utf8\'));\nconst values=new Map([[\'USHERO_SHARED_KEY\',\'synthetic-secret-for-offline-test-12345\'],[\'USHERO_SHEET_ID\',\'test-sheet\']]);\nlet tableWrites=0;\nconst props={getProperty:k=>values.get(k)||null,setProperty(k,v){values.set(k,v);return this;},setProperties(obj){Object.entries(obj).forEach(([k,v])=>values.set(k,v));return this;},deleteProperty(k){values.delete(k);return this;}};\nconst chain=names=>{const x={};names.forEach(n=>x[n]=()=>x);x.build=()=>({});return x;};\nclass Range {\n constructor(sheet,r,c,h=1,w=1){this.sheet=sheet;this.r=r;this.c=c;this.h=h;this.w=w;}\n setValue(v){return this.setValues([[v]]);}\n setValues(rows){\n  if(this.r>1&&this.sheet.name!==\'Dashboard\')tableWrites++;\n  for(let r=0;r<rows.length;r++)for(let c=0;c<rows[r].length;c++)this.sheet.cells.set((this.r+r)+\',\'+(this.c+c),rows[r][c]);\n  return this;\n }\n getValue(){return this.getValues()[0][0];}\n getValues(){return Array.from({length:this.h},(_,r)=>Array.from({length:this.w},(_,c)=>this.sheet.cells.get((this.r+r)+\',\'+(this.c+c))??\'\'));}\n clearContent(){for(const [key] of this.sheet.cells){const [r,c]=key.split(\',\').map(Number);if(r>=this.r&&r<this.r+this.h&&c>=this.c&&c<this.c+this.w)this.sheet.cells.delete(key);}return this;}\n setFormula(v){return this.setValue(v);}\n setBackground(v){this.sheet.colors.add(v);return this;}\n applyRowBanding(){return chain([\'setHeaderRowColor\',\'setFirstRowColor\',\'setSecondRowColor\',\'remove\']);}\n createFilter(){return this;}\n}\nfor(const name of [\'setFontColor\',\'setFontFamily\',\'setFontSize\',\'setFontWeight\',\'setWrap\',\'setVerticalAlignment\',\'setNumberFormat\',\'merge\',\'breakApart\'])Range.prototype[name]=function(){return this;};\nfunction coords(address){const m=/^([A-Z]+)(\\d+)(?::([A-Z]+)(\\d+))?$/.exec(address);if(!m)throw new Error(\'Unknown range \'+address);const col=s=>[...s].reduce((n,c)=>26*n+c.charCodeAt(0)-64,0);return [Number(m[2]),col(m[1]),m[4]?Number(m[4])-Number(m[2])+1:1,m[3]?col(m[3])-col(m[1])+1:1];}\nclass Sheet {\n constructor(ss,name){this.ss=ss;this.name=name;this.cells=new Map();this.rows=300;this.colors=new Set();this.tab=null;}\n getName(){return this.name;}\n setName(name){this.ss.sheets.delete(this.name);this.name=name;this.ss.sheets.set(name,this);return this;}\n getRange(...args){return new Range(this,...(typeof args[0]===\'string\'?coords(args[0]):args));}\n getLastRow(){return Math.max(0,...[...this.cells.keys()].filter(k=>this.cells.get(k)!==\'\').map(k=>Number(k.split(\',\')[0])));}\n getMaxRows(){return this.rows;}\n getMaxColumns(){return 26;}\n getBandings(){return [];}\n getFilter(){return null;}\n getCharts(){return [];}\n setTabColor(color){this.tab=color;return this;}\n insertRowsAfter(start,count){this.rows+=count;return this;}\n newChart(){return chain([\'setChartType\',\'addRange\',\'setPosition\',\'setOption\']);}\n}\nfor(const n of [\'setFrozenRows\',\'setFrozenColumns\',\'setHiddenGridlines\',\'setRowHeight\',\'setRowHeights\',\'setColumnWidth\',\'setColumnWidths\',\'setConditionalFormatRules\',\'insertChart\',\'removeChart\'])Sheet.prototype[n]=function(){return this;};\nconst ss={sheets:new Map(),getId:()=> \'test-sheet\',getSheetByName(n){return this.sheets.get(n)||null;},insertSheet(n){const s=new Sheet(this,n);this.sheets.set(n,s);return s;},setActiveSheet(){return this;}};\nconst ctx=vm.createContext({console,Date,JSON,PropertiesService:{getScriptProperties:()=>props},\n SpreadsheetApp:{getActiveSpreadsheet:()=>ss,openById:id=>{assert.equal(id,\'test-sheet\');return ss;},flush(){},BandingTheme:{LIGHT_GREY:1},\n newConditionalFormatRule:()=>chain([\'whenNumberLessThanOrEqualTo\',\'whenNumberBetween\',\'whenNumberGreaterThan\',\'whenTextEqualTo\',\'setBackground\',\'setFontColor\',\'setRanges\'])},\n Charts:{ChartType:{COLUMN:1}},Utilities:{formatDate:()=> \'20261101-TEST\',getUuid:()=> \'11111111-1111-1111-1111-111111111111\'},\n LockService:{getScriptLock:()=>({tryLock:()=>true,waitLock(){},releaseLock(){}})},\n ContentService:{MimeType:{JSON:\'json\'},createTextOutput:text=>({text,setMimeType(){return this;}})}});\nvm.runInContext(fs.readFileSync(process.argv[1],\'utf8\'),ctx);\nconst call=payload=>JSON.parse(ctx.doPost({postData:{contents:JSON.stringify(payload)}}).text);\nassert.equal(call({...data,shared_key:\'wrong\'}).ok,false);assert.equal(ss.sheets.size,0);\nlet invalid=JSON.parse(JSON.stringify(data));delete invalid.tables.sales;\nassert.equal(call({...invalid,shared_key:values.get(\'USHERO_SHARED_KEY\')}).ok,false);assert.equal(ss.sheets.size,0);\nctx.USHERO_einrichten();assert.equal(ss.sheets.size,12);\nconst schema=vm.runInContext(\'SCHEMA\',ctx),theme=vm.runInContext(\'THEME\',ctx);\nfor(const spec of schema){const sheet=ss.getSheetByName(spec.name);assert.equal(sheet.tab,spec.color);assert.ok(sheet.colors.has(theme.bg));}\nassert.match(ss.getSheetByName(\'Dashboard\').getRange(\'A4\').getValue(),/Noch kein/);\nlet payload={...data,shared_key:values.get(\'USHERO_SHARED_KEY\')};\nassert.equal(call(payload).revision,data.revision);\nconst sales=ss.getSheetByName(\'Verkäufe\');assert.equal(sales.getLastRow(),2);\nassert.equal(sales.getRange(2,2).getValue(),\'123456789012345678\');\nconst first=tableWrites;assert.equal(call(payload).unchanged,true);assert.equal(tableWrites,first);assert.equal(sales.getLastRow(),2);\nassert.equal(call({...payload,force:true}).ok,true);assert.equal(sales.getLastRow(),2);\nassert.equal(call({...payload,source:\'another-source-123456789012345678\',revision:\'e\'.repeat(64)}).ok,false);\nlet formula=JSON.parse(JSON.stringify(payload));formula.tables.sales.rows[0][2]=\' =IMPORTXML("https://example.invalid","x")\';formula.revision=\'f\'.repeat(64);\nassert.equal(call(formula).ok,true);assert.equal(sales.getRange(2,3).getValue()[0],"\'");\nassert.equal(ctx.safeCell(\'-not-a-number\')[0],"\'");assert.equal(ctx.safeCell(12.5),12.5);\nassert.equal(JSON.parse(ctx.doGet({parameter:{shared_key:\'wrong\'}}).text).ok,false);\n// Altes Tabellenschema wird archiviert, nicht zerstoert.\nsales.getRange(1,1,1,10).setValues([[\'Zeit\',\'Mitarbeiter\',\'Artikel\',\'Gesamt\',\'\',\'\',\'\',\'\',\'\',\'\']]);\nctx.USHERO_einrichten();\nassert.ok([...ss.sheets.keys()].some(n=>n.startsWith(\'Archiv Verkäufe\')));\nassert.equal(sales.getRange(2,2).getValue(),\'123456789012345678\');\nassert.equal(ss.getSheetByName(\'Verkäufe\').getLastRow(),1);\nassert.equal(values.has(\'USHERO_REVISION\'),false);\nassert.equal(call(payload).ok,true);assert.equal(ss.getSheetByName(\'Verkäufe\').getLastRow(),2);\nconsole.log(\'Apps Script OK: colors, authentication, schema validation, repeat snapshots, IDs, safe text, source guard and archive migration.\');\n'


class SheetsTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        for suffix in ('','-wal','-shm'):Path(DB_PATH+suffix).unlink(missing_ok=True)
        await init_db()
        self.bot=UsheroBot(sync_commands=False);await self.bot.__aenter__();await self.bot.setup_hook()
    async def asyncTearDown(self):await self.bot.close()

    async def test_01_snapshot_stable_complete_and_preserves_discord_id_precision(self):
        await add_sale(123456789012345678,'Testartikel',100,2)
        await add_vip(123456789012345678,223456789012345678,50,'Test-VIP')
        first=await build_snapshot();second=await build_snapshot()
        self.assertEqual(first['revision'],second['revision'])
        self.assertEqual(first['source'],second['source'])
        self.assertEqual(len(first['tables']),11)
        row=first['tables']['sales']['rows'][0]
        self.assertEqual(row[1],'123456789012345678');self.assertEqual(row[5],200)
        self.assertEqual(rows('SELECT COUNT(*) FROM sales'),[(1,)])
        for spec in TABLES:self.assertEqual(first['tables'][spec['key']]['columns'],spec['headers'])

    async def test_02_oversized_snapshot_is_rejected_as_a_whole(self):
        for i in range(3):await add_sale(2,'Artikel '+str(i),10)
        with patch('utils.sheet_sync.MAX_ROWS',2):
            with self.assertRaisesRegex(ValueError,'unvollständiger'):await build_snapshot()
        self.assertEqual(rows('SELECT COUNT(*) FROM sales'),[(3,)])

    async def test_03_sync_requires_acknowledged_revision_and_never_rebooks(self):
        await add_sale(2,'Test',100)
        service=SheetSync(self.bot)
        async def success(payload):return {'ok':True,'revision':payload['revision']}
        with patch.dict(os.environ,{'ENABLE_SHEETS':'true'}),patch('utils.sheet_sync.sheets_post',side_effect=success):
            result=await service.sync(force=True)
        self.assertTrue(result['ok']);self.assertIsNotNone(service.last_ok)
        with patch.dict(os.environ,{'ENABLE_SHEETS':'true'}),patch('utils.sheet_sync.sheets_post',new=AsyncMock(return_value={'ok':True,'revision':'wrong'})):
            self.assertFalse((await service.sync())['ok'])
        self.assertEqual(rows('SELECT COUNT(*) FROM sales'),[(1,)])
        self.assertIsNotNone(service.last_error)

    async def test_04_only_two_published_commands_and_legacy_scopes_are_cleared(self):
        self.assertEqual(set(c.name for c in self.bot.tree.get_commands()),{'menu','panel'})
        self.assertTrue({'verkauf','warehouse bestellen','sheets-sync'}<=set(self.bot.actions))
        self.assertFalse({'hilfe','arbeit','befehle','unternehmen'} & set(self.bot.actions))
        observed=[]
        async def sync(*,guild=None):
            observed.append((getattr(guild,'id',None),[c.name for c in self.bot.tree.get_commands(guild=guild)]))
            return []
        guild=SimpleNamespace(id=123)
        import discord
        async def obsolete(interaction): pass
        self.bot.tree.add_command(discord.app_commands.Command(name='alt-doppelt',description='Alter Eintrag',callback=obsolete),guild=guild)
        self.assertIn('alt-doppelt',[c.name for c in self.bot.tree.get_commands(guild=guild)])
        with patch.object(self.bot.tree,'sync',side_effect=sync):
            await self.bot.publish_navigation();await self.bot.publish_navigation(guild)
            await self.bot.publish_navigation();await self.bot.publish_navigation(guild)
        self.assertEqual(observed[0],(None,[]))
        self.assertEqual(set(observed[1][1]),{'menu','panel'});self.assertEqual(len(observed),2)
        self.assertEqual(set(c.name for c in self.bot.tree.get_commands()),{'menu','panel'})

    async def test_05_local_sheets_setup_preserves_existing_token_and_options(self):
        from run import save_env_values
        import tempfile
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'.env';path.write_text('DISCORD_TOKEN=synthetic-test-only\nOTHER=keep\nENABLE_SHEETS=false\n')
            save_env_values(path,{'ENABLE_SHEETS':'true','SHEETS_URL':'https://example.invalid/exec'})
            value=path.read_text()
            self.assertIn('DISCORD_TOKEN=synthetic-test-only',value)
            self.assertIn('OTHER=keep',value);self.assertEqual(value.count('ENABLE_SHEETS='),1)

    async def test_06_xlsx_has_dark_backgrounds_headers_ids_and_real_dashboard_formulas(self):
        with zipfile.ZipFile(ROOT/'sheets/USHERO-Dashboard.xlsx') as z:
            ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            wb=ET.fromstring(z.read('xl/workbook.xml'))
            names=[s.attrib['name'] for s in wb.findall('m:sheets/m:sheet',ns)]
            self.assertEqual(len(names),12);self.assertEqual(names[0],'Dashboard')
            styles=z.read('xl/styles.xml').decode()
            self.assertIn('11131F',styles);self.assertIn('EB459E',styles);self.assertIn('00D9E8',styles)
            dashboard=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            formula=dashboard.find('.//m:c[@r="A6"]/m:f',ns).text
            self.assertIn("'Verkäufe'!F2",formula);self.assertIn("'VIP'!D2",formula)
            self.assertNotIn('Tanz-Sessions',formula)
            self.assertIn('1B1F33',z.read('xl/charts/chart1.xml').decode())
            self.assertFalse(any(name.startswith('xl/externalLinks/') for name in z.namelist()))

    @unittest.skipUnless(shutil.which('node'),'Node nur fuer den Apps-Script-Offlinetest erforderlich')
    async def test_07_apps_script_snapshot_auth_styling_archive_and_no_duplicate_rows(self):
        await add_sale(123456789012345678,'Testartikel',100)
        payload=await build_snapshot()
        result=await asyncio.to_thread(subprocess.run,['node','-e',APPS_TEST,str(ROOT/'sheets/Code.gs')],input=json.dumps(payload),text=True,capture_output=True,timeout=20)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertIn('Apps Script OK',result.stdout)
