"""Offline-Integrationstests. Nie Anmeldung bei Discord oder Nutzung echter Tokens."""
import asyncio
import hashlib
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch,AsyncMock

_TEMP=tempfile.TemporaryDirectory(prefix='ushero-test-')
os.environ['USHERO_DB_PATH']=str(Path(_TEMP.name)/'bot.db')
# Tests duerfen niemals eine versehentlich vorhandene externe KI aktivieren.
os.environ['ENABLE_OPENAI']='false'
os.environ['ENABLE_SHEETS']='false'
os.environ['GUILD_ID']='123'

import discord
from discord import app_commands
from bot import UsheroBot,EXTENSIONS
from utils import database as database
from utils.database import DB_PATH,init_db,add_sale,add_vip,start_dance
from utils.settlements import pending_summary,settle_employee
from utils.menu_ui import (ActionView,ActionModal,HomeView,CategoryView,allowed,category,CATEGORIES,
                            open_category,invoke,validate,server_allowed)
from utils.sheet_sync import SheetSync
from cogs.schicht import start_schicht,end_schicht,is_on_duty
from cogs.buchhaltung import init_buchhaltung_tables,get_firmenkasse
from cogs.verkauf import WarenkorbView,QuantityModal,ARTIKEL


def rows(query,args=()):
    with sqlite3.connect(DB_PATH) as db:
        return db.execute(query,args).fetchall()


def execute(query,args=()):
    with sqlite3.connect(DB_PATH) as db:
        db.execute(query,args)


class Response:
    def __init__(self,interaction): self.interaction=interaction;self.done=False;self.modal=None
    def is_done(self): return self.done
    async def send_message(self,content=None,**kwargs):
        if self.done: raise AssertionError('Doppelte Discord-Antwort')
        self.done=True;self.interaction.record(content,kwargs)
    async def defer(self,**kwargs):
        if self.done: raise AssertionError('Doppelte Discord-Antwort')
        self.done=True
    async def edit_message(self,**kwargs):
        if self.done: raise AssertionError('Doppelte Discord-Antwort')
        self.done=True;self.interaction.record(None,kwargs)
    async def send_modal(self,modal):
        if self.done: raise AssertionError('Doppelte Discord-Antwort')
        self.done=True;self.modal=modal


class Interaction:
    def __init__(self,user,client):
        self.user=user;self.guild=user.guild;self.client=client
        self.response=Response(self);self.messages=[];self.command=None
        self.followup=SimpleNamespace(send=self.followup_send)
        self.channel=SimpleNamespace(id=99,send=self.followup_send)
        self.namespace=SimpleNamespace()
    def record(self,content,kwargs):
        if content: assert len(content)<=2000
        embeds=kwargs.get('embeds',[]) or ([kwargs['embed']] if kwargs.get('embed') else [])
        assert sum(len(e) for e in embeds)<=6000,'Discord-Embeds zu gross'
        for embed in embeds:
            assert len(embed.fields)<=25,'Mehr als 25 Discord-Felder'
            assert len(embed.description or '')<=4096
            for field in embed.fields:
                assert len(field.value)<=1024
        self.messages.append((content,kwargs))
    async def followup_send(self,content=None,**kwargs): self.record(content,kwargs)
    async def edit_original_response(self,**kwargs): self.record(None,kwargs)


def guild_and_user(roles=(),uid=2,admin=False):
    guild=SimpleNamespace(id=123,owner_id=1,name='Testclub',text_channels=[],roles=[],categories=[])
    permissions=discord.Permissions(administrator=admin,manage_guild=admin,manage_roles=admin,
        moderate_members=admin,send_messages=True,embed_links=True,manage_messages=admin,
        manage_channels=admin,read_message_history=True)
    async def send(*args,**kwargs): pass
    member=SimpleNamespace(id=uid,guild=guild,guild_permissions=permissions,roles=[SimpleNamespace(name=r) for r in roles],
        display_name='Testmitglied',mention=f'<@{uid}>',display_avatar=SimpleNamespace(url='https://example.invalid/avatar.png'),send=send)
    member.top_role=SimpleNamespace(position=99)
    guild.me=member;guild.get_member=lambda ident: member if ident==uid else None
    guild.get_channel=lambda ident:None
    return guild,member


class RepairTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        for suffix in ('','-wal','-shm'):
            Path(DB_PATH+suffix).unlink(missing_ok=True)
        await init_db()
        self.bot=UsheroBot(sync_commands=False)
        await self.bot.__aenter__()
        await self.bot.setup_hook()
        self.guild,self.owner=guild_and_user(uid=1,admin=True)
        self.client=SimpleNamespace(tree=self.bot.tree,actions=self.bot.actions,guilds=[self.guild],get_cog=self.bot.get_cog,user=SimpleNamespace(id=999))

    async def asyncTearDown(self):
        await self.bot.close()

    def command(self,name):
        return self.bot.actions[name]

    def interaction(self,user=None): return Interaction(user or self.owner,self.client)

    async def test_01_all_modules_forms_and_persistent_menus(self):
        self.assertEqual(len(self.bot.cogs),20)
        self.assertEqual(len(self.bot.extensions),len(EXTENSIONS))
        self.assertEqual(list(self.bot.cogs).count('Schicht'),1)
        self.assertNotIn('cogs.__init__',self.bot.extensions)
        self.assertNotIn('cogs.schicht_fixed',self.bot.extensions)
        actions=list(self.bot.actions.values())
        self.assertGreaterEqual(len(actions),64)
        for command in actions:
            with self.subTest(command=command.qualified_name):
                action=ActionView(1,command)
                self.assertTrue(action.to_components())
                self.assertIn(category(command),CATEGORIES)
                texts=[p for p in command.parameters if not p.choices and p.type in (discord.AppCommandOptionType.string,discord.AppCommandOptionType.integer,discord.AppCommandOptionType.number)]
                if texts: self.assertLessEqual(len(ActionModal(action,texts).children),5)
        view=HomeView();self.assertTrue(view.is_persistent())
        ids=[item.custom_id for item in view.children]
        self.assertEqual(len(ids),len(set(ids)))
        from cogs.channel_panels import CleanPanelView,AREAS
        views=[CleanPanelView(a) for a in AREAS]
        self.assertTrue(all(v.is_persistent() for v in views))
        all_ids=[i.custom_id for v in views for i in v.children]
        self.assertEqual(len(all_ids),len(set(all_ids)))

    async def test_02_roles_guests_and_stale_forms(self):
        _,guest=guild_and_user(['VIP-Kunde'])
        _,seller=guild_and_user(['Verkauf'])
        _,staff=guild_and_user(['Mitarbeiter'])
        self.assertFalse(allowed(guest,self.command('verkauf')))
        self.assertTrue(allowed(guest,self.command('bewerbung stellen')))
        self.assertTrue(allowed(seller,self.command('verkauf')))
        self.assertFalse(allowed(seller,self.command('firmenkasse')))
        self.assertFalse(allowed(staff,self.command('ki status')))
        _,other_admin=guild_and_user(uid=3,admin=True)
        self.assertFalse(allowed(other_admin,self.command('ki status')))
        self.assertTrue(allowed(self.owner,self.command('ki status')))
        action=ActionView(staff.id,self.command('verkauf'))
        staff.roles=[]
        with self.assertRaises(app_commands.CheckFailure): await action.run(self.interaction(staff))
        wrong=self.interaction(self.owner)
        self.assertFalse(await action.interaction_check(wrong))

    async def test_03_choice_and_modal_complete_a_real_warehouse_order(self):
        command=self.command('warehouse bestellen')
        action=ActionView(1,command)
        select=next(i for i in action.children if isinstance(i,discord.ui.Select))
        select._values=['0']
        await select.callback(self.interaction())
        self.assertIsInstance(action.values['artikel'],app_commands.Choice)
        fill=next(i for i in action.children if getattr(i,'label','').startswith('Angaben'))
        interaction=self.interaction();await fill.callback(interaction)
        modal=interaction.response.modal
        for field in modal.children:
            field._value='3' if field.custom_id=='menge' else 'Testlieferung'
        await modal.on_submit(self.interaction())
        self.assertEqual(action.values['menge'],3)
        await action.run(self.interaction())
        await action.run(self.interaction())
        self.assertEqual(rows('SELECT quantity,status FROM warehouse_orders'),[(3,'offen')])

    async def test_04_all_areas_open_real_actions(self):
        for key in CATEGORIES:
            interaction=self.interaction()
            await open_category(interaction,key)
            view=interaction.messages[-1][1]['view']
            self.assertIsInstance(view,CategoryView)
            select=next(i for i in view.children if isinstance(i,discord.ui.Select))
            select._values=[select.options[0].value]
            result=self.interaction();await select.callback(result)
            self.assertIsInstance(result.messages[-1][1]['view'],ActionView)

    async def test_05_all_readonly_callbacks_respond(self):
        names=['stats','wer-darf-was','mein-panel','firmenkasse','abrechnungen',
            'meine-abrechnungen','dienstplan heute','dienstplan zeigen','dienstplan meine',
            'ki status','ki tagesauswertung','ki bestellung','ki dienstplan','ki anomalie',
            'ki marketing','ki concierge','ki moderation','ki visual','ki panel','vip-ablauf',
            'daily-report','diagnose check','meine-verkaeufe','verkauf-summe','rang','rang-liste','security aktiv','security summe','sheets-status',
            'taenzer aktiv','preisliste','vip summe','warehouse lager','warehouse offen','warehouse historie','menu','diagnose cogs','diagnose fehler']
        for name in names:
            command=self.command(name)
            values={p.name:(p.default if not p.required else 'Testtext') for p in command.parameters}
            interaction=self.interaction()
            with self.subTest(command=name):
                await invoke(interaction,command,values)
                self.assertTrue(interaction.messages)

    async def test_06_shift_concurrency_and_bonus_settlement(self):
        starts=await asyncio.gather(start_schicht(2),start_schicht(2))
        self.assertEqual(sum(starts),1)
        self.assertTrue(await is_on_duty(2))
        await add_sale(2,'Eintritt',1000)
        result=await settle_employee(2)
        self.assertEqual((result['gross'],result['employee'],result['company'],result['bonus']),(1000,220,780,20))
        self.assertFalse(await is_on_duty(2))
        self.assertIsNone(await end_schicht(2))
        self.assertEqual(rows('SELECT started_at=startzeit,ended_at=endzeit,status FROM schichten'),[(1,1,'beendet')])

    async def test_07_double_settlement_only_pays_once_and_later_sales_only_once(self):
        await add_sale(2,'Getränk',100,2)
        await add_vip(2,3,100,'VIP')
        results=await asyncio.gather(settle_employee(2),settle_employee(2))
        self.assertEqual(sum(r is not None for r in results),1)
        self.assertEqual(await get_firmenkasse(),240)
        self.assertEqual((await pending_summary(2))[0],0)
        self.assertEqual(rows('SELECT COUNT(*) FROM abrechnungen'),[(1,)])
        await add_sale(2,'Essen',30,2)
        result=await settle_employee(2)
        self.assertEqual(result['gross'],60)
        self.assertEqual(await get_firmenkasse(),288)
        self.assertEqual(rows('SELECT COUNT(*) FROM sales WHERE settlement_id IS NULL'),[(0,)])

    async def test_08_warehouse_receipt_double_click_does_not_double_stock(self):
        await invoke(self.interaction(),self.command('warehouse bestellen'),{'artikel':app_commands.Choice(name='Trinken',value='Trinken (Warehouse)'),'menge':5,'notiz':''})
        command=self.command('warehouse eingang')
        await asyncio.gather(invoke(self.interaction(),command,{'bestell_nr':1}),invoke(self.interaction(),command,{'bestell_nr':1}))
        self.assertEqual(rows('SELECT quantity FROM warehouse_stock WHERE item=?',('Trinken (Warehouse)',)),[(5,)])

    async def test_09_cart_modal_and_double_checkout_local_ledger(self):
        view=WarenkorbView(self.owner)
        item=next(iter(ARTIKEL))
        modal=QuantityModal(view,item);modal.menge._value='2'
        await modal.on_submit(self.interaction())
        self.assertEqual(view.cart[item],2)
        await asyncio.gather(view.finish(self.interaction()),view.finish(self.interaction()))
        self.assertEqual(rows('SELECT item,quantity,amount FROM sales'),[(item,2,ARTIKEL[item])])
        self.assertTrue(view.completed)
        self.assertTrue(all(c.disabled for c in view.children))

    async def test_10_invalid_values_never_enter_ledgers(self):
        for amount in (0,-1,float('nan'),float('inf'),0.001):
            with self.subTest(amount=amount):
                with self.assertRaises(ValueError): await add_sale(2,'Fehler',amount)
        for value in ({'menge':0},{'neuer_bestand':-1},{'preis':float('nan')},{'tag':'2026-02-30'},{'von':'25:40'},{'limit':30}):
            with self.assertRaises(ValueError):validate(value)
        self.assertEqual(rows('SELECT COUNT(*) FROM sales'),[(0,)])

    async def test_11_dance_creation_is_atomic_and_prevents_overlapping_sessions(self):
        ident=await start_dance(2,3,10,50)
        self.assertEqual(ident,1)
        with self.assertRaises(ValueError): await start_dance(2,4,15,70)
        self.assertEqual(rows('SELECT COUNT(*) FROM dance_sessions'),[(1,)])
        self.assertEqual(rows("SELECT COUNT(*),SUM(amount) FROM sales WHERE category='taenzer'"),[(1,50)])
        _,other=guild_and_user(['Tänzer/in'],uid=4)
        interaction=self.interaction(other)
        await invoke(interaction,self.command('taenzer beenden'),{'session_id':ident})
        self.assertEqual(rows('SELECT status FROM dance_sessions'),[('active',)])

    async def test_12_security_duty_has_no_duplicate_starts(self):
        command=self.command('security dienst-start')
        await asyncio.gather(invoke(self.interaction(),command,{'notiz':'Test'}),invoke(self.interaction(),command,{'notiz':'Test'}))
        self.assertEqual(rows('SELECT COUNT(*) FROM security_duty'),[(1,)])
        await invoke(self.interaction(),self.command('security dienst-ende'),{})
        await invoke(self.interaction(),self.command('security dienst-ende'),{})
        self.assertEqual(rows('SELECT status FROM security_duty'),[('finished',)])

    async def test_13_server_scope_prevents_cross_server_data_access(self):
        self.assertTrue(server_allowed(self.client,self.guild))
        other=SimpleNamespace(id=456)
        self.assertFalse(server_allowed(self.client,other))
        with patch.dict(os.environ,{'GUILD_ID':''}):
            self.assertTrue(server_allowed(self.client,self.guild))
            self.client.guilds.append(other)
            self.assertFalse(server_allowed(self.client,self.guild))
        self.client.guilds.pop()

    async def test_14_legacy_startzeit_schema_is_migrated_without_losing_history(self):
        await self.bot.close()
        Path(DB_PATH).unlink()
        execute('CREATE TABLE schichten(id INTEGER PRIMARY KEY,user_id INTEGER,startzeit TEXT,endzeit TEXT,status TEXT)')
        execute("INSERT INTO schichten VALUES(1,2,'2026-10-30T10:00:00',NULL,'aktiv')")
        execute("INSERT INTO schichten VALUES(2,2,'2026-10-31T10:00:00',NULL,'aktiv')")
        await init_db();await init_db()
        self.assertEqual(rows('SELECT id,started_at,status FROM schichten ORDER BY id'),[(1,'2026-10-30T10:00:00','bereinigt'),(2,'2026-10-31T10:00:00','aktiv')])
        self.assertEqual(rows('SELECT COUNT(*) FROM schema_migrations'),[(1,)])
        self.assertIn('dauer',[r[1] for r in rows('PRAGMA table_info(schichten)')])
        self.assertTrue(Path(DB_PATH).parent.joinpath('backups/bot-vor-reparatur.db').exists())

    async def test_15_existing_settlements_are_not_repaid_on_upgrade(self):
        await add_sale(2,'Alt',100)
        execute('ALTER TABLE sales DROP COLUMN settlement_id')
        execute('ALTER TABLE vip_entries DROP COLUMN settlement_id')
        execute('DELETE FROM schema_migrations')
        execute("INSERT INTO abrechnungen(user_id,brutto,created_at) VALUES(2,100,'2099-01-01T00:00:00')")
        await database.migrate_legacy()
        self.assertEqual((await pending_summary(2))[0],0)

    async def test_16_setup_preserves_existing_roles(self):
        # Ein funktionsfaehiger Fake-Server; jedes Loeschen einer Rolle waere ein Testfehler.
        class Role:
            def __init__(self,name): self.name=name
            async def delete(self,**kwargs): raise AssertionError('Rollen duerfen nicht geloescht werden')
        guild=self.guild
        guild.roles=[Role('Mitarbeiter'),Role('Leitung')]
        class HashableMember(SimpleNamespace):
            __hash__=object.__hash__
        guild.me=HashableMember(**vars(self.owner))
        async def create_role(name,**kwargs):
            role=Role(name);guild.roles.append(role);return role
        async def create_category(name,**kwargs):
            cat=SimpleNamespace(name=name);guild.categories.append(cat);return cat
        async def create_channel(name,**kwargs):
            async def send(*args,**kwargs): pass
            ch=SimpleNamespace(name=name,send=send);guild.text_channels.append(ch);return ch
        guild.create_role=create_role;guild.create_category=create_category;guild.create_text_channel=create_channel
        guild.default_role=guild.roles[0]
        await invoke(self.interaction(),self.command('setup'),{})
        self.assertTrue(any(r.name=='Mitarbeiter' for r in guild.roles))
        self.assertEqual(sum(r.name=='Mitarbeiter' for r in guild.roles),1)
        self.assertGreater(len(guild.text_channels),20)
        count=(len(guild.roles),len(guild.categories),len(guild.text_channels))
        await invoke(self.interaction(),self.command('setup'),{})
        self.assertEqual(count,(len(guild.roles),len(guild.categories),len(guild.text_channels)))

    async def test_17_real_member_select_choice_and_multifield_plan_form(self):
        actual_guild=discord.Guild(data={'id':'123','name':'Test','owner_id':'1','roles':[]},state=self.bot._connection)
        member=discord.Member(data={'user':{'id':'6','username':'Test','discriminator':'0','avatar':None},'roles':[],'joined_at':'2026-01-01T00:00:00+00:00','flags':0},guild=actual_guild,state=self.bot._connection)
        action=ActionView(1,self.command('dienstplan eintragen'))
        select=next(c for c in action.children if isinstance(c,discord.ui.UserSelect))
        select._values=[member]
        await select.callback(self.interaction())
        select=next(c for c in action.children if isinstance(c,discord.ui.Select))
        select._values=['0'];await select.callback(self.interaction())
        fields=[p for p in action.command.parameters if p.name in ('von','bis','tag','notiz')]
        modal=ActionModal(action,fields)
        values={'von':'20:00','bis':'04:00','tag':'2026-11-01','notiz':'Testdienst'}
        for field in modal.children: field._value=values[field.custom_id]
        await modal.on_submit(self.interaction())
        await action.run(self.interaction())
        self.assertEqual(rows('SELECT user_id,tag,von,bis FROM dienstplan'),[(6,'2026-11-01','20:00','04:00')])

    async def test_18_timer_finishes_expired_dance_and_overdue_shift_once(self):
        from utils.clock import utcnow
        from datetime import timedelta
        await start_schicht(2)
        execute('UPDATE schichten SET started_at=?',((utcnow()-timedelta(hours=13)).isoformat(),))
        await start_dance(2,3,10,50)
        execute('UPDATE dance_sessions SET ends_at=?',((utcnow()-timedelta(minutes=1)).isoformat(),))
        timer=self.bot.get_cog('AutoTasks')
        timer.bot=self.client
        await timer.check_once();await timer.check_once()
        self.assertEqual(rows('SELECT status FROM schichten'),[('auto_logout',)])
        self.assertEqual(rows('SELECT status FROM dance_sessions'),[('finished',)])
        result=await settle_employee(2)
        self.assertEqual(result['bonus'],0)

    async def test_19_external_services_default_off_even_with_old_keys(self):
        from utils.openai_client import chat_completion,generate_image
        from utils.sheets import sheets_post
        with patch.dict(os.environ,{'ENABLE_OPENAI':'false','ENABLE_SHEETS':'false','OPENAI_API_KEY':'synthetic-test-key','SHEETS_URL':'https://example.invalid','SHEETS_SHARED_KEY':'synthetic-test-key'}):
            with patch('aiohttp.ClientSession',side_effect=AssertionError('Kein externer Aufruf erlaubt')):
                self.assertIsNone(await chat_completion('Test','Test'))
                self.assertIsNone(await generate_image('Test'))
                self.assertFalse((await sheets_post({'type':'verkauf'}))['ok'])

    async def test_20_failed_sheets_copy_does_not_lose_or_duplicate_local_sale(self):
        view=WarenkorbView(self.owner)
        item=next(iter(ARTIKEL));view.cart[item]=1
        mocked=AsyncMock(return_value={'ok':False,'error':'simuliert'})
        service=SheetSync(self.client)
        with patch.dict(os.environ,{'ENABLE_SHEETS':'true'}),patch('utils.sheet_sync.sheets_post',mocked),patch.object(service,'team',return_value=[]):
            interaction=self.interaction()
            await view.finish(interaction)
            await view.finish(self.interaction())
            result=await service.sync()
            self.assertFalse(result['ok'])
        mocked.assert_awaited_once()
        self.assertEqual(rows('SELECT COUNT(*) FROM sales'),[(1,)])
        self.assertTrue(view.completed)
        self.assertEqual(rows('SELECT COUNT(*) FROM sales'),[(1,)])


if __name__=='__main__':unittest.main()
