# Einrichtung

Die aktuelle vollständige Anleitung steht in [README.md](README.md).

Für deinen bereits vorhandenen Bot genügt die bisherige `.env` im neuen Ordner,
eine passende Python-Version und `start.bat`. Die Datenbank-Sicherung und
Migration erfolgen beim ersten Bot-Start. Das einmal gepostete `/panel` bleibt
als Button-Menü im Discord-Kanal verfügbar.

Es werden keine alten Rollen entfernt. Die Server-Einrichtung im Leitungsmenü
legt nur fehlende Standardrollen und Kanäle an, wenn du sie bewusst ausführst.
Vorhandene Kanalrechte werden dabei nicht ungefragt überschrieben.
