@echo off
chcp 65001 >nul
cd /d "%~dp0"
title USHERO Bot
where py >nul 2>nul
if not errorlevel 1 (
  for %%V in (3.12 3.13 3.14 3.11) do (
    py -%%V --version >nul 2>nul
    if not errorlevel 1 (
      py -%%V run.py
      goto ende
    )
  )
)
where python >nul 2>nul
if errorlevel 1 (
  echo Python fehlt. Bitte Python 3.12 von python.org installieren.
  goto ende
)
python run.py
:ende
pause
