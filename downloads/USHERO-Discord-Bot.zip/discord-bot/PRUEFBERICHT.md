# USHERO – Prüfbericht, 1. November 2026

## Geliefert

Vollständiger überarbeiteter Quellordner auf Grundlage von `discord-bot.zip`, nicht
nur einzelne Codeblöcke. Preise und vorhandene Konfiguration bleiben erhalten.
Die private `data/bot.db` wird nicht über GitHub verteilt. Vor dem Update die aktuellste eigene Datenbank übernehmen. `.env`, Python-Caches,
virtuelle Umgebungen und Testlauf-Daten sind nicht im Download enthalten.
Die vorhandenen `sheets/`-Dateipfade bleiben enthalten; beide Code.gs-Kopien sind
auf dasselbe abgesicherte Beispiel aktualisiert.

## Behobene konkrete Probleme

- `utils.design`: fehlende Discord-Imports, fehlende Farben/box/stempel_aus und
  falscher Rückgabetyp der Stempel-Funktion repariert.
- Module werden einmal in `setup_hook` geladen, nicht bei jedem `on_ready`.
  Kein Laden von `cogs.__init__`; `schicht_fixed` ist nur noch ein Import-Shim,
  niemals eine zweite registrierte Schicht-Cog.
- Fehlender Datenbankstart und konkurrierende Initialisierungen behoben.
  Migration berücksichtigt beide älteren Schichtspalten-Schemata und erzeugt
  vorab eine Sicherung. Doppeltes Ein-/Ausstempeln ist abgefangen.
- Fehlender `currency`-Konfigurationswert erhält einen Standard. Konfiguration
  und Preisdaten werden relativ zum Projektverzeichnis gelesen.
- Alle **69 Aktionen** aus **20 Modulen** sind über echte Menüs erreichbar.
  Eingaben erfolgen mit Nutzer-/Werte-Auswahl und Formularen; keine Platzhalter,
  die für die eigentliche Arbeit nur weitere Slash-Befehle nennen.
- Verkauf: funktionierender Warenkorb und lokale, gemeinsame Buchung aller
  Artikel. Abrechnung: atomare Zuordnung offener Verkäufe/VIP-Umsätze und
  Aktualisierung der Firmenkasse, auch bei gleichzeitigen Klicks.
- Warehouse: gleichzeitige Bestätigung derselben Lieferung erhöht das Lager
  nur einmal. Mengen, Beträge, Datum und Uhrzeit werden geprüft.
- Security-Quellmodul ergänzt. Tanzbuchung und Umsatz sind eine Transaktion;
  aktive Doppelbuchungen desselben Tänzers werden abgewiesen.
- Zentrale Hintergrundaufgabe beendet abgelaufene Tanz-Sessions und lange
  Schichten; keine doppelt gestarteten Auto-Logout-Schleifen.
- Rechteprüfung gilt auch für Menüaufrufe und nachträglich entzogene Rollen.
  VIP-Kunden werden nicht als Mitarbeiter behandelt. Interne Daten bleiben auf
  den konfigurierten Server beschränkt.
- Server-Einrichtung löscht keine vorhandenen Rollen und zerstört damit keine
  Rollenzuordnungen. Kanal-Aufräumen verschont fremde Bots und aktive Menüs.
- Starter überschreibt `.env` nicht durch Shell-Variablen und hängt nicht in
  einer Neustartschleife. Pakete sind festgelegt; Installation wird bestätigt.
- Externe OpenAI-/Sheets-Aufrufe sind ausdrücklich optional und standardmäßig
  deaktiviert. Es gibt keinen ungefragten kostenpflichtigen Ersatzanbieter.

## Ausgeführt

- Python **3.12**, discord.py **2.6.4**, aiosqlite **0.21.0**; vollständige
  Paketversionen in `requirements.txt`. `pip check` ohne Abhängigkeitskonflikte.
- **33 Offline-Integrationstests bestanden**, darunter echte SQLite-Transaktionen,
  parallele Abrechnung/Lagerzugänge, Warenkorb und Mengenformular, echte
  discord.Member-Auswahl plus Dienstplanformular, Rollenentzug, Serverbindung,
  alte Datenbankschemata, Dienstbonus, Timer und getrennte externe Integrationen.
- Alle registrierten Aktionen und zugehörigen Menü-/Formularkomponenten wurden
  mit der tatsächlichen discord.py-Bibliothek erzeugt und serialisiert.
- Zahlreiche Lese-/Berichtsaktionen direkt gegen Testdaten und eine simulierte
  Discord-Antwortschnittstelle ausgeführt; Discord-Größenlimits dabei geprüft.
- Migration und anschließender Start aller Module zusätzlich auf einer privaten
  Kopie der tatsächlich hochgeladenen Datenbank ausgeführt. Alle vorhandenen
  Tabellen behielten ihre Zeilenanzahl; `PRAGMA integrity_check` ergab `ok`.
  Die hochgeladene Original-Datenbank blieb bytegenau unverändert und wird nicht über GitHub verteilt.
- Kein Login bei Discord, keine Nachrichten an echte Nutzer, keine Verwendung
  des hochgeladenen Bot-Tokens und keine Veröffentlichung privater Bot-Dateien.

## Grenzen

Die Tests ersetzen keinen Live-Test mit Discord, echten Serverrechten und dem
Windows-Rechner. Der Windows-Starter wurde hier nicht auf Windows ausgeführt.
Microsoft Defender ist in dieser Linux-Umgebung nicht verfügbar; keine Aussage
„virenfrei“ oder Bestätigung eines Fehlalarms. Externe OpenAI-, Google-Sheets-
und Apps-Script-Aufrufe sind hier nicht live getestet. Ein erfolgreicher lokaler
Verkauf beweist keine erfolgreiche Sheets-Kopie und keine reale Auszahlung.
Historische doppelte Abrechnungen werden nicht rückwirkend gelöscht oder
umgebucht. Provisionsregeln und Security-Stundenlohn vor produktiver Verwendung
prüfen. Das Paket ist kein Ersatz für sämtliche proprietären KI-Modelle und
verspricht keine unbegrenzte kostenlose externe API-Nutzung.

## Kanalmenüs und Bereinigung

- 13 gespeicherte Kanalzuordnungen mit passenden Direktbuttons, darunter getrennte
  Bestell- und Lagerkanäle. `/panel` richtet sie ein; die Optionen sind über
  `/menues-einrichten` oder das Hauptmenü erreichbar.
- Menü-IDs werden gespeichert, eigene fehlende Menüs nach Neustart ersetzt,
  verfügbare Pin-Rechte genutzt. Bündelung begrenzt neue Menüposts auf ca.
  einen je 15 Sekunden und Kanal. Discord bietet keine schwebenden Menüs.
- Interaktionsantworten sind privat; einfache Ergebnisse werden nach ca. zwei
  Minuten entfernt. Nur neu eingegangene öffentliche Arbeitsnachrichten werden
  bei aktivierter Bereinigung nach ca. zehn Sekunden entfernt.
- Alte Chatverläufe, angeheftete Nutzernachrichten, fremde Bots, Webhooks und
  unregistrierte Kanäle sind von der Automatik ausgenommen. Getrennte Protokolle
  und SQLite-Buchungen bleiben erhalten.
- Zusätzliche Tests simulieren echte Discord-Nachrichtensemantik bei Zuordnung,
  direkten privaten Buttons, fehlenden Rechten, parallelem Nachrücken, Pin-
  Meldungen, Neustart/Wiederherstellung, nachträglichem Anheften von Nutzerdaten,
  Stoppen der Automatik, Protokolltrennung und unveränderten Buchungen.
- Die Discord-Netzwerkaufrufe sind simuliert. Pin-Rechte, Gateway-Ereignisse und
  Ratenbegrenzungen sind auf einem echten Server weiterhin zu prüfen.
