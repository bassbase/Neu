from utils.clock import utcnow
import discord
from datetime import datetime


def _find(guild: discord.Guild, name: str = "kasse"):
    ch = discord.utils.get(guild.text_channels, name=name)
    return ch or next((c for c in guild.text_channels if name in c.name.lower()), None)


async def post_kasse(guild: discord.Guild | None, title: str, description: str, color: int = 0x2ECC71):
    """Schreibt einen Eintrag in #kasse. Nur der Bot schreibt dort."""
    if guild is None:
        return
    channel = _find(guild)
    if not channel:
        return
    embed = discord.Embed(title=title, description=description, color=color, timestamp=discord.utils.utcnow())
    try:
        await channel.send(embed=embed)
    except Exception as e:
        print(f"Kasse-Log Fehler: {e}")
