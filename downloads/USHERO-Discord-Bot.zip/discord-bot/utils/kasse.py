"""Kompatibler Zugang zum getrennten Kassenprotokoll."""
from utils.logging_ch import post_kasse
