"""Protokolle bleiben getrennt von bereinigten Arbeitskanaelen."""
import discord
import aiosqlite
from utils.database import DB_PATH
from utils.config import CONFIG
from utils.panel_specs import normalize


async def send_audit(guild,content=None,*,embed=None,preferred=()):
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            managed={r[0] for r in await (await db.execute('SELECT channel_id FROM channel_panels WHERE guild_id=?',(guild.id,))).fetchall()}
        except aiosqlite.OperationalError:managed=set()
    names=[*preferred,'audit-logs','bot-logs']
    seen=set()
    for raw in names:
        name=CONFIG.get('log_channels',{}).get(raw,raw)
        channels=[c for c in guild.text_channels if normalize(c.name)==normalize(name) and c.id not in managed]
        if len(channels)!=1:continue
        channel=channels[0]
        if channel.id in seen:continue
        seen.add(channel.id)
        try:
            await channel.send(content=content,embed=embed,allowed_mentions=discord.AllowedMentions.none())
            return True
        except discord.HTTPException:continue
    # Datenbankbuchungen bleiben erhalten, wenn kein Protokollkanal verfuegbar ist.
    return False


async def post_log(guild,kind,title,lines,color=0x8B5CF6):
    embed=discord.Embed(title=title,color=color,timestamp=discord.utils.utcnow())
    for key,value in list(lines.items())[:25]:embed.add_field(name=str(key)[:256],value=str(value)[:1024],inline=True)
    return await send_audit(guild,embed=embed,preferred=(kind,'kasse'))


async def post_kasse(guild,text,embed=None):
    return await send_audit(guild,text or None,embed=embed,preferred=('kasse',))
