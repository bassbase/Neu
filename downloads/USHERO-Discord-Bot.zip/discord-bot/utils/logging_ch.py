"""Posts structured logs into dedicated channels."""
from utils.clock import utcnow
import discord
from datetime import datetime
import json

from utils.config import CONFIG

LOG_MAP = CONFIG.get("log_channels", {})


def _find(guild: discord.Guild, key: str):
    name = LOG_MAP.get(key, key)
    ch = discord.utils.get(guild.text_channels, name=name)
    if ch:
        return ch
    return next((c for c in guild.text_channels if name.lower() in c.name.lower()), None)


async def post_log(guild: discord.Guild, kind: str, title: str, lines: dict, color: int = 0x8B5CF6):
    ch = _find(guild, kind)
    if not ch:
        ch = _find(guild, "kasse")
    if not ch:
        return
    embed = discord.Embed(title=title, color=color, timestamp=discord.utils.utcnow())
    for k, v in lines.items():
        embed.add_field(name=str(k), value=str(v)[:1024], inline=True)
    try:
        await ch.send(embed=embed)
    except Exception:
        pass


async def post_kasse(guild: discord.Guild, text: str, embed: discord.Embed | None = None):
    ch = _find(guild, "kasse")
    if not ch:
        return
    try:
        if embed:
            await ch.send(content=text or None, embed=embed)
        else:
            await ch.send(text)
    except Exception:
        pass
