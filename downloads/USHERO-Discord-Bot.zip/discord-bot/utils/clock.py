"""Datenbankzeit bleibt UTC ohne Suffix fuer die Kompatibilitaet alter Eintraege."""
from datetime import datetime, timezone


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)
