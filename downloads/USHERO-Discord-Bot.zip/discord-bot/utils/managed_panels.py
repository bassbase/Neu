"""Ein registriertes Kanalmenue; neue Arbeitsnachrichten begrenzt bereinigen."""
import asyncio
from collections import OrderedDict
import logging
import time
import discord
from utils.panel_store import PanelStore
from utils.panel_specs import SPECS
from utils.menu_ui import server_allowed,HomeView,home_embed,CATEGORIES

MARKER='USHERO · KANALMENÜ · '


class PanelManager:
    def __init__(self,bot,view_factory,*,clock=time.monotonic):
        self.bot=bot;self.view_factory=view_factory;self.clock=clock;self.store=PanelStore()
        self.records={};self.locks={};self.pending=OrderedDict();self.dirty=set();self.last_post={}
        self.min_repost=15;self.delete_delay=10

    async def load(self):
        await self.store.init()
        self.records={r['channel_id']:r for r in await self.store.all() if r['panel_key'] in SPECS}
        self.dirty.update(self.records)

    def lock(self,channel_id):
        return self.locks.setdefault(channel_id,asyncio.Lock())

    def owned_menu(self,message):
        if not self.bot.user or message.author.id!=self.bot.user.id: return False
        return any((getattr(embed.footer,'text',None) or '').startswith(MARKER) for embed in message.embeds)

    def legacy_menu(self,message):
        if not self.bot.user or message.author.id!=self.bot.user.id:return False
        if not any('USHERO' in (embed.title or '').upper() for embed in message.embeds):return False
        return any(str(getattr(child,'custom_id','')).startswith(('ushero','menu_','panel_'))
                   for row in message.components for child in getattr(row,'children',()))

    def embed(self,key,clean):
        spec=SPECS[key]
        if key=='home': embed=home_embed()
        else:
            emoji,title=CATEGORIES[spec.area]
            if key=='lager': title='Lagerbestand'
            embed=discord.Embed(title=f'{emoji} USHERO · {title}',description='**Wähle deine Aktion direkt hier.**\nFormulare und Ergebnisse sind nur für dich sichtbar.',color=0xEB459E)
        if clean:
            embed.description+='\n\n🧹 Neue öffentliche Chatnachrichten werden nach etwa 10 Sekunden entfernt. Buchungen und Protokolle bleiben erhalten.'
        embed.set_footer(text=MARKER+key+' · '+('Arbeitskanal ohne Chatverlauf' if clean else 'Menü bleibt verfügbar'))
        return embed

    async def post(self,channel,key,*,clean=True,force=False,expected=None):
        if key not in SPECS:raise ValueError('Unbekannter Menübereich.')
        if not server_allowed(self.bot,channel.guild):raise ValueError('Kanal liegt nicht auf dem konfigurierten Server.')
        permissions=channel.permissions_for(channel.guild.me)
        if not (permissions.view_channel and permissions.send_messages and permissions.embed_links and permissions.read_message_history):
            raise ValueError('Bot braucht Kanal ansehen, Nachrichten senden, Verlauf lesen und Links einbetten.')
        clean=bool(clean and SPECS[key].clean and permissions.manage_messages)
        async with self.lock(channel.id):
            record=self.records.get(channel.id)
            if expected is not None and record!=expected:return None
            old=None
            if record and record['message_id']:
                try:old=await channel.fetch_message(record['message_id'])
                except discord.NotFound:pass
            if old is not None and not self.owned_menu(old):
                raise ValueError('Gespeicherte Nachricht ist kein eigenes registriertes USHERO-Menü.')
            view=HomeView() if key=='home' else self.view_factory(key)
            embed=self.embed(key,clean)
            if old is not None and not force:
                await old.edit(embed=embed,view=view)
                message=old
            else:
                message=await channel.send(embed=embed,view=view)
            saved={'guild_id':channel.guild.id,'channel_id':channel.id,'panel_key':key,'message_id':message.id,'clean_chat':int(clean)}
            try:await self.store.save(saved)
            except Exception:
                if message is not old:
                    try:await message.delete()
                    except discord.HTTPException:pass
                raise
            self.records[channel.id]=saved
            self.last_post[channel.id]=self.clock()
            self.dirty.discard(channel.id)
            pinned=True
            try:
                if not message.pinned:await message.pin(reason='USHERO-Kanalmenü')
            except discord.HTTPException:pinned=False
            if old is not None and old.id!=message.id:
                try:await old.delete()
                except discord.HTTPException:pass
            return {'clean':clean,'pinned':pinned,'message_id':message.id}

    async def remove_duplicate_menus(self,channel):
        record=self.records.get(channel.id)
        if not record:return
        async with self.lock(channel.id):
            async for message in channel.history(limit=50):
                if message.id==record['message_id']:continue
                if self.owned_menu(message) or self.legacy_menu(message):
                    try:await message.delete()
                    except discord.HTTPException:pass

    async def received(self,message):
        channel_id=message.channel.id
        record=self.records.get(channel_id)
        if not record or not server_allowed(self.bot,message.guild):return
        if message.id==record['message_id'] or self.owned_menu(message):return
        own=bool(self.bot.user and message.author.id==self.bot.user.id)
        pin_notice=message.type==discord.MessageType.pins_add and own
        if not pin_notice:self.dirty.add(channel_id)
        if message.pinned or getattr(message,'webhook_id',None):return
        if not pin_notice:
            if not record['clean_chat']:return
            if message.type not in (discord.MessageType.default,discord.MessageType.reply):return
            if message.author.bot and not own:return
            if message.components:return
        if len(self.pending)<2000:
            self.pending[(channel_id,message.id)]=(self.clock()+(2 if pin_notice else self.delete_delay),message,pin_notice)

    async def deleted(self,channel_id,message_id):
        record=self.records.get(channel_id)
        if record and record['message_id']==message_id:
            self.dirty.add(channel_id)
            self.last_post.pop(channel_id,None)

    async def unregister(self,channel_id):
        await self.store.remove(channel_id)
        self.records.pop(channel_id,None);self.dirty.discard(channel_id)
        for key in list(self.pending):
            if key[0]==channel_id:self.pending.pop(key,None)

    async def refresh(self,channel_id):
        record=self.records.get(channel_id)
        if not record:return
        channel=self.bot.get_channel(channel_id)
        if channel is None or not server_allowed(self.bot,channel.guild):return
        async with self.lock(channel_id):
            latest=None
            async for message in channel.history(limit=1):latest=message
            if latest and latest.id==record['message_id'] and self.owned_menu(latest):
                await latest.edit(embed=self.embed(record['panel_key'],bool(record['clean_chat'])),view=HomeView() if record['panel_key']=='home' else self.view_factory(record['panel_key']))
                if not latest.pinned:
                    try:await latest.pin(reason='USHERO-Kanalmenü wieder anheften')
                    except discord.HTTPException:pass
                self.dirty.discard(channel_id)
                return
        # post() nimmt denselben Lock; kein verschachtelter Lock.
        await self.post(channel,record['panel_key'],clean=bool(record['clean_chat']),force=True,expected=dict(record))
        await self.remove_duplicate_menus(channel)

    async def drain(self):
        now=self.clock();processed=0
        for ident,(deadline,message,pin_notice) in list(self.pending.items()):
            if processed>=30:break
            if deadline>now:continue
            processed+=1
            self.pending.pop(ident,None)
            record=self.records.get(ident[0])
            if not record or (not record['clean_chat'] and not pin_notice):continue
            if not server_allowed(self.bot,message.guild) or message.pinned:continue
            if message.id==record['message_id'] or self.owned_menu(message):continue
            try:
                current=await message.channel.fetch_message(message.id)
                if current.pinned or current.components or self.owned_menu(current):continue
                await current.delete()
            except discord.NotFound:pass
            except discord.Forbidden:
                record['clean_chat']=0
                await self.store.save(record)
                logging.warning('USHERO: Chatbereinigung wegen fehlender Rechte angehalten.')
            except discord.HTTPException:pass
        count=0
        for channel_id in list(self.dirty):
            if count>=3:break
            if now-self.last_post.get(channel_id,float('-inf'))<self.min_repost:continue
            # Fehlende Rechte verursachen keine schnelle Wiederholungsschleife.
            self.last_post[channel_id]=now
            try:await self.refresh(channel_id)
            except (discord.HTTPException,ValueError):
                logging.warning('USHERO: Kanalmenü konnte nicht aktualisiert werden; Rechte/Diagnose prüfen.')
            count+=1
