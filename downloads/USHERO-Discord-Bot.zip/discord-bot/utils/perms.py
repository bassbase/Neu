"""Abteilungsrechte und passende Kanalrechte, getrennt von der allgemeinen Personalrolle."""
import discord
from utils.config import CONFIG

MANAGEMENT={'Leitung','Admin','Geschäftsführung','Manager'}
SUPERVISORS={'Schichtleitung'}
AREA_ROLES={
 'verkauf':{'Verkauf'},'warehouse':{'Warehouse'},'vip':{'VIP'},'taenzer':{'Tänzer/in'},
 'security':{'Security'},'buchhaltung':{'Buchhaltung'},'leitung':set(MANAGEMENT),
 'dienst':{'Mitarbeiter','Aushilfe'},'dienstplan':{'Mitarbeiter','Aushilfe'},'lohn':{'Mitarbeiter','Aushilfe'},'ki':set(),
}
OPERATIONS={'verkauf','warehouse','vip','taenzer','security'}
STAFF_ROLES=set().union(*AREA_ROLES.values(),MANAGEMENT,SUPERVISORS)
LEITUNG_ROLES=set(MANAGEMENT)
CANONICAL={'gast':'Gast','mitarbeiter':'Mitarbeiter','verkauf':'Verkauf','warehouse':'Warehouse','vip':'VIP','taenzer':'Tänzer/in','security':'Security','leitung':'Leitung','buchhaltung':'Buchhaltung','schichtleitung':'Schichtleitung'}


def role_names(member):
    names={r.name for r in getattr(member,'roles',[])}
    for key,canonical in CANONICAL.items():
        configured=CONFIG.get('roles',{}).get(key,canonical)
        if configured in names:names.add(canonical)
    return names


def role_area(role,area):
    holder=type('RoleHolder',(),{'roles':[role]})()
    names=role_names(holder)
    ident=str(getattr(role,'id',''))
    configured={str(v) for v in CONFIG.get('area_role_ids',{}).get(area,[])}
    if ident and ident in configured:return True
    if area=='ki':return False
    if names & MANAGEMENT:return True
    if area in ('home','dienst','dienstplan','lohn'):
        return bool(names & STAFF_ROLES) or any(ident in {str(v) for v in ids} for ids in CONFIG.get('area_role_ids',{}).values())
    if area=='info':return True
    if area=='stats':area='buchhaltung'
    if area in OPERATIONS and names & SUPERVISORS:return True
    return bool(names & AREA_ROLES.get(area,set()))


def is_owner(member):return bool(member and getattr(member,'guild',None)) and member.id==member.guild.owner_id

def is_admin(member):return bool(member and getattr(member,'guild',None)) and (is_owner(member) or member.guild_permissions.administrator)

def is_staff(member):
    return is_admin(member) or bool(role_names(member)&STAFF_ROLES) or any(role_area(r,'home') for r in getattr(member,'roles',[]))

def is_leitung(member):return is_admin(member) or bool(role_names(member)&MANAGEMENT)


def can_use_area(member,area):
    if not member or not getattr(member,'guild',None):return False
    if area=='ki':return is_owner(member)
    if area=='info':return True
    if is_admin(member):return True
    return any(role_area(role,area) for role in getattr(member,'roles',[]))


def primary_areas(member):
    return [a for a in ('verkauf','warehouse','vip','taenzer','security','buchhaltung','dienst','dienstplan','leitung','ki','info') if can_use_area(member,a)]


def deny_guest_message():return '🚫 Dieser Bereich ist nur für die zuständige Abteilung freigegeben.'


async def channel_overwrites(guild,area,existing=None):
    """Entfernt breite Sichtfreigaben, ohne Rollen oder fremde Nachrichten zu loeschen."""
    current={target:discord.PermissionOverwrite.from_pair(*overwrite.pair()) for target,overwrite in (existing or {}).items()}
    everyone=current.get(guild.default_role,discord.PermissionOverwrite())
    everyone.view_channel=(area=='info');everyone.send_messages=False
    everyone.read_message_history=(True if area=='info' else None)
    current[guild.default_role]=everyone
    roles=set(guild.roles)
    for target in list(current):
        if target is guild.default_role or target is guild.me:continue
        overwrite=current[target]
        if target in roles:
            overwrite.view_channel=bool(role_area(target,area))
            overwrite.read_message_history=True if overwrite.view_channel else None
            overwrite.send_messages=False
            overwrite.use_application_commands=True if overwrite.view_channel else None
        else:
            # Ein altes persoenliches Allow darf Abteilungsrechte nicht umgehen.
            for flag in ('view_channel','read_message_history','send_messages','use_application_commands'):
                setattr(overwrite,flag,None)
            if overwrite.is_empty():current.pop(target)
    for role in guild.roles:
        if role is guild.default_role or not role_area(role,area):continue
        overwrite=current.get(role,discord.PermissionOverwrite())
        overwrite.view_channel=True;overwrite.read_message_history=True;overwrite.send_messages=False;overwrite.use_application_commands=True
        current[role]=overwrite
    if area=='ki':
        owner=guild.get_member(guild.owner_id)
        if owner is None:owner=await guild.fetch_member(guild.owner_id)
        current[owner]=discord.PermissionOverwrite(view_channel=True,read_message_history=True,send_messages=False,use_application_commands=True)
    if guild.me:
        own=current.get(guild.me,discord.PermissionOverwrite())
        own.view_channel=True;own.read_message_history=True;own.send_messages=True;own.embed_links=True;own.use_application_commands=True
        current[guild.me]=own
    if len(current)>100:raise ValueError('Zu viele Kanalüberschreibungen; bitte alte Einzelrechte prüfen.')
    return current


def admin_role_warning(guild):
    return [r.name for r in guild.roles if getattr(getattr(r,'permissions',None),'administrator',False) and not role_names(type('RoleHolder',(),{'roles':[r]})())&MANAGEMENT]
