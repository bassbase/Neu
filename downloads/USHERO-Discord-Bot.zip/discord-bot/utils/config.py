"""Projektpfade sind unabhaengig vom Arbeitsordner des Starters."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent
CONFIG = {"currency": "$", "embed_color": 0x9B59B6, "roles": {}, "log_channels": {}}
CONFIG.update(json.loads((ROOT / "config.json").read_text(encoding="utf-8-sig")))
MENU = json.loads((ROOT / "data" / "menu.json").read_text(encoding="utf-8-sig"))
