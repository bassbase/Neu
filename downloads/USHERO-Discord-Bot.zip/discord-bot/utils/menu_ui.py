"""Echte Menues fuer alle geladenen Aktionen; keine Slash-Command-Anleitungen."""
import asyncio
import inspect
import logging
import math
import os
import re
from datetime import date, time
import discord
from discord import app_commands
from utils.perms import is_staff, is_leitung, is_owner, can_use_area

CATEGORIES = {
    'verkauf': ('💰', 'Verkauf & Kasse'), 'warehouse': ('📦', 'Warehouse'),
    'vip': ('⭐', 'VIP'), 'taenzer': ('💃', 'Tänzer'), 'security': ('🛡️', 'Security'),
    'dienst': ('⏱️', 'Dienst & Lohn'), 'dienstplan': ('📅', 'Dienstplan'),
    'buchhaltung': ('📒', 'Buchhaltung'), 'leitung': ('⚙️', 'Leitung'),
    'ki': ('🧠', 'KI & Berichte'), 'info': ('ℹ️', 'Info & Bewerbung'),
}
PUBLIC = {'menu','arbeit','hilfe','befehle','unternehmen','wer-darf-was','rang-liste','bewerbung stellen'}
PERSONAL = {'dienst','mein-panel','meine-abrechnungen','rang'}
LEAD = {'panel','panel-channel','channel-sauber','bewerbung liste','stats','daily-report','vip-ablauf','menues-einrichten','menues-status','menues-stop'}
FINANCE = {'firmenkasse','firma-prozent','abrechnungen'}


def server_allowed(client,guild):
    if guild is None: return False
    configured=os.getenv('GUILD_ID','').strip()
    if configured: return configured.isdecimal() and guild.id==int(configured)
    guilds=client.guilds
    return len(guilds)==1 and guilds[0].id==guild.id


def category(command):
    name = command.qualified_name
    top = name.split()[0]
    if top in ('verkauf','verkauf_artikel','preisliste','meine-verkaeufe','verkauf-summe'): return 'verkauf'
    if top in ('warehouse','vip','taenzer','security','dienstplan','ki'): return top
    if top == 'vip-karte' or top == 'vip-ablauf': return 'vip'
    if name in PERSONAL: return 'dienst'
    if name in FINANCE: return 'buchhaltung'
    if name in PUBLIC: return 'info'
    return 'leitung'


def allowed(member, command):
    if not member or not getattr(member,'guild',None): return False
    name = command.qualified_name
    top = name.split()[0]
    if top == 'ki': return is_owner(member)
    if name in PUBLIC: return True
    if name == 'setup': return member.guild_permissions.administrator
    if top == 'diagnose': return is_leitung(member) or member.guild_permissions.manage_guild
    if top == 'warn': return member.guild_permissions.moderate_members or member.guild_permissions.administrator
    if name == 'bewerbung liste': return member.guild_permissions.manage_roles or is_leitung(member)
    if name in LEAD: return is_leitung(member) or member.guild_permissions.manage_guild
    if name in FINANCE: return can_use_area(member,'buchhaltung')
    if name == 'warehouse korrigieren': return is_leitung(member) or member.guild_permissions.manage_guild
    if top in ('warehouse','vip','taenzer','security') or top.startswith('verkauf') or top in ('vip-karte','preisliste','meine-verkaeufe','verkauf-summe'):
        area = 'verkauf' if top.startswith('verkauf') or top in ('preisliste','meine-verkaeufe','verkauf-summe') else ('vip' if top=='vip-karte' else top)
        return can_use_area(member,area)
    return is_staff(member)


async def reply(interaction, content=None, **kwargs):
    kwargs['ephemeral'] = True
    delay=kwargs.pop('delete_after',None if kwargs.get('view') is not None else 120)
    if interaction.response.is_done():
        message=await interaction.followup.send(content,wait=True,**kwargs)
        if delay is not None and message is not None:
            try:await message.delete(delay=delay)
            except discord.HTTPException:pass
        return message
    return await interaction.response.send_message(content,delete_after=delay,**kwargs)


async def show_error(interaction, error):
    error = getattr(error,'original',error)
    diagnose=interaction.client.get_cog('Diagnose')
    if diagnose: diagnose.record_error(type(error).__name__)
    if isinstance(error, (ValueError, app_commands.CheckFailure)):
        message = str(error) or 'Keine Berechtigung für diese Aktion.'
    elif isinstance(error, discord.Forbidden):
        message = 'Dem Bot fehlen Discord-Rechte für diese Aktion. Bitte die Bot-Rolle prüfen.'
    else:
        logging.error('Aktion fehlgeschlagen (%s)',type(error).__name__)
        message = 'Die Aktion konnte nicht abgeschlossen werden. Diagnose öffnen; nicht mehrfach buchen, wenn bereits gespeichert wurde.'
    await reply(interaction, '❌ '+message[:1700])


async def invoke(interaction, command, values):
    if not server_allowed(interaction.client,interaction.guild):
        raise app_commands.CheckFailure('Bitte GUILD_ID auf diesen Server einstellen. Eine Datenbank ist für genau einen Server bestimmt.')
    if not allowed(interaction.user,command):
        raise app_commands.CheckFailure('Deine Rolle darf diese Aktion nicht ausführen.')
    for predicate in command.checks:
        result = predicate(interaction)
        if inspect.isawaitable(result): result = await result
        if not result: raise app_commands.CheckFailure('Keine Berechtigung.')
    parent = command.parent
    while parent:
        if not await parent.interaction_check(interaction): raise app_commands.CheckFailure('Keine Berechtigung.')
        parent = parent.parent
    validate(values)
    if command.binding is None:
        await command.callback(interaction, **values)
    else:
        await command.callback(command.binding, interaction, **values)


def validate(values):
    for key, value in values.items():
        if value is None: continue
        if isinstance(value, app_commands.Choice): value=value.value
        if isinstance(value,(int,float)):
            if not math.isfinite(value): raise ValueError('Bitte eine endliche Zahl eingeben.')
            if key in ('menge','quantity') and not 1 <= value <= 10000: raise ValueError('Menge: 1 bis 10000.')
            if key in ('preis','amount','betrag') and not 0 < value <= 1_000_000_000: raise ValueError('Betrag muss positiv und höchstens 1 Milliarde sein.')
            if key in ('anzahl','limit') and not 1 <= value <= 25: raise ValueError('Anzahl: 1 bis 25.')
            if (key.endswith('_id') or key in ('bestell_nr','eintrag_id')) and value < 1: raise ValueError('Bitte eine gültige positive Nummer eingeben.')
            if key=='neuer_bestand' and value < 0: raise ValueError('Bestand darf nicht negativ sein.')
        if key=='tag' and value:
            try: date.fromisoformat(value)
            except ValueError: raise ValueError('Datum bitte als YYYY-MM-DD eingeben.') from None
        if key in ('von','bis') and value:
            if not re.fullmatch(r'\d{2}:\d{2}',value): raise ValueError('Uhrzeit bitte als HH:MM eingeben.')
            try: time.fromisoformat(value)
            except ValueError: raise ValueError('Ungültige Uhrzeit.') from None


class OwnedView(discord.ui.View):
    def __init__(self,user_id,**kwargs):
        super().__init__(timeout=600,**kwargs)
        self.user_id=user_id

    async def interaction_check(self,interaction):
        if not server_allowed(interaction.client,interaction.guild):
            await reply(interaction,'Bitte GUILD_ID für diesen Server in .env einstellen.')
            return False
        if interaction.user.id != self.user_id:
            await reply(interaction,'Dieses persönliche Menü gehört einem anderen Nutzer.')
            return False
        return True

    async def on_error(self,interaction,error,item):
        await show_error(interaction,error)


async def open_home(interaction):
    if not server_allowed(interaction.client,interaction.guild):
        return await reply(interaction,'Bitte GUILD_ID für diesen Server in .env einstellen.')
    await reply(interaction,embed=home_embed(),view=HomeView())


def home_embed():
    embed=discord.Embed(title='✦ USHERO · Nightclub',
        description='**Dein Arbeitsplatz. Alles über ein Menü.**\n\n🟢 Dienst starten → Bereich öffnen → 🔴 Dienst beenden → abrechnen.\nWähle einen Bereich. Aktionen öffnen sich als Auswahl oder Formular.', color=0xEB459E)
    embed.set_footer(text='USHERO · Persönliche Antworten · Rollen steuern den Zugriff')
    return embed


class HomeView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        for start,label in ((True,'🟢 Dienst starten'),(False,'🔴 Dienst beenden')):
            button=discord.ui.Button(label=label,custom_id='ushero_ein' if start else 'ushero_aus',row=0,style=discord.ButtonStyle.success if start else discord.ButtonStyle.danger)
            async def duty(interaction,start=start):
                from cogs.schicht import duty_action
                await duty_action(interaction,start)
            button.callback=duty
            self.add_item(button)
        for index,(key,(emoji,label)) in enumerate(CATEGORIES.items()):
            button=discord.ui.Button(label=label,emoji=emoji,custom_id='ushero:area:'+key,row=1+index//4,
                                     style=discord.ButtonStyle.primary if key!='info' else discord.ButtonStyle.secondary)
            async def open_area(interaction,key=key): await open_category(interaction,key)
            button.callback=open_area
            self.add_item(button)
        install=discord.ui.Button(label='Kanalmenüs einrichten',emoji='🗂️',custom_id='ushero:install-panels',row=4,style=discord.ButtonStyle.secondary)
        async def setup_panels(interaction):
            from cogs.channel_panels import open_action
            await open_action(interaction,'menues-einrichten')
        install.callback=setup_panels
        self.add_item(install)

    async def on_error(self,interaction,error,item):
        await show_error(interaction,error)

    async def interaction_check(self,interaction):
        if server_allowed(interaction.client,interaction.guild): return True
        await reply(interaction,'Bitte GUILD_ID für diesen Server in .env einstellen.')
        return False


async def open_category(interaction,key):
    if not server_allowed(interaction.client,interaction.guild): return await reply(interaction,'Bitte GUILD_ID für diesen Server in .env einstellen.')
    key='buchhaltung' if key=='kasse' else key
    commands=[c for c in interaction.client.tree.walk_commands() if isinstance(c,app_commands.Command) and category(c)==key and allowed(interaction.user,c)]
    if not commands: return await reply(interaction,'❌ Für diesen Bereich hast du keine freigegebenen Aktionen.')
    title=CATEGORIES.get(key,('✦',key))
    embed=discord.Embed(title=f'{title[0]} USHERO · {title[1]}',description='Aktion auswählen. Angaben werden direkt hier abgefragt; du musst keinen Befehl eintippen.',color=0x9B59B6)
    await reply(interaction,embed=embed,view=CategoryView(interaction.user.id,commands))


class CategoryView(OwnedView):
    def __init__(self,user_id,commands):
        super().__init__(user_id)
        for offset in range(0,len(commands),25):
            group=commands[offset:offset+25]
            select=discord.ui.Select(placeholder='Aktion auswählen …',options=[discord.SelectOption(label=c.description[:100],value=c.qualified_name) for c in group])
            async def selected(interaction,select=select,group=group):
                command=next(c for c in group if c.qualified_name==select.values[0])
                if not allowed(interaction.user,command): raise app_commands.CheckFailure('Berechtigung hat sich geändert.')
                action=ActionView(interaction.user.id,command)
                await reply(interaction,embed=action.embed(),view=action)
            select.callback=selected
            self.add_item(select)
        back=discord.ui.Button(label='Hauptmenü',emoji='↩️',style=discord.ButtonStyle.secondary)
        back.callback=open_home
        self.add_item(back)


class ActionView(OwnedView):
    def __init__(self,user_id,command):
        super().__init__(user_id)
        self.command=command
        self.values={}
        self.lock=asyncio.Lock()
        self.executed=False
        self.refresh()

    def embed(self):
        embed=discord.Embed(title='✦ '+self.command.qualified_name,description=self.command.description,color=0x00D9E8)
        if self.command.qualified_name=='setup':
            embed.description+='\n⚠️ Erst mit „Aktion ausführen“ werden fehlende Rollen und Kanäle angelegt. Bestehende Rollen werden nicht gelöscht.'
        if self.command.qualified_name=='menues-einrichten':
            embed.description+='\nNeue öffentliche Nachrichten in eingerichteten Arbeitskanälen werden nach ca. 10 Sekunden entfernt. Buchungen und getrennte Protokolle bleiben erhalten. Die Optionen unten steuern Kanalanlage und Bereinigung.'
        for p in self.command.parameters:
            value=self.values.get(p.name)
            if isinstance(value,app_commands.Choice): value=value.name
            elif hasattr(value,'display_name'): value=value.display_name
            default=('Ja' if p.default else 'Nein') if isinstance(p.default,bool) else p.default
            text=str(value) if value is not None and value!='' else ('Noch erforderlich' if p.required else f'Standard: {default}' if default is not None and default!='' else 'Optional')
            embed.add_field(name=p.display_name,value=text[:180],inline=True)
        embed.set_footer(text='Nur für dich · Prüfe deine Angaben vor dem Ausführen')
        return embed

    def refresh(self):
        self.clear_items()
        text_types={discord.AppCommandOptionType.string,discord.AppCommandOptionType.integer,discord.AppCommandOptionType.number}
        remaining=[p for p in self.command.parameters if p.name not in self.values]
        chosen=next((p for p in remaining if p.choices or p.type not in text_types),None)
        if chosen:
            p=chosen
            if p.choices:
                control=discord.ui.Select(placeholder=p.display_name[:150],options=[discord.SelectOption(label=c.name[:100],value=str(i)) for i,c in enumerate(p.choices)])
                async def change(interaction):
                    self.values[p.name]=p.choices[int(control.values[0])]
                    self.refresh()
                    await interaction.response.edit_message(embed=self.embed(),view=self)
            elif p.type==discord.AppCommandOptionType.boolean:
                control=discord.ui.Select(placeholder=p.display_name[:150],options=[discord.SelectOption(label='Ja',value='yes'),discord.SelectOption(label='Nein',value='no')])
                async def change(interaction):
                    self.values[p.name]=control.values[0]=='yes'
                    self.refresh()
                    await interaction.response.edit_message(embed=self.embed(),view=self)
            elif p.type==discord.AppCommandOptionType.user:
                control=discord.ui.UserSelect(placeholder=p.display_name[:150],min_values=1,max_values=1)
                async def change(interaction):
                    member=control.values[0]
                    if not isinstance(member,discord.Member) or member.guild.id!=interaction.guild.id: raise ValueError('Bitte ein Server-Mitglied auswählen.')
                    self.values[p.name]=member
                    self.refresh()
                    await interaction.response.edit_message(embed=self.embed(),view=self)
            else:
                raise ValueError(f'Nicht unterstütztes Auswahlfeld: {p.name}')
            control.callback=change
            self.add_item(control)
        fields=[p for p in self.command.parameters if not p.choices and p.type in text_types]
        if fields:
            fill=discord.ui.Button(label='Angaben ausfüllen / ändern',emoji='📝',style=discord.ButtonStyle.primary)
            async def edit(interaction):
                await interaction.response.send_modal(ActionModal(self,fields[:5]))
            fill.callback=edit
            self.add_item(fill)
        run=discord.ui.Button(label='Aktion ausführen',emoji='✅',style=discord.ButtonStyle.success,
                              disabled=any(p.required and p.name not in self.values for p in self.command.parameters))
        run.callback=self.run
        self.add_item(run)
        reset=discord.ui.Button(label='Zurücksetzen',style=discord.ButtonStyle.secondary)
        async def clear(interaction):
            self.values.clear(); self.refresh()
            await interaction.response.edit_message(embed=self.embed(),view=self)
        reset.callback=clear
        self.add_item(reset)
        back=discord.ui.Button(label='Hauptmenü',style=discord.ButtonStyle.secondary)
        back.callback=open_home
        self.add_item(back)

    async def run(self,interaction):
        async with self.lock:
            if self.executed: return await reply(interaction,'Diese Aktion wurde bereits ausgeführt. Öffne für eine weitere Aktion das Menü neu.')
            values={p.name:self.values.get(p.name,p.default) for p in self.command.parameters}
            if any(p.required and p.name not in self.values for p in self.command.parameters): raise ValueError('Bitte zuerst alle Pflichtfelder ausfüllen.')
            validate(values)
            self.executed=True
            await invoke(interaction,self.command,values)


class ActionModal(discord.ui.Modal):
    def __init__(self,action,fields):
        super().__init__(title=action.command.qualified_name[:45],timeout=600)
        self.action=action
        self.fields=fields
        for p in fields:
            value=action.values.get(p.name,p.default if not p.required else '')
            field=discord.ui.TextInput(custom_id=p.name,label=p.display_name[:45],placeholder=p.description[:100],required=p.required,
                                       default='' if value is None else str(value),max_length=900 if p.type==discord.AppCommandOptionType.string else 30,
                                       style=discord.TextStyle.paragraph if p.name in ('text','grund','beschreibung','notiz') else discord.TextStyle.short)
            self.add_item(field)

    async def on_submit(self,interaction):
        if not await self.action.interaction_check(interaction): return
        values={}
        for p,field in zip(self.fields,self.children):
            raw=field.value.strip()
            if not raw and not p.required: values[p.name]=p.default; continue
            try:
                value=int(raw) if p.type==discord.AppCommandOptionType.integer else float(raw.replace(',','.')) if p.type==discord.AppCommandOptionType.number else raw
            except ValueError: raise ValueError(f'{p.display_name}: Bitte eine gültige Zahl eingeben.') from None
            values[p.name]=value
        validate(values)
        self.action.values.update(values)
        self.action.refresh()
        await interaction.response.edit_message(embed=self.action.embed(),view=self.action)

    async def on_error(self,interaction,error):
        await show_error(interaction,error)
