"""Registrierte Menüs separat von Buchungen und Protokollen speichern."""
import aiosqlite
from utils.database import DB_PATH


class PanelStore:
    async def init(self):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute('''CREATE TABLE IF NOT EXISTS channel_panels(
                guild_id INTEGER NOT NULL, channel_id INTEGER PRIMARY KEY,
                panel_key TEXT NOT NULL, message_id INTEGER NOT NULL DEFAULT 0,
                clean_chat INTEGER NOT NULL DEFAULT 0)''')
            await db.commit()

    async def all(self):
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row
            return [dict(r) for r in await (await db.execute('SELECT * FROM channel_panels')).fetchall()]

    async def save(self,record):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute('''INSERT INTO channel_panels(guild_id,channel_id,panel_key,message_id,clean_chat)
                VALUES(:guild_id,:channel_id,:panel_key,:message_id,:clean_chat)
                ON CONFLICT(channel_id) DO UPDATE SET guild_id=excluded.guild_id,panel_key=excluded.panel_key,
                message_id=excluded.message_id,clean_chat=excluded.clean_chat''',record)
            await db.commit()

    async def remove(self,channel_id):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute('DELETE FROM channel_panels WHERE channel_id=?',(channel_id,))
            await db.commit()
