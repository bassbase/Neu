from utils.clock import utcnow
import aiosqlite
import os
import math
import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

DB_PATH = os.getenv('USHERO_DB_PATH') or str(Path(__file__).resolve().parent.parent / 'data' / 'bot.db')


def positive_money(value):
    if not math.isfinite(float(value)) or float(value) <= 0 or float(value) > 1_000_000_000:
        raise ValueError('Betrag muss positiv, endlich und hoechstens 1 Milliarde sein.')
    result = round(float(value), 2)
    if result <= 0:
        raise ValueError('Betrag muss mindestens 0,01 sein.')
    return result

async def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    # Backup der vorhandenen DB, bevor erstmals reparierende Migrationen laufen.
    source = Path(DB_PATH)
    backup = source.parent / 'backups' / 'bot-vor-reparatur.db'
    if source.exists() and source.stat().st_size and not backup.exists():
        backup.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(source) as src, sqlite3.connect(backup) as dst:
            src.backup(dst)
    async with aiosqlite.connect(DB_PATH) as db:
        # Mitarbeiter
        await db.execute("""
            CREATE TABLE IF NOT EXISTS employees (
                user_id INTEGER PRIMARY KEY,
                name TEXT,
                role TEXT,
                joined_at TEXT,
                active INTEGER DEFAULT 1
            )
        """)

        # Verkäufe
        await db.execute("""
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                seller_id INTEGER,
                item TEXT,
                amount REAL,
                quantity INTEGER DEFAULT 1,
                buyer_id INTEGER,
                category TEXT DEFAULT 'verkauf',
                created_at TEXT,
                note TEXT
            )
        """)

        # VIP
        await db.execute("""
            CREATE TABLE IF NOT EXISTS vip_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                seller_id INTEGER,
                receiver_id INTEGER,
                amount REAL,
                description TEXT,
                created_at TEXT
            )
        """)

        # Tänzer Sessions
        await db.execute("""
            CREATE TABLE IF NOT EXISTS dance_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dancer_id INTEGER,
                booker_id INTEGER,
                duration_minutes INTEGER,
                price REAL,
                started_at TEXT,
                ends_at TEXT,
                status TEXT DEFAULT 'active',
                channel_id INTEGER,
                message_id INTEGER
            )
        """)

        # Security Dienst
        await db.execute("""
            CREATE TABLE IF NOT EXISTS security_duty (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                started_at TEXT,
                ended_at TEXT,
                pay REAL DEFAULT 0,
                status TEXT DEFAULT 'active',
                note TEXT
            )
        """)

        # Allgemeines Dienstsystem
        await db.execute("""
            CREATE TABLE IF NOT EXISTS duty_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                role TEXT,
                started_at TEXT,
                ended_at TEXT,
                duration_minutes INTEGER,
                pay REAL DEFAULT 0
            )
        """)

        # Warnungen
        await db.execute("""
            CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                moderator_id INTEGER,
                reason TEXT,
                created_at TEXT
            )
        """)

        # Audit / Logs
        await db.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT,
                user_id INTEGER,
                target_id INTEGER,
                details TEXT,
                created_at TEXT
            )
        """)

        # Bewerbungen
        await db.execute("""
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                position TEXT,
                text TEXT,
                status TEXT DEFAULT 'pending',
                created_at TEXT,
                reviewed_by INTEGER,
                reviewed_at TEXT
            )
        """)

        # Schichten (Dienst)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS schichten (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                started_at TEXT,
                ended_at TEXT,
                status TEXT DEFAULT 'aktiv',
                bonus_prozent REAL DEFAULT 10,
                note TEXT
            )
        """)

        await db.commit()
    await migrate_legacy()


async def migrate_legacy():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('BEGIN IMMEDIATE')
        await db.execute('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY)')
        done = await (await db.execute('SELECT 1 FROM schema_migrations WHERE version=1')).fetchone()
        if done:
            return
        additions = {
            'schichten': {'started_at':'TEXT', 'ended_at':'TEXT', 'startzeit':'TEXT', 'endzeit':'TEXT',
                          'dauer':'INTEGER DEFAULT 0', 'bonus_prozent':'REAL DEFAULT 10', 'note':'TEXT'},
            'sales': {'settlement_id':'INTEGER'}, 'vip_entries': {'settlement_id':'INTEGER'},
        }
        for table, columns in additions.items():
            current = {r[1] for r in await (await db.execute(f'PRAGMA table_info({table})')).fetchall()}
            for name, kind in columns.items():
                if name not in current:
                    await db.execute(f'ALTER TABLE {table} ADD COLUMN {name} {kind}')
        await db.execute('UPDATE schichten SET started_at=COALESCE(started_at,startzeit), ended_at=COALESCE(ended_at,endzeit), startzeit=COALESCE(startzeit,started_at), endzeit=COALESCE(endzeit,ended_at)')
        # Alle Historien bleiben erhalten; nur der neueste offene Eintrag bleibt aktiv.
        await db.execute("UPDATE schichten SET status='bereinigt' WHERE status='aktiv' AND id NOT IN (SELECT MAX(id) FROM schichten WHERE status='aktiv' GROUP BY user_id)")
        await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS one_active_shift ON schichten(user_id) WHERE status='aktiv'")
        tables = {r[0] for r in await (await db.execute("SELECT name FROM sqlite_master WHERE type='table'")).fetchall()}
        if 'abrechnungen' in tables:
            for table in ('sales', 'vip_entries'):
                await db.execute(f'''UPDATE {table} SET settlement_id=(SELECT MAX(id) FROM abrechnungen a WHERE a.user_id={table}.seller_id)
                    WHERE created_at <= (SELECT MAX(created_at) FROM abrechnungen a WHERE a.user_id={table}.seller_id)''')
        await db.execute('INSERT INTO schema_migrations(version) VALUES(1)')
        await db.commit()


async def log_audit(action: str, user_id: int, target_id: int = None, details: str = ""):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO audit_logs (action, user_id, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)",
            (action, user_id, target_id, details, utcnow().isoformat())
        )
        await db.commit()


async def add_sale(seller_id: int, item: str, amount: float, quantity: int = 1,
                   buyer_id: int = None, category: str = "verkauf", note: str = ""):
    amount = positive_money(amount)
    if not isinstance(quantity, int) or not 1 <= quantity <= 10000:
        raise ValueError('Menge muss zwischen 1 und 10000 liegen.')
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO sales (seller_id, item, amount, quantity, buyer_id, category, created_at, note)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (seller_id, item, amount, quantity, buyer_id, category, utcnow().isoformat(), note)
        )
        await db.commit()


async def get_sales_sum(category: str = None, seller_id: int = None) -> float:
    async with aiosqlite.connect(DB_PATH) as db:
        query = "SELECT SUM(amount * quantity) FROM sales WHERE 1=1"
        params = []
        if category:
            query += " AND category = ?"
            params.append(category)
        if seller_id:
            query += " AND seller_id = ?"
            params.append(seller_id)
        async with db.execute(query, params) as cursor:
            row = await cursor.fetchone()
            return row[0] or 0.0


async def get_sales(category: str = None, limit: int = 20, seller_id: int = None) -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        query = "SELECT * FROM sales WHERE 1=1"
        params = []
        if category:
            query += " AND category = ?"
            params.append(category)
        if seller_id is not None:
            query += ' AND seller_id = ?'
            params.append(seller_id)
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]


async def add_vip(seller_id: int, receiver_id: int, amount: float, description: str = ""):
    amount = positive_money(amount)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO vip_entries (seller_id, receiver_id, amount, description, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (seller_id, receiver_id, amount, description, utcnow().isoformat())
        )
        await db.commit()


async def get_vip_sum(seller_id: int = None) -> float:
    async with aiosqlite.connect(DB_PATH) as db:
        if seller_id:
            async with db.execute("SELECT SUM(amount) FROM vip_entries WHERE seller_id = ?", (seller_id,)) as c:
                row = await c.fetchone()
                return row[0] or 0.0
        async with db.execute("SELECT SUM(amount) FROM vip_entries") as c:
            row = await c.fetchone()
            return row[0] or 0.0


async def start_dance(dancer_id: int, booker_id: int, duration: int, price: float,
                      channel_id: int = None, message_id: int = None) -> int:
    from datetime import timedelta
    price = positive_money(price)
    if duration not in (10, 15, 30):
        raise ValueError('Tanzdauer muss 10, 15 oder 30 Minuten sein.')
    started = utcnow()
    ends = started + timedelta(minutes=duration)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('BEGIN IMMEDIATE')
        if await (await db.execute("SELECT id FROM dance_sessions WHERE dancer_id=? AND status='active'", (dancer_id,))).fetchone():
            raise ValueError('Für diesen Tänzer läuft bereits eine Session.')
        cursor = await db.execute(
            """INSERT INTO dance_sessions 
               (dancer_id, booker_id, duration_minutes, price, started_at, ends_at, status, channel_id, message_id)
               VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)""",
            (dancer_id, booker_id, duration, price, started.isoformat(), ends.isoformat(), channel_id, message_id)
        )
        await db.execute("INSERT INTO sales(seller_id,item,amount,quantity,buyer_id,category,created_at,note) VALUES(?,?,?,1,?,'taenzer',?,?)",
                         (dancer_id, f'Tanz {duration}min', price, booker_id, started.isoformat(), f'Session #{cursor.lastrowid}'))
        await db.commit()
        return cursor.lastrowid


async def get_active_dances() -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM dance_sessions WHERE status = 'active'") as c:
            rows = await c.fetchall()
            return [dict(r) for r in rows]


async def finish_dance(session_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE dance_sessions SET status = 'finished' WHERE id = ?", (session_id,)
        )
        await db.commit()


async def start_security_duty(user_id: int, note: str = "") -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            """INSERT INTO security_duty (user_id, started_at, status, note)
               VALUES (?, ?, 'active', ?)""",
            (user_id, utcnow().isoformat(), note)
        )
        await db.commit()
        return cursor.lastrowid


async def end_security_duty(user_id: int, pay: float) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT id FROM security_duty WHERE user_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1",
            (user_id,)
        ) as c:
            row = await c.fetchone()
            if not row:
                return False
        await db.execute(
            """UPDATE security_duty SET ended_at = ?, pay = ?, status = 'finished' WHERE id = ?""",
            (utcnow().isoformat(), pay, row[0])
        )
        await db.commit()
        return True


async def get_security_sum(user_id: int = None) -> float:
    async with aiosqlite.connect(DB_PATH) as db:
        if user_id:
            async with db.execute("SELECT SUM(pay) FROM security_duty WHERE user_id = ? AND status = 'finished'", (user_id,)) as c:
                row = await c.fetchone()
                return row[0] or 0.0
        async with db.execute("SELECT SUM(pay) FROM security_duty WHERE status = 'finished'") as c:
            row = await c.fetchone()
            return row[0] or 0.0


async def add_warning(user_id: int, moderator_id: int, reason: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO warnings (user_id, moderator_id, reason, created_at) VALUES (?, ?, ?, ?)",
            (user_id, moderator_id, reason, utcnow().isoformat())
        )
        await db.commit()


async def get_warnings(user_id: int) -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM warnings WHERE user_id = ? ORDER BY created_at DESC", (user_id,)) as c:
            rows = await c.fetchall()
            return [dict(r) for r in rows]
