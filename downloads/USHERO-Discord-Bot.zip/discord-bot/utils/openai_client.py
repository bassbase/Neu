"""Externe OpenAI-API nur nach ausdruecklichem Opt-in; keine Wiederholungsversuche."""
import os
import aiohttp


def has_openai():
    return os.getenv('ENABLE_OPENAI','false').lower()=='true' and bool(os.getenv('OPENAI_API_KEY','').strip())


async def _request(endpoint,payload):
    if not has_openai(): return None
    headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'].strip()}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30)) as session:
            async with session.post('https://api.openai.com/v1/'+endpoint,headers=headers,json=payload) as response:
                if response.status!=200: return None
                return await response.json()
    except (aiohttp.ClientError,TimeoutError,ValueError):
        return None


async def chat_completion(system,user,model=None):
    result=await _request('chat/completions',{'model':model or os.getenv('OPENAI_CHAT_MODEL','gpt-4o-mini'),
        'messages':[{'role':'system','content':system},{'role':'user','content':user}], 'max_tokens':800,'temperature':0.7})
    try: return result['choices'][0]['message']['content']
    except (TypeError,KeyError,IndexError): return None


async def moderate_text(text):
    result=await _request('moderations',{'model':'omni-moderation-latest','input':text})
    try:
        item=result['results'][0]
        return {'flagged':item['flagged'],'categories':{k:v for k,v in item['categories'].items() if v}}
    except (TypeError,KeyError,IndexError): return None


async def generate_image(prompt,size='1024x1024'):
    result=await _request('images/generations',{'model':os.getenv('OPENAI_IMAGE_MODEL','dall-e-3'),'prompt':prompt,'size':size,'n':1})
    try: return result['data'][0]['url']
    except (TypeError,KeyError,IndexError): return None
