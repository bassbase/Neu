"""Einheitliches USHERO-Neon-Design; Helfer liefern echte Discord-Embeds."""
import discord

C_NEON_PNK = 0xEB459E
C_NEON_CYN = 0x00D9E8


def box(title, subtitle="", *lines, color=None):
    return "\n".join([f"**{title}**", subtitle, *map(str, lines)])[:4000]


def stempel_ein(user):
    return discord.Embed(title="🟢 Dienst gestartet", description=f"{user.mention} ist jetzt im Dienst.", color=0x57F287)


def stempel_aus(user, dauer):
    return discord.Embed(title="🔴 Dienst beendet", description=f"{user.mention} · Dauer: **{dauer}**", color=C_NEON_PNK)
