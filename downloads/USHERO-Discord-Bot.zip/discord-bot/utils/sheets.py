"""Sheets-Verbindung mit klarer Trennung von Deployment-ID und geheimem Schluessel."""
import asyncio
import json
import os
import re
import aiohttp


def connection_error():
    if os.getenv('ENABLE_SHEETS','false').lower()!='true':return 'Sheets ist deaktiviert. Sheets-verbinden.bat ausführen und Bot neu starten.'
    url=os.getenv('SHEETS_URL','').strip();key=os.getenv('SHEETS_SHARED_KEY','').strip()
    match=re.fullmatch(r'https://script\.google\.com/macros/s/([A-Za-z0-9_-]+)/exec',url)
    if not match:return 'SHEETS_URL muss die Web-App-/exec-URL sein; kein Bibliothekslink.'
    if not key:return 'SHEETS_SHARED_KEY fehlt. Schlüssel im USHERO-Menü deiner Tabelle erzeugen; nicht die AKfy-Bereitstellungs-ID verwenden.'
    if key==match.group(1) or key.startswith('AKfy'):return 'Bereitstellungs-ID als Schlüssel erkannt. Der geheime Verbindungsschlüssel wird separat im USHERO-Menü von Sheets erzeugt.'
    if len(key)<24:return 'Verbindungsschlüssel zu kurz. In Sheets einen neuen langen USHERO-Schlüssel erzeugen.'
    return None


async def _request(data=None,params=None):
    error=connection_error()
    if error:return {'ok':False,'error':error}
    url=os.environ['SHEETS_URL'].strip();key=os.environ['SHEETS_SHARED_KEY'].strip()
    try:
        async with aiohttp.ClientSession(trust_env=True,timeout=aiohttp.ClientTimeout(total=25)) as session:
            request=session.post(url,json={**data,'shared_key':key}) if data is not None else session.get(url,params={**(params or {}),'shared_key':key})
            async with request as response:
                if response.status in (401,403):return {'ok':False,'error':'Google verweigert den Web-App-Aufruf. Deployment-Zugriff und /exec-URL prüfen.'}
                if response.status==404:return {'ok':False,'error':'Web-App nicht gefunden. Aktuelle /exec-URL aus der Bereitstellung übernehmen.'}
                if response.status==429:return {'ok':False,'error':'Google-Kontingent vorübergehend erreicht. Später erneut abgleichen.'}
                if response.status!=200:return {'ok':False,'error':f'Google-Web-App antwortet mit HTTP {response.status}.'}
                chunks=[];size=0
                async for chunk in response.content.iter_chunked(65536):
                    size+=len(chunk)
                    if size>1024*1024:return {'ok':False,'error':'Google-Antwort zu groß; Abgleich nicht bestätigt.'}
                    chunks.append(chunk)
                raw=b''.join(chunks)
                try:result=json.loads(raw)
                except (ValueError,UnicodeError):return {'ok':False,'error':'Web-App liefert HTML statt JSON. Zugriff ohne Anmeldung erlauben und neue Script-Version bereitstellen.'}
                return result if isinstance(result,dict) else {'ok':False,'error':'Ungueltige Sheets-Antwort'}
    except (aiohttp.ClientError,TimeoutError,ValueError):
        return {'ok':False,'error':'Web-App nicht erreichbar. Internet, Google-Bereitstellung und /exec-URL prüfen; lokale Buchungen bleiben erhalten.'}


async def sheets_post(data):return await _request(data=data)
async def sheets_get(params):return await _request(params=params)


def document_url(value):
    """Nur echte Tabellenlinks anzeigen; nie den Backend-Endpunkt oder Geheimnisse."""
    if not isinstance(value,str):return None
    match=re.fullmatch(r'https://docs\.google\.com/spreadsheets/d/([A-Za-z0-9_-]+)/edit',value)
    return 'https://docs.google.com/spreadsheets/d/'+match.group(1)+'/edit' if match else None


async def check():
    from dotenv import load_dotenv
    from utils.config import ROOT
    load_dotenv(ROOT/'.env')
    result=await sheets_post({'type':'status'})
    if not result.get('ok'):print('Sheets-Test fehlgeschlagen: '+result.get('error','Unbekannte Antwort'));return 1
    if result.get('version',0)<3:print('Web-App veraltet: neues Code.gs einfügen und Deployment auf Version 3 aktualisieren.');return 1
    print('Web-App bestätigt. Tabelle eingerichtet: '+('ja' if result.get('configured') else 'nein'))
    print('Rückweg: nur Lagerbestand und Dienstplan. Geldbuchungen bleiben im Bot.')
    return 0 if result.get('configured') else 1


if __name__=='__main__':raise SystemExit(asyncio.run(check()))
