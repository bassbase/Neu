"""Transaktionale Provisionsabrechnung: jede Buchung wird genau einmal zugeordnet."""
from utils.clock import utcnow
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
import aiosqlite
from utils.database import DB_PATH


def money(value):
    return float(Decimal(str(value)).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))


async def pending_rows(db,user_id):
    sales=await (await db.execute('SELECT item,amount,quantity FROM sales WHERE seller_id=? AND settlement_id IS NULL',(user_id,))).fetchall()
    vip=await (await db.execute('SELECT description,amount FROM vip_entries WHERE seller_id=? AND settlement_id IS NULL',(user_id,))).fetchall()
    total=sum((Decimal(str(amount))*quantity for _,amount,quantity in sales),Decimal(0))+sum((Decimal(str(amount)) for _,amount in vip),Decimal(0))
    details=[f'{name} × {quantity}: {amount*quantity:,.2f} $' for name,amount,quantity in sales]
    details += [f'VIP · {name or "Service"}: {amount:,.2f} $' for name,amount in vip]
    return money(total),'\n'.join(details) or 'Keine offenen Buchungen'


async def pending_summary(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        return await pending_rows(db,user_id)


async def settle_employee(user_id):
    from cogs.schicht import parse_time, SCHICHT_BONUS_PROZENT
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('BEGIN IMMEDIATE')
        gross,details=await pending_rows(db,user_id)
        if gross<=0: return None
        now=utcnow()
        active=await (await db.execute("SELECT id,started_at FROM schichten WHERE user_id=? AND status='aktiv'",(user_id,))).fetchone()
        if active:
            minutes=max(0,int((now-parse_time(active[1])).total_seconds()//60)) if active[1] else 0
            await db.execute("UPDATE schichten SET status='beendet',ended_at=?,endzeit=?,dauer=? WHERE id=?",(now.isoformat(),now.isoformat(),minutes,active[0]))
        completed=await (await db.execute("SELECT 1 FROM schichten WHERE user_id=? AND status='beendet' AND ended_at LIKE ? LIMIT 1",(user_id,now.date().isoformat()+'%'))).fetchone()
        row=await (await db.execute("SELECT value FROM settings WHERE key='firma_prozent'")).fetchone()
        percent=float(row[0]) if row else 80.0
        if not 0<=percent<=100: raise ValueError('Ungültiger Firmenanteil in den Einstellungen.')
        base=money(Decimal(str(gross))*(Decimal(100)-Decimal(str(percent)))/100)
        company=money(gross-base)
        bonus=min(company,money(Decimal(str(base))*SCHICHT_BONUS_PROZENT/100)) if completed else 0
        employee=money(base+bonus);company=money(company-bonus)
        cursor=await db.execute('INSERT INTO abrechnungen(user_id,brutto,firma_prozent,firma_anteil,mitarbeiter_anteil,details,created_at) VALUES(?,?,?,?,?,?,?)',
                               (user_id,gross,percent,company,employee,details+f'\nDienstbonus: {bonus:.2f}',now.isoformat()))
        settlement_id=cursor.lastrowid
        for table in ('sales','vip_entries'):
            await db.execute(f'UPDATE {table} SET settlement_id=? WHERE seller_id=? AND settlement_id IS NULL',(settlement_id,user_id))
        await db.execute('UPDATE firmenkasse SET balance=balance+?,updated_at=? WHERE id=1',(company,now.isoformat()))
        await db.execute("INSERT INTO audit_logs(action,user_id,details,created_at) VALUES('abrechnung',?,?,?)",(user_id,f'#{settlement_id} Brutto {gross}',now.isoformat()))
        await db.commit()
        return {'id':settlement_id,'gross':gross,'company':company,'employee':employee,'base':base,'bonus':bonus,'percent':percent,'details':details}
