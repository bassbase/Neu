"""Bereichsbuttons in passenden Kanaelen, mit registrierter Chatbereinigung."""
import logging
import asyncio
import discord
from discord import app_commands
from discord.ext import commands,tasks
from utils.menu_ui import open_category,open_home,reply,server_allowed,allowed,ActionView,invoke
from utils.perms import is_leitung
from utils.panel_specs import SPECS,match_channel,match_category
from utils.managed_panels import PanelManager
from utils.config import CONFIG

AREAS=tuple(SPECS)


async def open_action(interaction,name):
    if name.startswith('@'):
        from cogs.schicht import duty_action
        return await duty_action(interaction,name=='@start')
    command=next((c for c in interaction.client.tree.walk_commands() if isinstance(c,app_commands.Command) and c.qualified_name==name),None)
    if command is None:raise ValueError('Aktion fehlt. Bitte Bot vollständig aktualisieren.')
    if not allowed(interaction.user,command):raise app_commands.CheckFailure('Deine Rolle darf diese Aktion nicht verwenden.')
    if not command.parameters and name not in ('security dienst-ende','setup'):
        return await invoke(interaction,command,{})
    action=ActionView(interaction.user.id,command)
    await reply(interaction,embed=action.embed(),view=action)


class AreaPanelView(discord.ui.View):
    def __init__(self,key):
        super().__init__(timeout=None)
        self.key=key
        for index,(name,label,emoji) in enumerate(SPECS[key].actions):
            button=discord.ui.Button(label=label,emoji=emoji,row=index//3,
                                     custom_id=f'ushero:work:{key}:{name}',style=discord.ButtonStyle.primary)
            async def action(interaction,name=name):await open_action(interaction,name)
            button.callback=action;self.add_item(button)
        more=discord.ui.Button(label='Weitere Bereichsaktionen',custom_id=f'ushero:work:{key}:more',style=discord.ButtonStyle.secondary,row=3)
        async def category(interaction):await open_category(interaction,SPECS[key].area)
        more.callback=category;self.add_item(more)
        home=discord.ui.Button(label='Hauptmenü',custom_id=f'ushero:work:{key}:home',style=discord.ButtonStyle.secondary,row=3)
        home.callback=open_home;self.add_item(home)

    async def interaction_check(self,interaction):
        if server_allowed(interaction.client,interaction.guild):return True
        await reply(interaction,'Bitte auf dem konfigurierten Server verwenden.')
        return False

    async def on_error(self,interaction,error,item):
        from utils.menu_ui import show_error
        await show_error(interaction,error)


class CleanPanelView(discord.ui.View):
    """Vorhandene alte Bereichsbuttons bleiben ansprechbar."""
    def __init__(self,area):
        super().__init__(timeout=None)
        button=discord.ui.Button(label='Bereich öffnen',custom_id='ushero:channel:'+area)
        async def open_area(interaction):
            if area=='home':return await open_home(interaction)
            await open_category(interaction,SPECS[area].area)
        button.callback=open_area;self.add_item(button)
        home=discord.ui.Button(label='Hauptmenü',custom_id='ushero:channel:home:'+area)
        home.callback=open_home;self.add_item(home)

    async def interaction_check(self,interaction):return server_allowed(interaction.client,interaction.guild)

    async def on_error(self,interaction,error,item):
        from utils.menu_ui import show_error
        await show_error(interaction,error)


class ChannelPanels(commands.Cog):
    def __init__(self,bot):
        self.bot=bot;self.manager=PanelManager(bot,AreaPanelView);self.install_lock=asyncio.Lock()

    async def cog_load(self):
        await self.manager.load()
        for key in AREAS:
            self.bot.add_view(CleanPanelView(key))
            if key!='home':self.bot.add_view(AreaPanelView(key))
        self.maintain.start()

    def cog_unload(self):self.maintain.cancel()

    @tasks.loop(seconds=5)
    async def maintain(self):
        try:await self.manager.drain()
        except Exception as error:logging.error('Kanalmenüs: %s',type(error).__name__)

    @maintain.before_loop
    async def before_maintain(self):await self.bot.wait_until_ready()

    @commands.Cog.listener()
    async def on_message(self,message):await self.manager.received(message)

    @commands.Cog.listener()
    async def on_raw_message_delete(self,payload):await self.manager.deleted(payload.channel_id,payload.message_id)

    @commands.Cog.listener()
    async def on_raw_message_edit(self,payload):
        record=self.manager.records.get(payload.channel_id)
        if record and record['message_id']==payload.message_id and payload.data.get('pinned') is False:
            self.manager.dirty.add(payload.channel_id)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self,channel):await self.manager.unregister(channel.id)

    async def install(self,interaction,create_missing=True,clean_chat=True):
        if not is_leitung(interaction.user):return await reply(interaction,'❌ Nur Leitung darf Kanalmenüs einrichten.')
        if not server_allowed(self.bot,interaction.guild):return await reply(interaction,'Bitte GUILD_ID prüfen.')
        if not interaction.response.is_done():await interaction.response.defer(ephemeral=True)
        async with self.install_lock:
            guild=interaction.guild
            from cogs.setup_server import ow_team,ow_leitung,ow_public
            results=[];assigned={}
            for key,spec in SPECS.items():
                try:
                    channel=match_channel(guild,spec,CONFIG.get('panel_channels',{}))
                    if channel is None:
                        if not create_missing:
                            results.append(f'⚠️ {spec.channel}: fehlt (kein Kanal angelegt).');continue
                        if not guild.me.guild_permissions.manage_channels:
                            results.append(f'⚠️ {spec.channel}: fehlt; Bot braucht Kanäle verwalten.');continue
                        if spec.area in ('leitung','buchhaltung','ki'):overwrites=await ow_leitung(guild)
                        elif spec.area=='info':overwrites=await ow_public(guild)
                        else:overwrites=await ow_team(guild)
                        # Keine Rollen/alten Kanaele veraendern. Neue Kanaele nur mit vorhandenen Rollen.
                        channel=await guild.create_text_channel(spec.channel,category=match_category(guild,spec),overwrites=overwrites,reason='USHERO-Kanalmenü einrichten')
                    if channel.id in assigned:
                        raise ValueError(f'Kanal schon für {assigned[channel.id]} verwendet; panel_channels prüfen.')
                    assigned[channel.id]=key
                    result=await self.manager.post(channel,key,clean=clean_chat)
                    await self.manager.remove_duplicate_menus(channel)
                    notes=[]
                    if not result['pinned']:notes.append('Anheften nicht erlaubt')
                    if clean_chat and spec.clean and not result['clean']:notes.append('Chatbereinigung aus: Nachrichten verwalten fehlt')
                    results.append(f'✅ <#{channel.id}> · {spec.channel}'+(' · '+', '.join(notes) if notes else ''))
                except (ValueError,discord.HTTPException) as error:
                    detail=str(error) if isinstance(error,ValueError) else type(error).__name__
                    results.append(f'⚠️ {spec.channel}: {detail[:180]}')
            embed=discord.Embed(title='🗂️ USHERO · Kanalmenüs eingerichtet',description='\n'.join(results)[:4000],color=0xEB459E)
            embed.set_footer(text='Nur neue Nachrichten in registrierten Arbeitskanälen werden bereinigt. Alte Chats und Protokolle bleiben erhalten.')
            await reply(interaction,embed=embed)

    @app_commands.command(name='menues-einrichten',description='Bereichsmenüs automatisch den Kanälen zuordnen; neue Arbeits-Chats bereinigen')
    @app_commands.describe(fehlende_anlegen='Fehlende Arbeitskanäle mit vorhandenen Teamrechten neu anlegen',chat_aufraeumen='Neue öffentliche Nachrichten in Arbeitskanälen nach ca. 10 Sekunden entfernen')
    async def setup_panels(self,interaction: discord.Interaction,fehlende_anlegen: bool=True,chat_aufraeumen: bool=True):
        await self.install(interaction,fehlende_anlegen,chat_aufraeumen)

    @app_commands.command(name='menues-status',description='Gespeicherte Kanalmenüs und Chatbereinigung prüfen')
    async def status(self,interaction: discord.Interaction):
        rows=[r for r in self.manager.records.values() if r['guild_id']==interaction.guild.id]
        text='\n'.join(f"<#{r['channel_id']}> · {r['panel_key']} · Chatbereinigung {'an' if r['clean_chat'] else 'aus'}" for r in rows) or 'Noch keine Kanalmenüs eingerichtet.'
        await reply(interaction,embed=discord.Embed(title='🔎 USHERO · Kanalmenüs',description=text[:4000],color=0x9B59B6))

    @app_commands.command(name='menues-stop',description='Menüautomatik und neue Chatlöschungen in diesem Kanal ausschalten')
    async def stop(self,interaction: discord.Interaction):
        if not is_leitung(interaction.user):return await reply(interaction,'❌ Nur Leitung.')
        await self.manager.unregister(interaction.channel.id)
        await reply(interaction,'✅ Menüautomatik und Chatbereinigung in diesem Kanal ausgeschaltet. Das bestehende Menü bleibt bedienbar.')

    @app_commands.command(name='panel-channel',description='Passendes dauerhaftes Bereichsmenü in diesen Kanal setzen')
    @app_commands.choices(bereich=[app_commands.Choice(name=spec.channel,value=key) for key,spec in SPECS.items()])
    async def panel_channel(self,interaction: discord.Interaction,bereich: app_commands.Choice[str]):
        if not is_leitung(interaction.user):return await reply(interaction,'❌ Nur Leitung.')
        await interaction.response.defer(ephemeral=True)
        result=await self.manager.post(interaction.channel,bereich.value)
        await self.manager.remove_duplicate_menus(interaction.channel)
        await reply(interaction,'✅ Bereichsmenü registriert. '+('Neue Arbeitsnachrichten werden nach ca. 10 Sekunden entfernt.' if result['clean'] else 'Öffentliche Chatnachrichten bleiben erhalten.'))

    @app_commands.command(name='channel-sauber',description='Eigene alte Bot-Texte in diesem Kanal aufräumen; Menüs und Logs verschonen')
    async def channel_sauber(self,interaction: discord.Interaction,anzahl: int=15):
        if not is_leitung(interaction.user):return await reply(interaction,'❌ Nur Leitung.')
        if interaction.channel.id not in self.manager.records:return await reply(interaction,'Nur in registrierten Menükanälen verfügbar; Protokollkanäle werden nicht bereinigt.')
        if not 1<=anzahl<=25:raise ValueError('Anzahl muss zwischen 1 und 25 liegen.')
        await interaction.response.defer(ephemeral=True)
        deleted=0
        async for message in interaction.channel.history(limit=anzahl):
            if message.author.id==self.bot.user.id and not message.components and not message.pinned:
                await message.delete();deleted+=1
        await reply(interaction,f'🧹 {deleted} eigene Bot-Texte entfernt; Menüs bleiben erhalten.')


async def setup(bot):await bot.add_cog(ChannelPanels(bot))
