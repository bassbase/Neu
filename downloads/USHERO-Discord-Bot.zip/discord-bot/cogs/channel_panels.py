import discord
from discord import app_commands
from discord.ext import commands
from utils.menu_ui import open_category, open_home, OwnedView, reply, server_allowed
from utils.perms import is_leitung

AREAS=('verkauf','warehouse','vip','taenzer','security','buchhaltung')


class CleanPanelView(discord.ui.View):
    def __init__(self,area):
        super().__init__(timeout=None)
        self.area=area
        button=discord.ui.Button(label='Bereich öffnen',emoji='📂',custom_id='ushero:channel:'+area,style=discord.ButtonStyle.primary)
        async def open_area(interaction): await open_category(interaction,self.area)
        button.callback=open_area
        self.add_item(button)
        home=discord.ui.Button(label='Hauptmenü',custom_id='ushero:channel:home:'+area,style=discord.ButtonStyle.secondary)
        home.callback=open_home
        self.add_item(home)

    async def interaction_check(self,interaction):
        if server_allowed(interaction.client,interaction.guild): return True
        await reply(interaction,"Bitte GUILD_ID für diesen Server einstellen.")
        return False

    async def on_error(self,interaction,error,item):
        from utils.menu_ui import show_error
        await show_error(interaction,error)


class ChannelPanels(commands.Cog):
    def __init__(self,bot): self.bot=bot

    async def cog_load(self):
        for area in AREAS: self.bot.add_view(CleanPanelView(area))

    @app_commands.command(name='panel-channel',description='Dauerhaftes Bereichsmenü in diesen Kanal posten')
    @app_commands.choices(bereich=[app_commands.Choice(name=a.title(),value=a) for a in AREAS])
    async def panel_channel(self,interaction: discord.Interaction,bereich: app_commands.Choice[str]):
        if not is_leitung(interaction.user): return await reply(interaction,'❌ Nur Leitung.')
        await interaction.response.defer(ephemeral=True)
        await interaction.channel.send(embed=discord.Embed(title='✦ USHERO · '+bereich.name,description='Bereich öffnen und direkt per Auswahl oder Formular arbeiten.',color=0xEB459E),view=CleanPanelView(bereich.value))
        await reply(interaction,'✅ Bereichsmenü gepostet.')

    @app_commands.command(name='channel-sauber',description='Eigene Bot-Nachrichten ohne aktive Menüs aufräumen')
    async def channel_sauber(self,interaction: discord.Interaction,anzahl: int=15):
        if not is_leitung(interaction.user): return await reply(interaction,'❌ Nur Leitung.')
        if not 1<=anzahl<=25: raise ValueError('Anzahl muss zwischen 1 und 25 liegen.')
        await interaction.response.defer(ephemeral=True)
        deleted=0
        async for message in interaction.channel.history(limit=anzahl):
            if message.author.id==interaction.client.user.id and not message.components:
                await message.delete()
                deleted+=1
        await reply(interaction,f'🧹 {deleted} eigene Bot-Nachrichten entfernt. Menüs und fremde Bots bleiben erhalten.')


async def setup(bot): await bot.add_cog(ChannelPanels(bot))
