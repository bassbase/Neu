from utils.menu_ui import reply
from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, timedelta, timezone
import json

from utils.database import start_dance, get_active_dances, finish_dance, log_audit, add_sale

from utils.config import CONFIG

# Standard-Preise (kannst du anpassen)
PREISE = {
    10: 50.0,
    15: 70.0,
    30: 120.0
}


class Taenzer(commands.Cog):
    """Tänzer/innen System mit Timer"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    taenzer = app_commands.Group(name="taenzer", description="Tänzer/innen Sessions verwalten")

    @taenzer.command(name="starten", description="Neue Tanz-Session starten (mit Timer)")
    @app_commands.describe(
        taenzer="Wer tanzt",
        dauer="Dauer in Minuten (10, 15 oder 30)",
        kaeufer="Wer hat gebucht / bezahlt",
        preis="Optional eigener Preis (sonst Standard)"
    )
    @app_commands.choices(dauer=[
        app_commands.Choice(name="10 Minuten", value=10),
        app_commands.Choice(name="15 Minuten", value=15),
        app_commands.Choice(name="30 Minuten", value=30),
    ])
    async def taenzer_starten(
        self,
        interaction: discord.Interaction,
        taenzer: discord.Member,
        dauer: app_commands.Choice[int],
        kaeufer: discord.Member,
        preis: float = None
    ):
        await interaction.response.defer(ephemeral=True)

        duration = dauer.value
        price = preis if preis is not None else PREISE.get(duration, 50.0)

        # Session in DB speichern
        session_id = await start_dance(
            dancer_id=taenzer.id,
            booker_id=kaeufer.id,
            duration=duration,
            price=price,
            channel_id=interaction.channel.id
        )

        # Session und Umsatz wurden in einer gemeinsamen Transaktion gespeichert.

        await log_audit("dance_start", interaction.user.id, taenzer.id,
                        f"{duration}min - {price} - Käufer {kaeufer.id}")

        ends_at = utcnow() + timedelta(minutes=duration)

        embed = discord.Embed(
            title="💃 Tanz-Session gestartet",
            color=0xE91E63,
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Tänzer/in", value=taenzer.mention, inline=True)
        embed.add_field(name="Gebucht von", value=kaeufer.mention, inline=True)
        embed.add_field(name="Dauer", value=f"{duration} Minuten", inline=True)
        embed.add_field(name="Preis", value=f"**{price} {CONFIG['currency']}**", inline=True)
        embed.add_field(name="Endet um", value=f"<t:{int(ends_at.replace(tzinfo=timezone.utc).timestamp())}:T>", inline=True)
        embed.add_field(name="Session-ID", value=f"#{session_id}", inline=True)
        embed.set_footer(text="Der Tänzer/Mitarbeiter erhält eine DM wenn die Zeit abgelaufen ist.")

        await reply(interaction, embed=embed)

        # DM an den Tänzer (Mitarbeiter) – Info dass Session läuft
        try:
            dm_embed = discord.Embed(
                title="💃 Deine Tanz-Session läuft",
                description=(
                    f"Du tanzt jetzt für **{kaeufer.display_name}**.\n"
                    f"Dauer: **{duration} Minuten**\n"
                    f"Preis: **{price} {CONFIG['currency']}**\n"
                    f"Endet: <t:{int(ends_at.replace(tzinfo=timezone.utc).timestamp())}:R>\n\n"
                    f"Du bekommst eine Nachricht sobald die Zeit vorbei ist."
                ),
                color=0xE91E63
            )
            await taenzer.send(embed=dm_embed)
        except Exception:
            pass

    @taenzer.command(name="aktiv", description="Aktuell laufende Sessions anzeigen")
    async def taenzer_aktiv(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        sessions = await get_active_dances()
        if not sessions:
            await reply(interaction, "Aktuell keine laufenden Sessions.")
            return

        embed = discord.Embed(
            title="💃 Aktive Tanz-Sessions",
            color=0xE91E63,
            timestamp=discord.utils.utcnow()
        )
        for s in sessions[:25]:
            dancer = interaction.guild.get_member(s["dancer_id"])
            booker = interaction.guild.get_member(s["booker_id"])
            ends = datetime.fromisoformat(s["ends_at"])
            embed.add_field(
                name=f"Session #{s['id']}",
                value=(
                    f"Tänzer: {dancer.mention if dancer else s['dancer_id']}\n"
                    f"Käufer: {booker.mention if booker else s['booker_id']}\n"
                    f"Dauer: {s['duration_minutes']} Min | {s['price']} {CONFIG['currency']}\n"
                    f"Endet: <t:{int(ends.replace(tzinfo=timezone.utc).timestamp())}:R>"
                ),
                inline=False
            )
        await reply(interaction, embed=embed)

    @taenzer.command(name="beenden", description="Session manuell beenden")
    async def taenzer_beenden(self, interaction: discord.Interaction, session_id: int):
        await interaction.response.defer(ephemeral=True)
        from utils.perms import is_leitung
        from utils.database import DB_PATH
        import aiosqlite
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("BEGIN IMMEDIATE")
            row = await (await db.execute("SELECT dancer_id,status FROM dance_sessions WHERE id=?", (session_id,))).fetchone()
            if not row or row[1] != "active":
                await reply(interaction, "Keine aktive Session mit dieser Nummer.", ephemeral=True)
                return
            if row[0] != interaction.user.id and not is_leitung(interaction.user):
                await reply(interaction, "Nur eigene Sessions oder Leitung.", ephemeral=True)
                return
            await db.execute("UPDATE dance_sessions SET status='finished' WHERE id=?", (session_id,))
            await db.commit()
        await log_audit("dance_end", interaction.user.id, details=f"Session #{session_id} manuell beendet")
        await reply(interaction, f"✅ Session #{session_id} wurde beendet.")


async def setup(bot: commands.Bot):
    await bot.add_cog(Taenzer(bot))
