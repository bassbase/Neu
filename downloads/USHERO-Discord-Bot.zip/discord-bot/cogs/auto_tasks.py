"""Ein zentraler Timer: Auto-Logout, Tanz-Ende, Lagerhinweise."""
from utils.clock import utcnow
from datetime import datetime,timedelta
import discord
from discord.ext import commands,tasks
import aiosqlite
from utils.database import DB_PATH
from cogs.schicht import end_schicht,parse_time


class AutoTasks(commands.Cog):
    def __init__(self,bot): self.bot=bot;self.warned=set()

    async def cog_load(self): self.tick.start()
    def cog_unload(self): self.tick.cancel()

    @tasks.loop(minutes=1)
    async def tick(self):
        try:
            await self.check_once()
        except Exception as error:
            import logging
            logging.error('Automatik konnte nicht ausgefuehrt werden: %s',type(error).__name__)

    @tick.before_loop
    async def before(self): await self.bot.wait_until_ready()

    async def check_once(self):
        from utils.menu_ui import server_allowed
        if not any(server_allowed(self.bot,g) for g in self.bot.guilds): return
        now=utcnow()
        async with aiosqlite.connect(DB_PATH) as db:
            shifts=await (await db.execute("SELECT id,user_id,started_at FROM schichten WHERE status='aktiv'")).fetchall()
            dances=await (await db.execute("SELECT id,dancer_id FROM dance_sessions WHERE status='active' AND ends_at<=?",(now.isoformat(),))).fetchall()
            await db.execute("UPDATE dance_sessions SET status='finished' WHERE status='active' AND ends_at<=?",(now.isoformat(),))
            stock=await (await db.execute('SELECT item,quantity FROM warehouse_stock WHERE quantity<=10')).fetchall()
            await db.commit()
        for ident,user_id,started in shifts:
            try:
                overdue=bool(started) and now-parse_time(started)>=timedelta(hours=12)
            except (ValueError,TypeError):
                continue
            if overdue:
                ended=await end_schicht(user_id,automatic=True,expected_id=ident)
                if ended is not None: await self.notify(user_id,'⏰ USHERO: Dein Dienst wurde nach mindestens 12 Stunden automatisch beendet. Kein manueller Dienstbonus für diese Schicht.')
        for ident,user_id in dances:
            await self.notify(user_id,f'💃 USHERO: Tanz-Session #{ident} ist abgelaufen und wurde beendet.')
        current={(item,quantity) for item,quantity in stock}
        if current and current!=self.warned:
            embed=discord.Embed(title='📦 USHERO · Lagerhinweis',description='\n'.join(f'**{item}**: {quantity} Stück' for item,quantity in sorted(current))[:4000],color=0xF59E0B)
            for guild in self.bot.guilds:
                if not server_allowed(self.bot,guild): continue
                channel=discord.utils.get(guild.text_channels,name='lager-warnungen')
                if channel:
                    try: await channel.send(embed=embed)
                    except discord.HTTPException: pass
        self.warned=current

    async def notify(self,user_id,message):
        from utils.menu_ui import server_allowed
        for guild in self.bot.guilds:
            if not server_allowed(self.bot,guild): continue
            member=guild.get_member(user_id)
            if member:
                try: await member.send(message)
                except discord.HTTPException: pass
                break


async def setup(bot): await bot.add_cog(AutoTasks(bot))
