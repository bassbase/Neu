"""Admin-Diagnose: was fehlt, was kaputt ist, was noch konfiguriert werden muss."""
from utils.menu_ui import reply
from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
import os
import json
import aiosqlite
import traceback
import math
from utils.config import ROOT
from utils.openai_client import has_openai

from utils.database import DB_PATH
from utils.perms import is_leitung, is_owner


def _admin_ok(member: discord.Member) -> bool:
    return (
        member.guild_permissions.administrator
        or is_owner(member)
        or is_leitung(member)
    )


class Diagnose(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._last_errors: list[str] = []

    def record_error(self, text: str):
        self._last_errors.append(f"{utcnow().strftime('%H:%M:%S')} {text[:200]}")
        self._last_errors = self._last_errors[-15:]

    @commands.Cog.listener()
    async def on_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        msg = f"/{getattr(interaction.command, 'qualified_name', '?')}: {error}"
        self.record_error(msg)
        # don't swallow - other handlers may exist

    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        self.record_error(f"!{getattr(ctx.command, 'name', '?')}: {error}")

    diagnose = app_commands.Group(name="diagnose", description="Admin: System prüfen")

    @diagnose.command(name="check", description="Komplett-Check: Config, Cogs, Channels, Rechte, KI")
    async def check(self, interaction: discord.Interaction):
        if not _admin_ok(interaction.user):
            await reply(interaction, "❌ Nur Leitung / Admin / Inhaber.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        ok, warn, bad = [], [], []

        # --- Token / env ---
        if os.getenv("DISCORD_TOKEN"):
            ok.append("DISCORD_TOKEN gesetzt")
        else:
            bad.append("DISCORD_TOKEN fehlt in .env")

        if has_openai():
            ok.append("Externe OpenAI-Aufrufe explizit aktiviert; Anbietertarife gelten")
        else:
            warn.append("Externe KI deaktiviert: lokale Regelvorlagen, kein generatives Sprachmodell")

        # --- Config ---
        try:
            with open(ROOT / "config.json", encoding="utf-8") as f:
                cfg = json.load(f)
            ok.append("config.json lesbar")
        except Exception as e:
            bad.append(f"config.json: {e}")
            cfg = {}

        # --- Cogs ---
        loaded = [name for name, _ in self.bot.cogs.items()]
        expected = [
            "Admin", "Verkauf", "Warehouse", "Vip", "Taenzer", "Security",
            "SetupServer", "Panel", "Buchhaltung", "Schicht", "KI", "Arbeit",
            "LogsReport", "ChannelPanels", "StartHilfe", "Diagnose",
        ]
        # cog class names may vary
        loaded_lower = {n.lower() for n in loaded}
        for exp in expected:
            # flexible match
            if any(exp.lower() in L or L in exp.lower() for L in loaded_lower):
                ok.append(f"Modul geladen: {exp}")
            else:
                # check by file stem in extensions
                warn.append(f"Modul evtl. nicht geladen: {exp} (Name kann abweichen)")

        ok.append(f"Geladene Cogs ({len(loaded)}): {', '.join(sorted(loaded))}")

        # --- Bot permissions ---
        me = guild.me
        if me:
            perms = me.guild_permissions
            need = {
                "Nachrichten verwalten": perms.manage_messages,
                "Rollen verwalten": perms.manage_roles,
                "Kanäle verwalten": perms.manage_channels,
                "Nachrichten senden": perms.send_messages,
                "Links einbetten": perms.embed_links,
                "Mitglieder moderieren": perms.moderate_members,
            }
            for label, has in need.items():
                if has or perms.administrator:
                    ok.append(f"Recht OK: {label}")
                else:
                    bad.append(f"Recht fehlt: {label}")
            if me.top_role.position <= 1:
                warn.append("Bot-Rolle sehr weit unten – Rollen anlegen kann scheitern")
        else:
            bad.append("Bot-Member nicht gefunden")

        # --- Important channels ---
        important = [
            "willkommen", "abschied", "verkauf", "kasse", "warehouse-bestellungen",
            "vip", "taenzer", "security", "mitarbeiter-chat", "buchhaltung",
            "sales-log", "daily-report", "ki-panel",
        ]
        names = {c.name for c in guild.text_channels}
        for ch in important:
            if ch in names or any(ch in n for n in names):
                ok.append(f"Channel vorhanden: #{ch}")
            else:
                warn.append(f"Channel fehlt: #{ch} (ggf. /setup)")

        # --- Roles ---
        role_need = ["Gast", "Verkauf", "Tänzer/in", "Security", "Warehouse", "Mitarbeiter", "Leitung", "Buchhaltung"]
        rnames = {r.name for r in guild.roles}
        for r in role_need:
            if r in rnames:
                ok.append(f"Rolle OK: {r}")
            else:
                warn.append(f"Rolle fehlt: {r} (ggf. /setup)")

        # --- Database ---
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                async with db.execute("SELECT name FROM sqlite_master WHERE type='table'") as c:
                    tables = [row[0] for row in await c.fetchall()]
            ok.append(f"Datenbank OK ({len(tables)} Tabellen)")
            for t in ("sales", "vip_entries", "warnings"):
                if t in tables:
                    ok.append(f"Tabelle: {t}")
                else:
                    warn.append(f"Tabelle fehlt noch: {t} (wird bei Nutzung angelegt)")
        except Exception as e:
            bad.append(f"Datenbank-Fehler: {e}")

        # --- Latency ---
        ok.append(f"Ping: {round(self.bot.latency * 1000)} ms" if math.isfinite(self.bot.latency) else "Ping: noch nicht mit Discord verbunden")

        # --- Recent errors ---
        if self._last_errors:
            warn.append("Letzte Command-Fehler:\n" + "\n".join(self._last_errors[-5:]))
        else:
            ok.append("Keine Command-Fehler im Speicher")

        # Build embeds (split if long)
        def pack(title, items, color):
            if not items:
                return None
            e = discord.Embed(title=title, color=color, timestamp=discord.utils.utcnow())
            text = "\n".join(f"• {i}" for i in items[:25])
            if len(items) > 25:
                text += f"\n… +{len(items)-25} weitere"
            e.description = text
            return e

        embeds = []
        for title, items, color in (
            ("✅ OK", ok, 0x2ECC71),
            ("⚠️ Hinweise", warn, 0xF59E0B),
            ("❌ Probleme", bad, 0xEF4444),
        ):
            em = pack(title, items, color)
            if em:
                embeds.append(em)

        summary = discord.Embed(
            title="🩺 System-Diagnose",
            description=(
                f"**OK:** {len(ok)} · **Hinweise:** {len(warn)} · **Probleme:** {len(bad)}\n"
                f"Server: **{guild.name}** · Bot: **{self.bot.user}**"
            ),
            color=0x8B5CF6 if not bad else 0xEF4444,
        )
        if bad:
            summary.add_field(
                name="Nächster Schritt",
                value="Rechte/Channels/Rollen prüfen · `/setup` · Bot-Rolle nach oben · Konsole lesen",
                inline=False,
            )
        else:
            summary.add_field(name="Status", value="Keine kritischen Fehler gefunden.", inline=False)

        await reply(interaction, embeds=[summary] + embeds[:3], ephemeral=True)

    @diagnose.command(name="fehler", description="Zuletzt gemerkte Command-Fehler")
    async def fehler(self, interaction: discord.Interaction):
        if not _admin_ok(interaction.user):
            await reply(interaction, "❌ Keine Rechte.", ephemeral=True)
            return
        if not self._last_errors:
            await reply(interaction, "✅ Keine Fehler im Speicher (seit Bot-Start).", ephemeral=True)
            return
        embed = discord.Embed(
            title="🩹 Letzte Fehler",
            description="\n".join(f"`{e}`" for e in self._last_errors),
            color=0xE67E22
        )
        await reply(interaction, embed=embed, ephemeral=True)

    @diagnose.command(name="cogs", description="Welche Module geladen sind")
    async def cogs(self, interaction: discord.Interaction):
        if not _admin_ok(interaction.user):
            await reply(interaction, "❌ Keine Rechte.", ephemeral=True)
            return
        names = sorted(self.bot.cogs.keys())
        embed = discord.Embed(
            title="📦 Geladene Module",
            description="\n".join(f"• **{n}**" for n in names) or "Keine",
            color=0x3498DB
        )
        embed.set_footer(text=f"{len(names)} Cogs")
        await reply(interaction, embed=embed, ephemeral=True)

    @diagnose.command(name="ping", description="Bot-Reaktionszeit")
    async def ping(self, interaction: discord.Interaction):
        await reply(interaction, 
            f"🏓 Latency: **{round(self.bot.latency * 1000)} ms**",
            ephemeral=True
        )


    @diagnose.command(name="sync", description="Slash-Commands neu synchronisieren (Admin)")
    async def sync_cmd(self, interaction: discord.Interaction):
        if not _admin_ok(interaction.user):
            await reply(interaction, "❌ Keine Rechte.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        try:
            self.bot.tree.copy_global_to(guild=interaction.guild)
            synced = await self.bot.tree.sync(guild=interaction.guild)
            await reply(interaction, 
                f"✅ **{len(synced)} Commands** für diesen Server synchronisiert.\n"
                "Das Hauptmenü und die Bereichsaktionen sind jetzt aktualisiert."
            )
        except Exception as e:
            await reply(interaction, f"❌ Sync-Fehler: {e}")


async def setup(bot: commands.Bot):
    await bot.add_cog(Diagnose(bot))
