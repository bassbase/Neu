"""Rangsystem (inspiriert von deinen alten Business-Bots) – kostenlos, lokal."""
from utils.menu_ui import reply
from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from utils.perms import is_leitung, is_owner

# Name (kleingeschrieben) -> Stufe + Stundenlohn-Hinweis
RANG_TABELLE = {
    "gast": 0,
    "kunde": 0,
    "aushilfe": 1,
    "mitarbeiter": 2,
    "verkauf": 3,
    "warehouse": 3,
    "tänzer/in": 3,
    "taenzer/in": 3,
    "security": 3,
    "schichtleitung": 5,
    "buchhaltung": 5,
    "leitung": 8,
    "admin": 10,
}

STUNDENLOHN = {
    0: 0,
    1: 500,
    2: 1500,
    3: 3000,
    5: 5000,
    8: 7000,
    10: 8000,
}


def get_rang(member: discord.Member) -> tuple[int, str]:
    best = 0
    best_name = "ohne Rang"
    for r in member.roles:
        key = r.name.strip().lower()
        if key in RANG_TABELLE:
            lvl = RANG_TABELLE[key]
            if lvl >= best:
                best = lvl
                best_name = r.name
    if member.guild_permissions.administrator or member.id == member.guild.owner_id:
        return 99, "Inhaber/Admin"
    return best, best_name


def stundenlohn(member: discord.Member) -> int:
    lvl, _ = get_rang(member)
    if lvl >= 99:
        return STUNDENLOHN.get(10, 8000)
    # nearest
    best = 0
    for k, v in STUNDENLOHN.items():
        if k <= lvl:
            best = v
    return best


class Rang(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="rang", description="Dein Rang & Stundenlohn-Stufe")
    async def rang(self, interaction: discord.Interaction, user: discord.Member = None):
        target = user or interaction.user
        lvl, name = get_rang(target)
        lohn = stundenlohn(target)
        embed = discord.Embed(
            title=f"🎖️ Rang – {target.display_name}",
            color=0xFACC15,
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Rang", value=f"**{name}** (Stufe {lvl})", inline=True)
        embed.add_field(name="Stundenlohn-Stufe", value=f"**{lohn:,} $**/h (Richtwert)", inline=True)
        await reply(interaction, embed=embed, ephemeral=True)

    @app_commands.command(name="rang-liste", description="Alle Rang-Stufen (Firma)")
    async def rang_liste(self, interaction: discord.Interaction):
        lines = [
            "`0` Gast / Kunde",
            "`1` Aushilfe",
            "`2` Mitarbeiter",
            "`3` Verkauf / Warehouse / Tänzer / Security",
            "`5` Schichtleitung / Buchhaltung",
            "`8` Leitung",
            "`10` Admin",
            "`99` Server-Inhaber",
        ]
        embed = discord.Embed(
            title="🎖️ USHERO Rangsystem",
            description="\n".join(lines) + "\n\nRollen in Discord = Rang. `/rang` zeigt deine Stufe.",
            color=0x8B5CF6
        )
        await reply(interaction, embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Rang(bot))
