from utils.logging_ch import send_audit
from utils.menu_ui import reply
from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
import json

from utils.database import add_warning, get_warnings, log_audit

from utils.config import CONFIG


class Admin(commands.Cog):
    """Admin, Warnungen, Bewerbungen, Übersicht"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ---------- Warnsystem ----------
    warn = app_commands.Group(name="warn", description="Warnsystem")

    @warn.command(name="add", description="User verwarnen")
    @app_commands.describe(user="Wen verwarnen", grund="Grund der Verwarnung")
    async def warn_add(self, interaction: discord.Interaction, user: discord.Member, grund: str):
        if not interaction.user.guild_permissions.moderate_members:
            await reply(interaction, "❌ Keine Berechtigung.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        await add_warning(user.id, interaction.user.id, grund)
        await log_audit("warn", interaction.user.id, user.id, grund)

        warns = await get_warnings(user.id)
        embed = discord.Embed(
            title="⚠️ Verwarnung erteilt",
            color=0xE67E22,
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="User", value=user.mention, inline=True)
        embed.add_field(name="Von", value=interaction.user.mention, inline=True)
        embed.add_field(name="Grund", value=grund, inline=False)
        embed.add_field(name="Anzahl Warns", value=str(len(warns)), inline=True)

        await reply(interaction, embed=embed)

        try:
            await user.send(f"⚠️ Du hast eine Verwarnung auf **{interaction.guild.name}** erhalten.\nGrund: {grund}")
        except Exception:
            pass

    @warn.command(name="list", description="Warnungen eines Users anzeigen")
    async def warn_list(self, interaction: discord.Interaction, user: discord.Member):
        await interaction.response.defer(ephemeral=True)
        warns = await get_warnings(user.id)
        if not warns:
            await reply(interaction, f"{user.mention} hat keine Verwarnungen.")
            return
        embed = discord.Embed(
            title=f"⚠️ Warnungen von {user.display_name}",
            color=0xE67E22
        )
        for w in warns[:25]:
            mod = interaction.guild.get_member(w["moderator_id"])
            mod_name = mod.display_name if mod else str(w["moderator_id"])
            embed.add_field(
                name=f"#{w['id']} – {w['created_at'][:10]}",
                value=f"Von: {mod_name}\nGrund: {w['reason']}",
                inline=False
            )
        await reply(interaction, embed=embed)

    # ---------- Bewerbungen ----------
    bewerbung = app_commands.Group(name="bewerbung", description="Mitarbeiter-Bewerbungen")

    @bewerbung.command(name="stellen", description="Bewerbung absenden")
    @app_commands.describe(
        position="Für welche Position (Verkauf / VIP / Tänzer / Security / ...)",
        text="Deine Bewerbung / Erfahrung"
    )
    async def bewerbung_stellen(self, interaction: discord.Interaction, position: str, text: str):
        await interaction.response.defer(ephemeral=True)
        import aiosqlite
        from utils.database import DB_PATH
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                """INSERT INTO applications (user_id, position, text, status, created_at)
                   VALUES (?, ?, ?, 'pending', ?)""",
                (interaction.user.id, position, text, utcnow().isoformat())
            )
            await db.commit()

        await log_audit("application", interaction.user.id, details=position)

        embed = discord.Embed(
            title="📝 Bewerbung eingegangen",
            description=f"**Position:** {position}\n\n{text}",
            color=0x9B59B6,
            timestamp=discord.utils.utcnow()
        )
        embed.set_author(name=interaction.user.display_name, icon_url=interaction.user.display_avatar.url)

        await reply(interaction, "✅ Deine Bewerbung wurde gespeichert. Die Leitung wird sich melden.", ephemeral=True)

        # Optional: an einen Bewerbungs-Channel senden
        channel = discord.utils.get(interaction.guild.text_channels, name="bewerbungen")
        if channel:
            try:
                await send_audit(interaction.guild, embed=embed, preferred=('bewerbungen',))
            except Exception:
                pass

    @bewerbung.command(name="liste", description="Offene Bewerbungen anzeigen (Leitung)")
    async def bewerbung_liste(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.manage_roles:
            await reply(interaction, "❌ Keine Berechtigung.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        import aiosqlite
        from utils.database import DB_PATH
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM applications WHERE status = 'pending' ORDER BY created_at DESC LIMIT 20"
            ) as c:
                rows = await c.fetchall()

        if not rows:
            await reply(interaction, "Keine offenen Bewerbungen.")
            return

        embed = discord.Embed(title="📋 Offene Bewerbungen", color=0x9B59B6)
        for r in rows[:25]:
            user = interaction.guild.get_member(r["user_id"])
            name = user.mention if user else str(r["user_id"])
            embed.add_field(
                name=f"#{r['id']} – {r['position']}",
                value=f"{name}\n{r['text'][:100]}...",
                inline=False
            )
        await reply(interaction, embed=embed)

    # ---------- Übersicht / Stats ----------
    @app_commands.command(name="stats", description="Schnellübersicht aller Summen")
    async def stats(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        from utils.database import get_sales_sum, get_vip_sum, get_security_sum

        verkauf = await get_sales_sum(category="verkauf")
        taenzer = await get_sales_sum(category="taenzer")
        vip = await get_vip_sum()
        security = await get_security_sum()

        total = verkauf + taenzer + vip

        embed = discord.Embed(
            title="📊 Server Übersicht",
            color=CONFIG.get("embed_color", 0x9B59B6),
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="💰 Verkauf", value=f"{verkauf:.2f} {CONFIG['currency']}", inline=True)
        embed.add_field(name="💃 Tänzer", value=f"{taenzer:.2f} {CONFIG['currency']}", inline=True)
        embed.add_field(name="⭐ VIP", value=f"{vip:.2f} {CONFIG['currency']}", inline=True)
        embed.add_field(name="🛡️ Security Löhne", value=f"{security:.2f} {CONFIG['currency']}", inline=True)
        embed.add_field(name="📈 Einnahmen gesamt", value=f"**{total:.2f} {CONFIG['currency']}**", inline=False)

        await reply(interaction, embed=embed)

    @app_commands.command(name="befehle", description="Detaillierte Command-Liste")
    async def hilfe(self, interaction: discord.Interaction):
        from utils.menu_ui import open_home
        await open_home(interaction)


async def setup(bot: commands.Bot):
    await bot.add_cog(Admin(bot))
