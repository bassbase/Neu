"""VIP-Laufzeiten, Daily Report, Hinweise #kasse."""
from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, timedelta, timezone
import aiosqlite
import json

from utils.database import DB_PATH, get_sales_sum, get_vip_sum, get_security_sum, log_audit
from utils.perms import is_leitung, is_owner, is_staff, deny_guest_message

from utils.config import CONFIG
CURRENCY = CONFIG.get("currency", "$")


async def init_vip_members():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS vip_members (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                months INTEGER,
                started_at TEXT,
                ends_at TEXT,
                sold_by INTEGER,
                note TEXT,
                status TEXT DEFAULT 'aktiv'
            )
        """)
        await db.commit()


class LogsReport(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await init_vip_members()

    @app_commands.command(name="vip-karte", description="VIP für 1/2/3 Monate buchen")
    @app_commands.describe(mitglied="VIP-Gast", monate="Laufzeit", notiz="Optional")
    @app_commands.choices(monate=[
        app_commands.Choice(name="1 Monat", value=1),
        app_commands.Choice(name="2 Monate", value=2),
        app_commands.Choice(name="3 Monate", value=3),
    ])
    async def vip_karte(self, interaction: discord.Interaction, mitglied: discord.Member,
                        monate: app_commands.Choice[int], notiz: str = ""):
        if not is_staff(interaction.user):
            await interaction.response.send_message(deny_guest_message(), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        await init_vip_members()
        start = utcnow()
        end = start + timedelta(days=30 * monate.value)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                """INSERT INTO vip_members (user_id, months, started_at, ends_at, sold_by, note, status)
                   VALUES (?, ?, ?, ?, ?, ?, 'aktiv')""",
                (mitglied.id, monate.value, start.isoformat(), end.isoformat(),
                 interaction.user.id, notiz)
            )
            await db.commit()
        await log_audit("vip_karte", interaction.user.id, mitglied.id, f"{monate.value} Monate")
        embed = discord.Embed(
            title="👑 VIP-Karte aktiviert",
            description=f"{mitglied.mention} – **{monate.value} Monat(e)**\nLäuft ab: <t:{int(end.replace(tzinfo=timezone.utc).timestamp())}:D>",
            color=0xFACC15
        )
        if notiz:
            embed.add_field(name="Notiz", value=notiz)
        await interaction.followup.send(embed=embed, ephemeral=True)
        kasse = discord.utils.get(interaction.guild.text_channels, name="kasse")
        if kasse:
            try:
                await kasse.send(
                    f"👑 VIP {mitglied.mention} · {monate.value} Mon. · bis <t:{int(end.replace(tzinfo=timezone.utc).timestamp())}:D> · von {interaction.user.mention}"
                )
            except Exception:
                pass

    @app_commands.command(name="vip-ablauf", description="Bald ablaufende VIP-Karten")
    async def vip_ablauf(self, interaction: discord.Interaction):
        if not is_staff(interaction.user):
            await interaction.response.send_message(deny_guest_message(), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        await init_vip_members()
        soon = (utcnow() + timedelta(days=7)).isoformat()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                """SELECT * FROM vip_members WHERE status='aktiv' AND ends_at <= ? ORDER BY ends_at""",
                (soon,)
            ) as c:
                rows = await c.fetchall()
        if not rows:
            await interaction.followup.send("Keine VIP-Karten, die in 7 Tagen ablaufen.")
            return
        embed = discord.Embed(title="⏰ VIP läuft bald ab", color=0xF59E0B)
        for r in rows[:25]:
            m = interaction.guild.get_member(r["user_id"])
            embed.add_field(
                name=m.display_name if m else str(r["user_id"]),
                value=f"Ende: `{r['ends_at'][:10]}` ({r['months']} Mon.)",
                inline=False
            )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="daily-report", description="Tagesreport (Leitung)")
    async def daily_report(self, interaction: discord.Interaction):
        if not is_leitung(interaction.user) and not is_owner(interaction.user):
            await interaction.response.send_message("❌ Nur Leitung / Inhaber.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        v = await get_sales_sum(category="verkauf")
        w = await get_sales_sum(category="warehouse")
        t = await get_sales_sum(category="taenzer")
        vip = await get_vip_sum()
        sec = await get_security_sum()
        total = v + w + t + vip
        embed = discord.Embed(
            title="📋 Daily Report",
            description="Gäste · Umsatz · Waren · Gehälter · Überblick",
            color=0x8B5CF6,
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Sales / Verkauf", value=f"{v:,.0f} {CURRENCY}", inline=True)
        embed.add_field(name="Warehouse", value=f"{w:,.0f} {CURRENCY}", inline=True)
        embed.add_field(name="Tänzer", value=f"{t:,.0f} {CURRENCY}", inline=True)
        embed.add_field(name="VIP", value=f"{vip:,.0f} {CURRENCY}", inline=True)
        embed.add_field(name="Security-Löhne", value=f"{sec:,.0f} {CURRENCY}", inline=True)
        embed.add_field(name="Umsatz gesamt", value=f"**{total:,.0f} {CURRENCY}**", inline=False)
        embed.set_footer(text="Logs: Sales · Food/Drink über Warehouse · VIP · Entry über Security-Notizen")
        await interaction.followup.send(embed=embed, ephemeral=True)
        log_ch = discord.utils.get(interaction.guild.text_channels, name="bot-logs")
        if log_ch:
            try:
                await log_ch.send(embed=embed)
            except Exception:
                pass


async def setup(bot: commands.Bot):
    await bot.add_cog(LogsReport(bot))
