from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

OLD_ROLES = [
    "Gast", "Kunde", "VIP-Kunde", "Mitarbeiter", "Verkauf", "VIP", "Tänzer/in",
    "Security", "Warehouse", "Schichtleitung", "Buchhaltung", "Leitung", "Admin", "Aushilfe",
]

NEW_ROLES = [
    ("Gast", discord.Colour.light_grey()),
    ("Kunde", discord.Colour.from_rgb(220, 220, 220)),
    ("VIP-Kunde", discord.Colour.gold()),
    ("Aushilfe", discord.Colour.from_rgb(150, 150, 150)),
    ("Mitarbeiter", discord.Colour.blue()),
    ("Verkauf", discord.Colour.green()),
    ("VIP", discord.Colour.gold()),
    ("Warehouse", discord.Colour.purple()),
    ("Tänzer/in", discord.Colour.magenta()),
    ("Security", discord.Colour.dark_blue()),
    ("Schichtleitung", discord.Colour.orange()),
    ("Buchhaltung", discord.Colour.teal()),
    ("Leitung", discord.Colour.red()),
    ("Admin", discord.Colour.dark_red()),
]


def _r(guild, name):
    return discord.utils.get(guild.roles, name=name)


async def ow_public(guild):
    ow = {guild.default_role: discord.PermissionOverwrite(view_channel=True, send_messages=False, read_message_history=True)}
    if guild.me:
        ow[guild.me] = discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_messages=True)
    return ow


async def ow_team(guild, extra=None, readonly_team=False):
    ow = {guild.default_role: discord.PermissionOverwrite(view_channel=False)}
    team = ["Aushilfe", "Mitarbeiter", "Verkauf", "Warehouse", "VIP", "Tänzer/in", "Security",
            "Schichtleitung", "Buchhaltung", "Leitung", "Admin"]
    if extra:
        team = list(dict.fromkeys(team + extra))
    for n in team:
        r = _r(guild, n)
        if r:
            ow[r] = discord.PermissionOverwrite(
                view_channel=True,
                send_messages=not readonly_team,
                read_message_history=True
            )
    if guild.me:
        ow[guild.me] = discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_messages=True)
    return ow


async def ow_leitung(guild):
    ow = {guild.default_role: discord.PermissionOverwrite(view_channel=False)}
    for n in ("Schichtleitung", "Buchhaltung", "Leitung", "Admin"):
        r = _r(guild, n)
        if r:
            ow[r] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
    if guild.me:
        ow[guild.me] = discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_messages=True)
    return ow


async def ow_kasse(guild):
    """Team darf lesen, nur Leitung/Buchhaltung + Bot schreiben."""
    ow = {guild.default_role: discord.PermissionOverwrite(view_channel=False)}
    for n in ("Mitarbeiter", "Verkauf", "Warehouse", "VIP", "Tänzer/in", "Security", "Aushilfe", "Schichtleitung"):
        r = _r(guild, n)
        if r:
            ow[r] = discord.PermissionOverwrite(view_channel=True, send_messages=False, read_message_history=True)
    for n in ("Buchhaltung", "Leitung", "Admin"):
        r = _r(guild, n)
        if r:
            ow[r] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
    if guild.me:
        ow[guild.me] = discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_messages=True)
    return ow


class SetupServer(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="setup", description="USHERO Server sauber aufbauen (Rollen + Channels + Rechte)")
    @app_commands.default_permissions(administrator=True)
    async def setup_cmd(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Nur Administrator.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        log = []
        bot_top = guild.me.top_role

        log.append("**── Rollen ──**")
        # Vorhandene Rollen und deren Mitglieder werden niemals geloescht.
        for name, colour in NEW_ROLES:
            if discord.utils.get(guild.roles, name=name):
                continue
            try:
                await guild.create_role(name=name, colour=colour, reason="USHERO Setup")
                log.append(f"✅ {name}")
            except Exception as e:
                log.append(f"❌ {name}: {e}")

        # (Kategorie, [(channel, mode), ...])
        structure = [
            ("📢｜USHERO Info", [
                ("willkommen", "public"), ("regeln", "public"),
                ("ankündigungen", "public"), ("abschied", "public"),
            ]),
            ("💰｜Verkauf & Kasse", [
                ("verkauf", "team"), ("kasse", "kasse"),
            ]),
            ("🏭｜Warehouse", [
                ("warehouse-bestellungen", "team"),
                ("warehouse-lager", "team"),
                ("lager-warnungen", "team"),
            ]),
            ("⭐｜VIP", [
                ("vip", "team"),
            ]),
            ("💃｜Entertainment", [
                ("taenzer", "team"), ("buchungen", "team"),
            ]),
            ("🛡️｜Security", [
                ("security", "team"), ("entry-log", "team"),
            ]),
            ("⏱️｜Dienst & Personal", [
                ("dienstplan", "team"), ("stempel-logs", "team"),
                ("mitarbeiter-chat", "team"), ("bewerbungen", "team"),
            ]),
            ("📒｜Büro", [
                ("buchhaltung", "leitung"), ("abrechnungen", "leitung"),
                ("stats", "leitung"),
            ]),
            ("📜｜Logs", [
                ("sales-log", "leitung"), ("vip-log", "leitung"),
                ("daily-report", "leitung"), ("audit-logs", "leitung"),
                ("bot-logs", "leitung"),
            ]),
            ("🧠｜Leitung privat", [
                ("ki-panel", "leitung"), ("ki-berichte", "leitung"),
            ]),
        ]

        log.append("\n**── Channels ──**")
        for cat_name, channels in structure:
            cat = discord.utils.get(guild.categories, name=cat_name)
            if not cat:
                try:
                    cat = await guild.create_category(cat_name, reason="USHERO Setup")
                    log.append(f"✅ {cat_name}")
                except Exception as e:
                    log.append(f"❌ {cat_name}: {e}")
                    continue
            for ch_name, mode in channels:
                if discord.utils.get(guild.text_channels, name=ch_name):
                    log.append(f"  #{ch_name} existiert")
                    continue
                try:
                    if mode == "public":
                        ow = await ow_public(guild)
                    elif mode == "kasse":
                        ow = await ow_kasse(guild)
                    elif mode == "leitung":
                        ow = await ow_leitung(guild)
                    else:
                        ow = await ow_team(guild)
                    await guild.create_text_channel(ch_name, category=cat, overwrites=ow, reason="USHERO Setup")
                    log.append(f"  ✅ #{ch_name}")
                except Exception as e:
                    log.append(f"  ❌ #{ch_name}: {e}")

        embed = discord.Embed(
            title="🌙 USHERO Setup fertig",
            description="\n".join(log[:55]),
            color=0x8B5CF6,
            timestamp=discord.utils.utcnow()
        )
        embed.set_footer(text="Gäste → Info | Team → Bereiche | #kasse nur lesen | Büro/Logs → Leitung")
        await interaction.followup.send(embed=embed)

        # Willkommenstext
        w = discord.utils.get(guild.text_channels, name="willkommen")
        if w:
            try:
                await w.send(embed=discord.Embed(
                    title="🌙 Willkommen bei USHERO",
                    description=(
                        "**Mitarbeiter:** tippe `/start`\n"
                        "Dann: `/dienst` → `/arbeit` → am Ende `/mein-panel`\n\n"
                        "Gäste: Regeln & Ankündigungen lesen."
                    ),
                    color=0x8B5CF6
                ))
            except Exception:
                pass


async def setup(bot):
    await bot.add_cog(SetupServer(bot))
