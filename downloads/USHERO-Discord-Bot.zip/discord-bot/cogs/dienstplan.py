"""Echter Dienstplan – eintragen, anzeigen, ohne OpenAI."""
from utils.logging_ch import send_audit
from utils.menu_ui import reply
from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, date, timedelta
import aiosqlite

from utils.database import DB_PATH, log_audit
from utils.perms import is_leitung, is_staff, deny_guest_message, role_names

BEREICHE = ["Verkauf", "Warehouse", "VIP", "Tänzer", "Security", "Leitung", "Allgemein"]


async def init_plan():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS dienstplan (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                tag TEXT,
                bereich TEXT,
                von TEXT,
                bis TEXT,
                note TEXT,
                created_by INTEGER,
                created_at TEXT
            )
        """)
        await db.commit()


class Dienstplan(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await init_plan()

    plan = app_commands.Group(name="dienstplan", description="Dienstplan der Firma")

    @plan.command(name="eintragen", description="Schicht in den Plan eintragen")
    @app_commands.describe(
        mitarbeiter="Wer",
        bereich="Abteilung",
        tag="Datum YYYY-MM-DD (leer = heute)",
        von="z.B. 20:00",
        bis="z.B. 04:00",
        notiz="Optional"
    )
    @app_commands.choices(bereich=[app_commands.Choice(name=b, value=b) for b in BEREICHE])
    async def eintragen(
        self, interaction: discord.Interaction,
        mitarbeiter: discord.Member,
        bereich: app_commands.Choice[str],
        von: str,
        bis: str,
        tag: str = "",
        notiz: str = ""
    ):
        if not is_leitung(interaction.user) and not is_staff(interaction.user):
            await reply(interaction, deny_guest_message(), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        await init_plan()
        if mitarbeiter.id != interaction.user.id and not is_leitung(interaction.user):
            raise ValueError("Nur die Leitung darf andere Mitarbeiter einplanen.")
        if not tag:
            tag = date.today().isoformat()
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                """INSERT INTO dienstplan (user_id, tag, bereich, von, bis, note, created_by, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (mitarbeiter.id, tag, bereich.value, von, bis, notiz,
                 interaction.user.id, utcnow().isoformat())
            )
            await db.commit()
        try:
            await log_audit("dienstplan", interaction.user.id, mitarbeiter.id, f"{tag} {bereich.value}")
        except Exception:
            pass
        embed = discord.Embed(
            title="📅 Schicht eingetragen",
            description=f"{mitarbeiter.mention} · **{bereich.value}**\n`{tag}` {von}–{bis}",
            color=0x2ECC71
        )
        if notiz:
            embed.add_field(name="Notiz", value=notiz)
        await reply(interaction, embed=embed, ephemeral=True)
        ch = discord.utils.get(interaction.guild.text_channels, name="dienstplan")
        if ch:
            try:
                await send_audit(
                interaction.guild,
                    f"📅 **{tag}** {von}–{bis} · {bereich.value} · {mitarbeiter.mention}"
                    + (f" · {notiz}" if notiz else "")
                , preferred=('dienstplan-logs', 'audit-logs'))
            except Exception:
                pass

    @plan.command(name="heute", description="Heutiger Dienstplan")
    async def heute(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await init_plan()
        tag = date.today().isoformat()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM dienstplan WHERE tag = ? AND (?=1 OR user_id=?) ORDER BY von, bereich", (tag,int(is_leitung(interaction.user) or "Schichtleitung" in role_names(interaction.user)),interaction.user.id)
            ) as c:
                rows = await c.fetchall()
        if not rows:
            await reply(interaction, f"Kein Eintrag für **{tag}**. Leitung: Dienstplan → Schicht eintragen")
            return
        embed = discord.Embed(title=f"📅 Dienstplan – {tag}", color=0x3498DB)
        for r in rows[:25]:
            m = interaction.guild.get_member(r["user_id"])
            name = m.display_name if m else str(r["user_id"])
            embed.add_field(
                name=f"{r['von']}–{r['bis']} · {r['bereich']}",
                value=f"{name}" + (f"\n_{r['note']}_" if r["note"] else ""),
                inline=False
            )
        await reply(interaction, embed=embed, ephemeral=True)

    @plan.command(name="zeigen", description="Plan für ein Datum")
    @app_commands.describe(tag="YYYY-MM-DD (leer = heute)")
    async def zeigen(self, interaction: discord.Interaction, tag: str = ""):
        await interaction.response.defer(ephemeral=True)
        await init_plan()
        if not tag:
            tag = date.today().isoformat()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM dienstplan WHERE tag = ? AND (?=1 OR user_id=?) ORDER BY von", (tag,int(is_leitung(interaction.user) or "Schichtleitung" in role_names(interaction.user)),interaction.user.id)
            ) as c:
                rows = await c.fetchall()
        if not rows:
            await reply(interaction, f"Nichts für `{tag}`.")
            return
        lines = []
        for r in rows[:25]:
            m = interaction.guild.get_member(r["user_id"])
            lines.append(
                f"• **{r['von']}–{r['bis']}** {r['bereich']}: "
                f"{m.display_name if m else r['user_id']}"
            )
        embed = discord.Embed(title=f"📅 Dienstplan {tag}", description="\n".join(lines), color=0x3498DB)
        await reply(interaction, embed=embed, ephemeral=True)

    @plan.command(name="meine", description="Meine eingetragenen Schichten")
    async def meine(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await init_plan()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM dienstplan WHERE user_id = ? ORDER BY tag DESC LIMIT 15",
                (interaction.user.id,)
            ) as c:
                rows = await c.fetchall()
        if not rows:
            await reply(interaction, "Du hast keine Plan-Einträge.")
            return
        text = "\n".join(
            f"• `{r['tag']}` {r['von']}–{r['bis']} **{r['bereich']}**" for r in rows
        )
        await reply(interaction, embed=discord.Embed(
            title="📅 Meine Schichten", description=text, color=0x9B59B6
        ))

    @plan.command(name="loeschen", description="Plan-Eintrag löschen (Leitung)")
    async def loeschen(self, interaction: discord.Interaction, eintrag_id: int):
        if not is_leitung(interaction.user) and not interaction.user.guild_permissions.manage_guild:
            await reply(interaction, "❌ Nur Leitung.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute("DELETE FROM dienstplan WHERE id = ?", (eintrag_id,))
            if not cursor.rowcount:
                await reply(interaction, "Kein Dienstplan-Eintrag mit dieser Nummer.", ephemeral=True)
                return
            await db.commit()
        await reply(interaction, f"🗑️ Eintrag #{eintrag_id} gelöscht.")


async def setup(bot):
    await bot.add_cog(Dienstplan(bot))
