"""Artikel-Auswahl, Mengenformular und atomarer Warenkorb-Abschluss."""
from utils.logging_ch import send_audit
from utils.clock import utcnow
import asyncio
import os
import discord
from discord.ext import commands
from discord import app_commands
import aiosqlite
from datetime import datetime
from utils.config import MENU
from utils.database import DB_PATH, add_sale, get_sales, get_sales_sum
from utils.menu_ui import OwnedView, reply, validate
from utils.perms import can_use_area
from utils.sheets import sheets_post

ARTIKEL={name:price for category,items in MENU.items() if category not in ('warehouse','box_inhalte') for name,price in items.items()}


class QuantityModal(discord.ui.Modal,title='Artikel hinzufügen'):
    menge=discord.ui.TextInput(label='Menge',default='1',max_length=5)

    def __init__(self,cart,item):
        super().__init__()
        self.cart=cart; self.item=item

    async def on_submit(self,interaction):
        if not await self.cart.interaction_check(interaction): return
        try: quantity=int(self.menge.value)
        except ValueError: raise ValueError('Bitte eine ganze Menge eingeben.') from None
        validate({'menge':quantity})
        async with self.cart.lock:
            if self.cart.completed: return await reply(interaction,'Dieser Warenkorb ist bereits abgeschlossen.')
            new=self.cart.cart.get(self.item,0)+quantity
            validate({'menge':new})
            self.cart.cart[self.item]=new
            await interaction.response.edit_message(embed=self.cart.embed(),view=self.cart)

    async def on_error(self,interaction,error):
        from utils.menu_ui import show_error
        await show_error(interaction,error)


class WarenkorbView(OwnedView):
    def __init__(self,user):
        super().__init__(user.id)
        self.cart={};self.completed=False;self.lock=asyncio.Lock()
        select=discord.ui.Select(placeholder='Artikel auswählen …',options=[discord.SelectOption(label=a,value=a,description=f'{p:,.0f} $ pro Stück') for a,p in ARTIKEL.items()])
        async def choose(interaction):
            await interaction.response.send_modal(QuantityModal(self,select.values[0]))
        select.callback=choose; self.add_item(select)
        clear=discord.ui.Button(label='Warenkorb leeren',style=discord.ButtonStyle.secondary)
        async def empty(interaction):
            async with self.lock:
                if self.completed: return await reply(interaction,'Bereits abgeschlossen.')
                self.cart.clear()
                await interaction.response.edit_message(embed=self.embed(),view=self)
        clear.callback=empty;self.add_item(clear)
        finish=discord.ui.Button(label='Verkauf abschließen',emoji='✅',style=discord.ButtonStyle.success)
        finish.callback=self.finish;self.add_item(finish)

    async def interaction_check(self,interaction):
        if not await super().interaction_check(interaction): return False
        if not can_use_area(interaction.user,'verkauf'):
            await reply(interaction,'❌ Kein Zugriff auf Verkauf.');return False
        return True

    def total(self): return sum(ARTIKEL[a]*n for a,n in self.cart.items())

    def embed(self):
        lines=[f'**{a}** × {n} · {ARTIKEL[a]*n:,.0f} $' for a,n in self.cart.items()]
        return discord.Embed(title='💰 USHERO · Warenkorb',description=('\n'.join(lines) or 'Noch leer. Wähle einen Artikel und gib die Menge ein.')+f'\n\n**Gesamt: {self.total():,.0f} $**',color=0x00D9E8)

    async def finish(self,interaction):
        async with self.lock:
            if self.completed: return await reply(interaction,'Dieser Warenkorb ist bereits verbucht.')
            if not self.cart: return await reply(interaction,'Der Warenkorb ist leer.')
            await interaction.response.defer(ephemeral=True)
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute('BEGIN IMMEDIATE')
                now=utcnow().isoformat()
                for item,quantity in self.cart.items():
                    await db.execute("INSERT INTO sales(seller_id,item,amount,quantity,category,created_at) VALUES(?,?,?,?,'verkauf',?)",(interaction.user.id,item,ARTIKEL[item],quantity,now))
                await db.execute("INSERT INTO audit_logs(action,user_id,details,created_at) VALUES('verkauf',?,?,?)",(interaction.user.id,f'{len(self.cart)} Artikel, Summe {self.total()}',now))
                await db.commit()
            self.completed=True
            for child in self.children: child.disabled=True
            await interaction.edit_original_response(embed=self.embed(),view=self)
            await reply(interaction,f'✅ Verkauf über **{self.total():,.0f} $** lokal gespeichert. Die Beträge stehen jetzt zur Abrechnung bereit.')
            if os.getenv('ENABLE_SHEETS','false').lower()=='true':
                result=await sheets_post({'type':'verkauf','mitarbeiter':interaction.user.display_name,
                    'artikel':'\n'.join(f'{a} × {n}' for a,n in self.cart.items()),'gesamt':self.total(),'zeit':utcnow().isoformat()})
                await reply(interaction,'✅ Sheets-Kopie bestätigt.' if result.get('ok') else '⚠️ Sheets-Kopie nicht bestätigt. Lokal ist der Verkauf bereits gespeichert; nicht erneut buchen.')
            channel=discord.utils.get(interaction.guild.text_channels,name='kasse-logs') or discord.utils.get(interaction.guild.text_channels,name='sales-log')
            if channel:
                try: await send_audit(interaction.guild, embed=self.embed(), preferred=('sales-log', 'kasse-logs', 'kasse'))
                except discord.HTTPException: pass


class Verkauf(commands.Cog):
    def __init__(self,bot): self.bot=bot

    @app_commands.command(name='verkauf',description='Warenkorb mit Artikelauswahl öffnen')
    async def verkauf(self,interaction: discord.Interaction):
        view=WarenkorbView(interaction.user)
        await reply(interaction,embed=view.embed(),view=view)

    @app_commands.command(name='verkauf_artikel',description='Einzelnen Artikel direkt buchen (alternativ zum Warenkorb)')
    @app_commands.choices(artikel=[app_commands.Choice(name=n,value=n) for n in ARTIKEL])
    async def verkauf_artikel(self,interaction: discord.Interaction,artikel: app_commands.Choice[str],menge: int=1):
        await interaction.response.defer(ephemeral=True)
        validate({'menge':menge})
        await add_sale(interaction.user.id,artikel.value,ARTIKEL[artikel.value],menge)
        await reply(interaction,f'✅ {artikel.value} × {menge} = {ARTIKEL[artikel.value]*menge:,.0f} $ lokal gespeichert.')
        if os.getenv('ENABLE_SHEETS','false').lower()=='true':
            result=await sheets_post({'type':'verkauf','mitarbeiter':interaction.user.display_name,'artikel':f'{artikel.value} × {menge}',
                'gesamt':ARTIKEL[artikel.value]*menge,'zeit':utcnow().isoformat()})
            await reply(interaction,'✅ Sheets-Kopie bestätigt.' if result.get('ok') else '⚠️ Sheets-Kopie nicht bestätigt. Lokal gespeichert; nicht erneut buchen.')

    @app_commands.command(name='preisliste',description='Alle aktuellen Artikelpreise anzeigen')
    async def preisliste(self,interaction: discord.Interaction):
        await reply(interaction,embed=discord.Embed(title='📋 USHERO · Preisliste',description='\n'.join(f'**{n}** · {p:,.0f} $' for n,p in ARTIKEL.items()),color=0xEB459E))

    @app_commands.command(name='meine-verkaeufe',description='Deine letzten Verkäufe anzeigen')
    async def history(self,interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        sales=await get_sales(category='verkauf',seller_id=interaction.user.id,limit=20)
        embed=discord.Embed(title='🧾 USHERO · Meine Verkäufe',color=0x00D9E8)
        embed.description='\n'.join(f"**{s['item']}** × {s['quantity']} · {s['amount']*s['quantity']:,.2f} $" for s in sales)[:4000] or 'Noch keine Verkäufe.'
        await reply(interaction,embed=embed)

    @app_commands.command(name='verkauf-summe',description='Gesamtsumme der Verkäufe anzeigen')
    async def summe(self,interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        total=await get_sales_sum(category='verkauf')
        await reply(interaction,f'💰 Verkauf insgesamt: **{total:,.2f} $**')


async def setup(bot): await bot.add_cog(Verkauf(bot))
