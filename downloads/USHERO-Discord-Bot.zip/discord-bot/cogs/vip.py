from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
import json

from utils.database import add_vip, get_vip_sum, log_audit

from utils.config import CONFIG


class VIP(commands.Cog):
    """VIP Bereich"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    vip = app_commands.Group(name="vip", description="VIP Verkäufe & Empfänger")

    @vip.command(name="add", description="VIP-Eintrag erstellen")
    @app_commands.describe(
        empfaenger="Wer hat den VIP-Service bekommen",
        preis="Betrag",
        beschreibung="Optional: Was genau"
    )
    async def vip_add(
        self,
        interaction: discord.Interaction,
        empfaenger: discord.Member,
        preis: float,
        beschreibung: str = "VIP Service"
    ):
        await interaction.response.defer(ephemeral=True)
        await add_vip(
            seller_id=interaction.user.id,
            receiver_id=empfaenger.id,
            amount=preis,
            description=beschreibung
        )
        await log_audit("vip_add", interaction.user.id, empfaenger.id, f"{preis} - {beschreibung}")

        embed = discord.Embed(
            title="⭐ VIP eingetragen",
            color=0xF1C40F,
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Verkäufer", value=interaction.user.mention, inline=True)
        embed.add_field(name="Empfänger", value=empfaenger.mention, inline=True)
        embed.add_field(name="Betrag", value=f"**{preis} {CONFIG['currency']}**", inline=True)
        embed.add_field(name="Beschreibung", value=beschreibung, inline=False)

        await interaction.followup.send(embed=embed)

        try:
            await interaction.channel.send(
                f"⭐ **VIP:** {beschreibung} → {empfaenger.mention} "
                f"({preis} {CONFIG['currency']}) von {interaction.user.mention}"
            )
        except Exception:
            pass

    @vip.command(name="summe", description="VIP Gesamtsumme")
    async def vip_summe(self, interaction: discord.Interaction, nur_ich: bool = False):
        await interaction.response.defer(ephemeral=True)
        seller_id = interaction.user.id if nur_ich else None
        total = await get_vip_sum(seller_id)
        title = "Deine VIP-Summe" if nur_ich else "Gesamte VIP-Summe"
        embed = discord.Embed(
            title=f"⭐ {title}",
            description=f"**{total:.2f} {CONFIG['currency']}**",
            color=0xF1C40F,
            timestamp=discord.utils.utcnow()
        )
        await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(VIP(bot))
