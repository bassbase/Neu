from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, date
import json
import aiosqlite

from utils.database import DB_PATH, log_audit, get_sales, get_sales_sum, get_vip_sum

from utils.config import CONFIG

CURRENCY = CONFIG.get("currency", "$")

# Standard: Anteil der FIRMA (Rest = Mitarbeiter)
DEFAULT_FIRMA_PROZENT = 80  # Firma 80%, Mitarbeiter 20%


async def init_buchhaltung_tables():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS firmenkasse (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                balance REAL DEFAULT 0,
                updated_at TEXT
            )
        """)
        await db.execute(
            "INSERT OR IGNORE INTO firmenkasse (id, balance, updated_at) VALUES (1, 0, ?)",
            (utcnow().isoformat(),)
        )
        await db.execute("""
            CREATE TABLE IF NOT EXISTS abrechnungen (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                brutto REAL,
                firma_prozent REAL,
                firma_anteil REAL,
                mitarbeiter_anteil REAL,
                details TEXT,
                created_at TEXT,
                status TEXT DEFAULT 'abgeschlossen'
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        await db.execute(
            "INSERT OR IGNORE INTO settings (key, value) VALUES ('firma_prozent', ?)",
            (str(DEFAULT_FIRMA_PROZENT),)
        )
        await db.commit()


async def get_firma_prozent() -> float:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT value FROM settings WHERE key = 'firma_prozent'") as c:
            row = await c.fetchone()
            return float(row[0]) if row else DEFAULT_FIRMA_PROZENT


async def set_firma_prozent(prozent: float):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO settings (key, value) VALUES ('firma_prozent', ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (str(prozent),)
        )
        await db.commit()


async def get_firmenkasse() -> float:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT balance FROM firmenkasse WHERE id = 1") as c:
            row = await c.fetchone()
            return row[0] if row else 0.0


async def add_firmenkasse(amount: float):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE firmenkasse SET balance = balance + ?, updated_at = ? WHERE id = 1",
            (amount, utcnow().isoformat())
        )
        await db.commit()


async def get_employee_brutto_today(user_id):
    from utils.settlements import pending_summary
    return await pending_summary(user_id)


async def save_abrechnung(user_id, brutto, firma_prozent, firma_anteil, mitarbeiter_anteil, details):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """INSERT INTO abrechnungen
               (user_id, brutto, firma_prozent, firma_anteil, mitarbeiter_anteil, details, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (user_id, brutto, firma_prozent, firma_anteil, mitarbeiter_anteil, details,
             utcnow().isoformat())
        )
        await db.commit()
        return cur.lastrowid


from utils.menu_ui import OwnedView
from utils.perms import is_staff


class MeinPanelView(OwnedView):
    def __init__(self, user_id: int):
        super().__init__(user_id)

    async def interaction_check(self, interaction):
        if not await super().interaction_check(interaction): return False
        if not is_staff(interaction.user):
            await interaction.response.send_message("Nur Mitarbeiter.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Mein offener Verdienst", style=discord.ButtonStyle.primary, emoji="💵")
    async def verdienst(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self.interaction_check(interaction): return
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Nur dein eigenes Panel.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        brutto, details = await get_employee_brutto_today(interaction.user.id)
        prozent = await get_firma_prozent()
        firma = brutto * (prozent / 100)
        netto = brutto - firma
        embed = discord.Embed(
            title="💵 Dein offener Verdienst (noch nicht abgerechnet)",
            color=0x2ECC71,
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Brutto (alles)", value=f"**{brutto:,.0f} {CURRENCY}**", inline=True)
        embed.add_field(name=f"Firma ({prozent:.0f}%)", value=f"{firma:,.0f} {CURRENCY}", inline=True)
        embed.add_field(name="Dein Anteil", value=f"**{netto:,.0f} {CURRENCY}**", inline=True)
        if details and details != "Keine Einträge heute":
            embed.add_field(name="Details", value=details[:1000], inline=False)
        embed.set_footer(text="Mit „Schicht beenden“ wird abgerechnet")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @discord.ui.button(label="Schicht beenden / Abrechnen", style=discord.ButtonStyle.danger, emoji="🏁")
    async def feierabend(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self.interaction_check(interaction): return
        await interaction.response.defer(ephemeral=True)
        from utils.settlements import settle_employee
        result = await settle_employee(interaction.user.id)
        if not result:
            await interaction.followup.send("Keine offenen Buchungen. Bereits abgerechnete Beträge werden nicht erneut ausgezahlt.", ephemeral=True)
            return
        embed = discord.Embed(title="🏁 USHERO · Abrechnung gespeichert", color=0xEB459E)
        for name,key in (("Abrechnung-Nr.","id"),("Offenes Brutto","gross"),("Firmen-Anteil","company"),("Dein Basis-Anteil","base"),("Dienstbonus","bonus"),("Dein Auszahlungs-Anteil","employee")):
            embed.add_field(name=name,value=f"#{result[key]}" if key=="id" else f"{result[key]:,.2f} $",inline=True)
        embed.set_footer(text="Jede Buchung wird genau einmal abgerechnet. Security-Dienstlöhne werden getrennt protokolliert.")
        await interaction.followup.send(embed=embed, ephemeral=True)
        channel = discord.utils.get(interaction.guild.text_channels, name="abrechnungen") or discord.utils.get(interaction.guild.text_channels, name="buchhaltung")
        if channel:
            try:
                embed.description = interaction.user.mention
                await channel.send(embed=embed)
            except discord.HTTPException:
                pass


class Buchhaltung(commands.Cog):
    """Verdienst, Abrechnung, Firmenkasse, Buchhaltung"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def cog_load(self):
        await init_buchhaltung_tables()

    # ----- Mitarbeiter: eigenes Panel -----
    @app_commands.command(name="mein-panel", description="Dein persönliches Mitarbeiter-Panel")
    async def mein_panel(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title=f"👤 Panel – {interaction.user.display_name}",
            description=(
                "Dein persönliches Mitarbeiter-Panel.\n\n"
                "1. Im Hauptmenü den Dienst starten / beenden (+10% Bonus)\n"
                "2. Hier: Verdienst prüfen & **abrechnen**\n\n"
                "• **Mein offener Verdienst** – Vorschau\n"
                "• **Schicht beenden** – Abrechnung (Firma / du / Bonus)"
            ),
            color=0x3498DB
        )
        prozent = await get_firma_prozent()
        embed.set_footer(text=f"Firma: {prozent:.0f}% | Mitarbeiter: {100-prozent:.0f}%")
        await interaction.response.send_message(
            embed=embed, view=MeinPanelView(interaction.user.id), ephemeral=True
        )

    # ----- Buchhaltung: Firmenkasse -----
    @app_commands.command(name="firmenkasse", description="Stand der Firmenkasse (Buchhaltung)")
    async def firmenkasse(self, interaction: discord.Interaction):
        await init_buchhaltung_tables()
        balance = await get_firmenkasse()
        prozent = await get_firma_prozent()
        embed = discord.Embed(
            title="🏦 Firmenkasse",
            description=f"**{balance:,.2f} {CURRENCY}**",
            color=0x9B59B6,
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Firmen-Anteil bei Abrechnung", value=f"{prozent:.0f} %", inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ----- Prozent einstellen (10 / 20 / 25) -----
    @app_commands.command(name="firma-prozent", description="Firmen-Anteil einstellen (75 / 80 / 90 %)")
    @app_commands.describe(prozent="Anteil der FIRMA vom Brutto (Mitarbeiter bekommt den Rest)")
    @app_commands.choices(prozent=[
        app_commands.Choice(name="90 % Firma → 10 % Mitarbeiter", value=90),
        app_commands.Choice(name="80 % Firma → 20 % Mitarbeiter", value=80),
        app_commands.Choice(name="75 % Firma → 25 % Mitarbeiter", value=75),
    ])
    @app_commands.default_permissions(manage_guild=True)
    async def firma_prozent(self, interaction: discord.Interaction, prozent: app_commands.Choice[int]):
        await set_firma_prozent(float(prozent.value))
        await log_audit("firma_prozent", interaction.user.id, details=str(prozent.value))
        embed = discord.Embed(
            title="⚙️ Firmen-Anteil geändert",
            description=(
                f"Bei jeder Abrechnung gehen **{prozent.value} %** in die **Firmenkasse**.\n"
                f"Mitarbeiter bekommen **{100 - prozent.value} %**."
            ),
            color=0x2ECC71
        )
        await interaction.response.send_message(embed=embed)

    # ----- Alle Abrechnungen (Buchhaltung) -----
    @app_commands.command(name="abrechnungen", description="Alle Mitarbeiter-Abrechnungen (Buchhaltung)")
    @app_commands.default_permissions(manage_guild=True)
    async def abrechnungen(self, interaction: discord.Interaction, limit: int = 15):
        await interaction.response.defer(ephemeral=True)
        await init_buchhaltung_tables()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM abrechnungen ORDER BY created_at DESC LIMIT ?", (limit,)
            ) as c:
                rows = await c.fetchall()

        if not rows:
            await interaction.followup.send("Noch keine Abrechnungen.")
            return

        embed = discord.Embed(title="📋 Abrechnungen – Übersicht", color=0xE67E22)
        for r in rows[:25]:
            member = interaction.guild.get_member(r["user_id"])
            name = member.display_name if member else str(r["user_id"])
            embed.add_field(
                name=f"#{r['id']} – {name}",
                value=(
                    f"Brutto: {r['brutto']:,.0f} $ | "
                    f"Firma ({r['firma_prozent']:.0f}%): {r['firma_anteil']:,.0f} $ | "
                    f"MA: {r['mitarbeiter_anteil']:,.0f} $\n"
                    f"`{r['created_at'][:16]}`"
                ),
                inline=False
            )
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="meine-abrechnungen", description="Deine letzten Abrechnungen")
    async def meine_abrechnungen(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM abrechnungen WHERE user_id = ? ORDER BY created_at DESC LIMIT 10",
                (interaction.user.id,)
            ) as c:
                rows = await c.fetchall()
        if not rows:
            await interaction.followup.send("Du hast noch keine Abrechnungen.")
            return
        embed = discord.Embed(title="🧾 Deine Abrechnungen", color=0x3498DB)
        for r in rows[:25]:
            embed.add_field(
                name=f"#{r['id']} – {r['created_at'][:10]}",
                value=f"Brutto {r['brutto']:,.0f} $ → Du: **{r['mitarbeiter_anteil']:,.0f} $**",
                inline=False
            )
        await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Buchhaltung(bot))
