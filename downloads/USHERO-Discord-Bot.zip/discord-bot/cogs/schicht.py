"""Eine Schichtlogik fuer Buttons, Abrechnung und Auto-Logout."""
from utils.logging_ch import send_audit
from utils.menu_ui import reply
from datetime import datetime, timezone
import discord
from discord import app_commands
from discord.ext import commands
import aiosqlite
from utils.database import DB_PATH
from utils.design import stempel_ein, stempel_aus
from utils.perms import is_staff

SCHICHT_BONUS_PROZENT = 10


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def parse_time(value):
    value = datetime.fromisoformat(value)
    return value.astimezone(timezone.utc).replace(tzinfo=None) if value.tzinfo else value


async def is_on_duty(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        row = await (await db.execute("SELECT id FROM schichten WHERE user_id=? AND status='aktiv'", (user_id,))).fetchone()
        return bool(row)


async def start_schicht(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('BEGIN IMMEDIATE')
        if await (await db.execute("SELECT id FROM schichten WHERE user_id=? AND status='aktiv'", (user_id,))).fetchone():
            return False
        now = utcnow().isoformat()
        await db.execute("INSERT INTO schichten(user_id,started_at,startzeit,status) VALUES(?,?,?,'aktiv')", (user_id, now, now))
        await db.commit()
        return True


async def end_schicht(user_id, *, automatic=False, expected_id=None):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('BEGIN IMMEDIATE')
        row = await (await db.execute("SELECT id,started_at FROM schichten WHERE user_id=? AND status='aktiv' ORDER BY id DESC LIMIT 1", (user_id,))).fetchone()
        if not row or (expected_id is not None and row[0] != expected_id):
            return None
        now = utcnow()
        minutes = max(0, int((now-parse_time(row[1])).total_seconds()//60)) if row[1] else 0
        await db.execute('UPDATE schichten SET ended_at=?,endzeit=?,status=?,dauer=? WHERE id=?',
                         (now.isoformat(),now.isoformat(),'auto_logout' if automatic else 'beendet',minutes,row[0]))
        await db.commit()
        return minutes


async def has_completed_schicht_today(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        row = await (await db.execute("SELECT id FROM schichten WHERE user_id=? AND status='beendet' AND ended_at LIKE ? LIMIT 1", (user_id, utcnow().date().isoformat()+'%'))).fetchone()
        return bool(row)


async def duty_action(interaction, start):
    if not interaction.guild or not is_staff(interaction.user):
        await reply(interaction, '❌ Nur Mitarbeiter auf dem Server.', ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    if start:
        if not await start_schicht(interaction.user.id):
            await reply(interaction, 'Du bist bereits im Dienst.', ephemeral=True)
            return
        embed = stempel_ein(interaction.user)
    else:
        minutes = await end_schicht(interaction.user.id)
        if minutes is None:
            await reply(interaction, 'Du hast keine aktive Schicht.', ephemeral=True)
            return
        embed = stempel_aus(interaction.user, f'{minutes//60}h {minutes%60}min')
    await reply(interaction, embed=embed, ephemeral=True)
    channel = discord.utils.get(interaction.guild.text_channels, name='stempel-logs')
    if channel:
        try:
            await send_audit(interaction.guild, embed=embed, preferred=('stempel-logs', 'audit-logs'))
        except discord.HTTPException:
            pass


class Schicht(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name='dienst', description='Dienst starten oder beenden')
    async def dienst(self, interaction: discord.Interaction):
        await duty_action(interaction, not await is_on_duty(interaction.user.id))


async def setup(bot):
    await bot.add_cog(Schicht(bot))
