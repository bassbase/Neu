import discord
from discord.ext import commands
from discord import app_commands
from utils.menu_ui import HomeView, home_embed, reply
from utils.perms import is_leitung

MainMenuView=HomeView


class Panel(commands.Cog):
    def __init__(self,bot):
        self.bot=bot

    @app_commands.command(name='panel',description='Dauerhaftes Hauptmenü in diesen Kanal posten (Leitung)')
    async def panel(self,interaction: discord.Interaction):
        if not is_leitung(interaction.user):
            return await reply(interaction,'❌ Nur die Leitung darf öffentliche Menüs posten.')
        await interaction.response.defer(ephemeral=True)
        await interaction.channel.send(embed=home_embed(),view=HomeView())
        await reply(interaction,'✅ Hauptmenü gepostet. Ab jetzt reichen die Buttons; sie funktionieren auch nach einem Bot-Neustart.')

    @app_commands.command(name='unternehmen',description='Informationen zum USHERO-Menü')
    async def unternehmen(self,interaction: discord.Interaction):
        from utils.menu_ui import open_home
        await open_home(interaction)


async def setup(bot):
    await bot.add_cog(Panel(bot))
