import discord
from discord.ext import commands
from discord import app_commands
from utils.menu_ui import HomeView, home_embed, reply
from utils.perms import is_leitung

MainMenuView=HomeView


class Panel(commands.Cog):
    def __init__(self,bot):
        self.bot=bot

    @app_commands.command(name='panel',description='Alle Bereichsmenüs automatisch in passenden Kanälen einrichten (Leitung)')
    async def panel(self,interaction: discord.Interaction):
        await self.bot.get_cog("ChannelPanels").install(interaction)

    @app_commands.command(name='unternehmen',description='Informationen zum USHERO-Menü')
    async def unternehmen(self,interaction: discord.Interaction):
        from utils.menu_ui import open_home
        await open_home(interaction)


async def setup(bot):
    await bot.add_cog(Panel(bot))
