import discord
from discord import app_commands
from discord.ext import commands
from utils.menu_ui import open_home, reply
from utils.perms import AREA_ROLES


class Arbeit(commands.Cog):
    def __init__(self,bot): self.bot=bot

    @app_commands.command(name='arbeit',description='Persönliches USHERO-Arbeitsmenü öffnen')
    async def arbeit(self,interaction: discord.Interaction):
        await open_home(interaction)

    @app_commands.command(name='wer-darf-was',description='Rollen und Arbeitsbereiche anzeigen')
    async def rechte(self,interaction: discord.Interaction):
        embed=discord.Embed(title='✦ USHERO · Rollen & Bereiche',color=0x9B59B6)
        for area,roles in AREA_ROLES.items():
            embed.add_field(name=area.title(),value=', '.join(sorted(roles)) if roles else 'Nur Server-Inhaber',inline=False)
        embed.set_footer(text='Gäste: Info & Bewerbung. VIP-Kunde ist keine Mitarbeiter-Rolle.')
        await reply(interaction,embed=embed)


async def setup(bot): await bot.add_cog(Arbeit(bot))
