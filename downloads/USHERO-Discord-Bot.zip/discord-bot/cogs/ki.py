"""KI: lokal immer nutzbar. OpenAI nur als Bonus wenn Guthaben da ist."""
from utils.menu_ui import reply
from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, date
import aiosqlite
from collections import Counter

from utils.database import DB_PATH
from utils.openai_client import has_openai, chat_completion, moderate_text, generate_image

CURRENCY = "$"
USHERO = (
    "Du bist KI-Assistent des Nightclubs USHERO. Deutsch, knapp, professionell. "
    "Nur Vorschläge – Entscheidungen treffen Menschen."
)


def owner_only():
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.user.id != interaction.guild.owner_id:
            await reply(interaction, 
                "🔒 Nur der **Server-Inhaber**.", ephemeral=True
            )
            return False
        return True
    return app_commands.check(predicate)


class KI(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    ki = app_commands.Group(name="ki", description="Auswertung & Vorschläge (Inhaber)")

    @ki.command(name="status", description="KI-Status")
    @owner_only()
    async def status(self, interaction: discord.Interaction):
        embed = discord.Embed(title="🧠 KI-Status", color=0x8B5CF6)
        embed.add_field(
            name="Lokale Berichte & Regelvorlagen",
            value="✅ Tagesauswertung, Bestellung, Dienstplan, Anomalie, Marketing-Texte – **ohne** OpenAI-Guthaben",
            inline=False
        )
        if has_openai():
            embed.add_field(
                name="OpenAI-Key",
                value="Explizit aktiviert. Aufrufe können gemäß Anbietertarif kostenpflichtig sein; ein Fehlschlag ist keine Kostengarantie.",
                inline=False
            )
        else:
            embed.add_field(name="OpenAI-Key", value="Externe API deaktiviert – lokale Regelvorlagen und Berichte. Keine generative lokale KI enthalten.", inline=False)
        embed.set_footer(text="Externe KI nur mit ENABLE_OPENAI=true; Anbietertarife gelten.")
        await reply(interaction, embed=embed, ephemeral=True)

    @ki.command(name="tagesauswertung", description="Tagesbericht (lokal)")
    @owner_only()
    async def tagesauswertung(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        today = date.today().isoformat()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            try:
                async with db.execute(
                    "SELECT item, amount, quantity, category FROM sales WHERE created_at LIKE ?",
                    (f"{today}%",)
                ) as c:
                    sales = list(await c.fetchall())
            except Exception:
                sales = []
            try:
                async with db.execute(
                    "SELECT amount FROM vip_entries WHERE created_at LIKE ?", (f"{today}%",)
                ) as c:
                    vips = list(await c.fetchall())
            except Exception:
                vips = []

        umsatz = sum(r["amount"] * r["quantity"] for r in sales) + sum(r["amount"] for r in vips)
        by_item = Counter()
        by_cat = Counter()
        for r in sales:
            line = r["amount"] * r["quantity"]
            by_item[r["item"]] += line
            by_cat[r["category"] or "sonst"] += line
        best = by_item.most_common(5)
        local = (
            f"**Datum:** {today}\n**Umsatz:** {umsatz:,.0f} {CURRENCY}\n\n"
            f"**Bestseller:**\n" + ("\n".join(f"• {n}: {v:,.0f} $" for n, v in best) or "• keine Verkäufe") +
            f"\n\n**Bereiche:**\n" + ("\n".join(f"• {k}: {v:,.0f} $" for k, v in by_cat.most_common()) or "—")
        )
        ai = await chat_completion(USHERO, f"Verbessere kurz diesen Club-Tagesbericht:\n{local}")
        embed = discord.Embed(
            title="📊 Tagesauswertung",
            description=(ai if ai and not str(ai).startswith("⚠️") else local)[:4000],
            color=0x8B5CF6,
            timestamp=discord.utils.utcnow()
        )
        embed.set_footer(text="Lokal berechnet" + (" · OpenAI ergänzt" if ai else " · ohne OpenAI-Credits"))
        await reply(interaction, embed=embed, ephemeral=True)

    @ki.command(name="bestellung", description="Lager-Empfehlung (lokal)")
    @owner_only()
    async def bestellung(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            try:
                async with db.execute("SELECT item, quantity FROM warehouse_stock") as c:
                    stock = {r["item"]: r["quantity"] for r in await c.fetchall()}
            except Exception:
                stock = {}
        if not stock:
            text = "Noch kein Lagerbestand. Zuerst das Warehouse-Menü nutzen und Bestand aufbauen."
        else:
            tips = []
            for item, qty in stock.items():
                if qty <= 0:
                    tips.append(f"🔴 **{item}** leer → ca. 40 Stück bestellen")
                elif qty < 10:
                    tips.append(f"🟡 **{item}** ({qty}) → nachbestellen ca. {25 - qty}")
                else:
                    tips.append(f"🟢 **{item}** ({qty}) OK")
            text = "\n".join(tips)
        embed = discord.Embed(title="📦 Bestell-Empfehlung", description=text[:4000], color=0xF59E0B)
        embed.set_footer(text="Lokal aus Lagerdaten")
        await reply(interaction, embed=embed, ephemeral=True)

    @ki.command(name="dienstplan", description="Hinweis zu heutigen Schichten")
    @owner_only()
    async def dienstplan_ki(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await reply(interaction, 
            "Für den **echten Dienstplan** nutze:\n"
            "Dienstplan → Datum auswählen · Dienstplan → Schicht eintragen · Dienstplan → Heute\n"
            "(funktioniert ohne OpenAI)",
            ephemeral=True
        )

    @ki.command(name="anomalie", description="Auffällige Buchungen")
    @owner_only()
    async def anomalie(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        today = date.today().isoformat()
        flags = []
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            try:
                async with db.execute(
                    "SELECT seller_id, item, amount, quantity FROM sales WHERE created_at LIKE ?",
                    (f"{today}%",)
                ) as c:
                    sales = list(await c.fetchall())
            except Exception:
                sales = []
        seen = set()
        for r in sales:
            key = (r["seller_id"], r["item"], r["amount"], r["quantity"])
            if key in seen:
                flags.append(f"⚠️ Mögliche Doppelbuchung: {r['item']}")
            seen.add(key)
            if r["amount"] * r["quantity"] >= 50000:
                flags.append(f"💰 Hoch: {r['amount']*r['quantity']:,.0f} $ – {r['item']}")
        embed = discord.Embed(
            title="🔍 Anomalie-Wächter",
            description="\n".join(flags[:20]) if flags else "✅ Keine groben Auffälligkeiten heute.",
            color=0xEF4444
        )
        await reply(interaction, embed=embed, ephemeral=True)

    @ki.command(name="marketing", description="Event-Text (lokal oder OpenAI)")
    @owner_only()
    async def marketing(self, interaction: discord.Interaction, thema: str):
        await interaction.response.defer(ephemeral=True)
        local = (
            f"**USHERO – {thema}**\n\n"
            f"Tonight. Marble. Gold. Violet.\n"
            f"{thema} – exclusive, only at USHERO.\n\n"
            f"Doors from opening. VIP limited.\nDresscode: elegant / dark exclusive.\n\n— USHERO"
        )
        ai = await chat_completion(USHERO, f"Social-Post für USHERO zum Thema: {thema}")
        text = ai if ai else local
        embed = discord.Embed(title="✍️ Marketing", description=text[:4000], color=0xFF2E93)
        embed.set_footer(text="OpenAI" if ai else "Lokaler Ushero-Text (kein API-Guthaben nötig)")
        await reply(interaction, embed=embed, ephemeral=True)

    @ki.command(name="concierge", description="Gäste-Antwort")
    @owner_only()
    async def concierge(self, interaction: discord.Interaction, frage: str):
        await interaction.response.defer(ephemeral=True)
        q = frage.lower()
        if any(x in q for x in ("preis", "kosten", "eintritt")):
            local = "Eintritt Normal 15.000 $, Afterdark 25.000 $. Getränke ab 1.200 $, Speisen ab 1.300 $, Boxen 15–18.000 $."
        elif "dress" in q or "kleidung" in q:
            local = "Dresscode: elegant / dark exclusive. Keine Sportkleidung."
        elif "vip" in q:
            local = "VIP-Lounge auf Anfrage an Bar/Leitung. Plätze begrenzt. Karten: 1–3 Monate."
        else:
            local = f"Zur Frage „{frage}“: Bitte Theke oder Leitung. Details in #ankündigungen."
        ai = await chat_completion(USHERO + " Concierge für Gäste.", frage)
        embed = discord.Embed(title="🛎️ Concierge", description=(ai or local)[:4000], color=0x22D3EE)
        await reply(interaction, embed=embed, ephemeral=True)

    @ki.command(name="moderation", description="Text prüfen")
    @owner_only()
    async def moderation(self, interaction: discord.Interaction, text: str):
        await interaction.response.defer(ephemeral=True)
        mod = await moderate_text(text)
        # lokale Heuristik
        low = text.lower()
        local_flags = []
        for w in ("http://", "https://", "discord.gg", "@everyone", "@here"):
            if w in low:
                local_flags.append(f"Link/Ping: `{w}`")
        if len(text) > 500:
            local_flags.append("Sehr langer Text")
        desc = []
        if mod:
            desc.append(f"OpenAI flagged: **{mod.get('flagged')}**")
            if mod.get("categories"):
                desc.append(f"Kategorien: {mod['categories']}")
        else:
            desc.append("OpenAI-Moderation nicht verfügbar (Credits/Key) – lokale Prüfung:")
        desc.append("\n".join(local_flags) if local_flags else "✅ Lokal keine groben Muster.")
        desc.append("\n**Hausverbot/Bann immer manuell.**")
        embed = discord.Embed(title="🛡️ Moderation", description="\n".join(desc), color=0x8B5CF6)
        await reply(interaction, embed=embed, ephemeral=True)

    @ki.command(name="visual", description="Bild-Idee / Visual (API optional)")
    @owner_only()
    async def visual(self, interaction: discord.Interaction, motiv: str):
        await interaction.response.defer(ephemeral=True)
        url = await generate_image(
            f"Luxury nightclub USHERO poster, marble gold violet, elegant dark: {motiv}"
        )
        if url:
            embed = discord.Embed(title="🎨 KI-Visual", description=motiv, color=0xFACC15)
            embed.set_image(url=url)
            await reply(interaction, embed=embed, ephemeral=True)
            return
        # Lokaler Design-Brief statt Fehler
        embed = discord.Embed(
            title="🎨 Visual-Brief (ohne Bild-API)",
            description=(
                f"**Motiv:** {motiv}\n\n"
                f"**Stil:** Marmor, Gold, Violett, After Dark\n"
                f"**Format:** Story 9:16 · Post 1:1 · Flyer A5\n"
                f"**Text-Idee:** USHERO · {motiv} · WHERE LEGENDS MEET\n\n"
                f"_Kein Bild-Modell/Credits auf dem OpenAI-Account – "
                f"Brief zum Weitergeben an Grafik oder Canva._"
            ),
            color=0xFACC15
        )
        await reply(interaction, embed=embed, ephemeral=True)

    @ki.command(name="panel", description="KI-Übersicht posten")
    @owner_only()
    async def ki_panel(self, interaction: discord.Interaction):
        from utils.menu_ui import open_category
        await open_category(interaction, "ki")


async def setup(bot):
    await bot.add_cog(KI(bot))
