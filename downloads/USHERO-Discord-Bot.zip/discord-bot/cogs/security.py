"""Fehlendes Security-Quellmodul, mit doppelbuchungssicherem Dienst."""
from utils.clock import utcnow
from datetime import datetime
import discord
from discord import app_commands
from discord.ext import commands
import aiosqlite
from utils.database import DB_PATH, get_security_sum
from utils.menu_ui import reply
from utils.config import CONFIG


class Security(commands.Cog):
    security=app_commands.Group(name='security',description='Security-Dienst und Lohn')
    def __init__(self,bot): self.bot=bot

    @security.command(name='dienst-start',description='Eigenen Security-Dienst starten')
    async def start(self,interaction: discord.Interaction,notiz: str=''):
        await interaction.response.defer(ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute('BEGIN IMMEDIATE')
            if await (await db.execute("SELECT id FROM security_duty WHERE user_id=? AND status='active'",(interaction.user.id,))).fetchone():
                return await reply(interaction,'Du hast bereits einen aktiven Security-Dienst.')
            await db.execute("INSERT INTO security_duty(user_id,started_at,note,status) VALUES(?,?,?,'active')",(interaction.user.id,utcnow().isoformat(),notiz))
            await db.commit()
        await reply(interaction,'🛡️ Security-Dienst gestartet.')

    @security.command(name='dienst-ende',description='Eigenen Security-Dienst beenden; Lohn automatisch berechnen')
    async def end(self,interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        hourly=float(CONFIG.get('security_hourly_rate',0))
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute('BEGIN IMMEDIATE')
            row=await (await db.execute("SELECT id,started_at FROM security_duty WHERE user_id=? AND status='active' ORDER BY id DESC LIMIT 1",(interaction.user.id,))).fetchone()
            if not row: return await reply(interaction,'Kein aktiver Security-Dienst.')
            now=utcnow(); hours=max(0,(now-datetime.fromisoformat(row[1])).total_seconds()/3600)
            pay=round(hours*hourly,2)
            await db.execute("UPDATE security_duty SET status='finished',ended_at=?,pay=? WHERE id=?",(now.isoformat(),pay,row[0]))
            await db.commit()
        suffix=' Noch kein Stundenlohn konfiguriert; security_hourly_rate in config.json festlegen.' if hourly==0 else ''
        await reply(interaction,f'🏁 Security-Dienst beendet: {hours:.2f} Stunden, {pay:,.2f} $ Lohn protokolliert.'+suffix)

    @security.command(name='aktiv',description='Aktive Security-Dienste anzeigen')
    async def active(self,interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            rows=await (await db.execute("SELECT user_id,started_at FROM security_duty WHERE status='active' ORDER BY id DESC LIMIT 20")).fetchall()
        text='\n'.join(f'<@{uid}> · seit {start[:16]} UTC' for uid,start in rows) or 'Niemand im Dienst.'
        await reply(interaction,embed=discord.Embed(title='🛡️ Security im Dienst',description=text,color=0x3498DB))

    @security.command(name='summe',description='Eigene abgeschlossene Security-Löhne anzeigen')
    async def summe(self,interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        total=await get_security_sum(interaction.user.id)
        await reply(interaction,f'🛡️ Deine protokollierten Security-Löhne: **{total:,.2f} $**. Diese Dienstlöhne sind getrennt von der Umsatz-Provisionsabrechnung.')


async def setup(bot): await bot.add_cog(Security(bot))
