from utils.clock import utcnow
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
import json
import os
import aiosqlite

from utils.database import DB_PATH, log_audit
from utils.perms import is_leitung

from utils.config import CONFIG

from utils.config import MENU

# Warehouse-Artikel mit Einkaufspreis
WAREHOUSE_ITEMS = MENU.get("warehouse", {
    "Trinken (Warehouse)": 250,
    "Essen (Warehouse)": 250
})


async def init_warehouse_tables():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS warehouse_stock (
                item TEXT PRIMARY KEY,
                quantity INTEGER DEFAULT 0,
                last_updated TEXT
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS warehouse_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item TEXT,
                quantity INTEGER,
                unit_price REAL,
                total_price REAL,
                ordered_by INTEGER,
                status TEXT DEFAULT 'offen',
                note TEXT,
                created_at TEXT,
                received_at TEXT
            )
        """)
        # Standard-Artikel anlegen falls nicht vorhanden
        for item in WAREHOUSE_ITEMS:
            await db.execute(
                "INSERT OR IGNORE INTO warehouse_stock (item, quantity, last_updated) VALUES (?, 0, ?)",
                (item, utcnow().isoformat())
            )
        await db.commit()


class Warehouse(commands.Cog):
    """Warehouse = Bestellungen & Lagerbestand"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    warehouse = app_commands.Group(name="warehouse", description="Warehouse Bestellungen & Lager")

    async def cog_load(self):
        await init_warehouse_tables()

    # ---------- Bestellung aufgeben ----------
    @warehouse.command(name="bestellen", description="Neue Bestellung fürs Warehouse aufgeben")
    @app_commands.describe(
        artikel="Was soll bestellt werden",
        menge="Wie viele Stück",
        notiz="Optional: Notiz (z.B. dringend)"
    )
    @app_commands.choices(artikel=[
        app_commands.Choice(name="Trinken (Warehouse) – 250$", value="Trinken (Warehouse)"),
        app_commands.Choice(name="Essen (Warehouse) – 250$", value="Essen (Warehouse)"),
    ])
    async def warehouse_bestellen(
        self,
        interaction: discord.Interaction,
        artikel: app_commands.Choice[str],
        menge: int,
        notiz: str = ""
    ):
        await interaction.response.defer()
        if menge < 1:
            await interaction.followup.send("❌ Menge muss mindestens 1 sein.", ephemeral=True)
            return

        name = artikel.value
        unit_price = WAREHOUSE_ITEMS.get(name, 250)
        total = unit_price * menge

        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute(
                """INSERT INTO warehouse_orders 
                   (item, quantity, unit_price, total_price, ordered_by, status, note, created_at)
                   VALUES (?, ?, ?, ?, ?, 'offen', ?, ?)""",
                (name, menge, unit_price, total, interaction.user.id, notiz, utcnow().isoformat())
            )
            await db.commit()
            order_id = cursor.lastrowid

        await log_audit("warehouse_order", interaction.user.id, details=f"{name} x{menge} = {total}")

        embed = discord.Embed(
            title="📦 Bestellung aufgegeben",
            color=0x8E44AD,
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Bestell-Nr.", value=f"#{order_id}", inline=True)
        embed.add_field(name="Artikel", value=name, inline=True)
        embed.add_field(name="Menge", value=str(menge), inline=True)
        embed.add_field(name="Einzelpreis", value=f"{unit_price:,} {CONFIG['currency']}", inline=True)
        embed.add_field(name="Gesamt", value=f"**{total:,} {CONFIG['currency']}**", inline=True)
        embed.add_field(name="Bestellt von", value=interaction.user.mention, inline=True)
        embed.add_field(name="Status", value="🟡 Offen", inline=True)
        if notiz:
            embed.add_field(name="Notiz", value=notiz, inline=False)
        embed.set_footer(text="Wenn die Lieferung kommt: im Warehouse-Menü „Eingang“ wählen.")

        await interaction.followup.send(embed=embed)

    # ---------- Lieferung eingegangen (Lager erhöhen) ----------
    @warehouse.command(name="eingang", description="Lieferung als eingegangen markieren + Lager erhöhen")
    @app_commands.describe(bestell_nr="Die Bestell-Nummer (z.B. 3)")
    async def warehouse_eingang(self, interaction: discord.Interaction, bestell_nr: int):
        await interaction.response.defer(ephemeral=True)

        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT * FROM warehouse_orders WHERE id = ?", (bestell_nr,)
            ) as c:
                order = await c.fetchone()

            if not order:
                await interaction.followup.send(f"❌ Bestellung #{bestell_nr} nicht gefunden.")
                return
            if order["status"] == "erledigt":
                await interaction.followup.send(f"❌ Bestellung #{bestell_nr} wurde schon als erledigt markiert.")
                return

            # Status auf erledigt
            await db.execute(
                "UPDATE warehouse_orders SET status = 'erledigt', received_at = ? WHERE id = ?",
                (utcnow().isoformat(), bestell_nr)
            )
            # Lager erhöhen
            await db.execute(
                """INSERT INTO warehouse_stock (item, quantity, last_updated) VALUES (?, ?, ?)
                   ON CONFLICT(item) DO UPDATE SET 
                   quantity = quantity + excluded.quantity,
                   last_updated = excluded.last_updated""",
                (order["item"], order["quantity"], utcnow().isoformat())
            )
            await db.commit()

            # Neuer Bestand holen
            async with db.execute(
                "SELECT quantity FROM warehouse_stock WHERE item = ?", (order["item"],)
            ) as c:
                row = await c.fetchone()
                new_stock = row["quantity"] if row else order["quantity"]

        await log_audit("warehouse_received", interaction.user.id, details=f"Bestellung #{bestell_nr}")

        embed = discord.Embed(
            title="✅ Lieferung eingegangen",
            color=0x2ECC71,
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Bestell-Nr.", value=f"#{bestell_nr}", inline=True)
        embed.add_field(name="Artikel", value=order["item"], inline=True)
        embed.add_field(name="Menge", value=f"+{order['quantity']}", inline=True)
        embed.add_field(name="Neuer Lagerbestand", value=f"**{new_stock}** Stück", inline=True)
        embed.add_field(name="Eingetragen von", value=interaction.user.mention, inline=True)

        await interaction.followup.send(embed=embed)
        try:
            await interaction.channel.send(
                f"📦 **Warehouse Eingang:** {order['item']} +{order['quantity']} "
                f"(Bestellung #{bestell_nr}) → Lager jetzt **{new_stock}**"
            )
        except Exception:
            pass

    # ---------- Aktueller Lagerbestand ----------
    @warehouse.command(name="lager", description="Aktuellen Lagerbestand anzeigen")
    async def warehouse_lager(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await init_warehouse_tables()

        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM warehouse_stock ORDER BY item") as c:
                rows = await c.fetchall()

        embed = discord.Embed(
            title="🏭 Warehouse – Lagerbestand",
            color=0x8E44AD,
            timestamp=discord.utils.utcnow()
        )
        if not rows:
            embed.description = "Noch kein Bestand vorhanden."
        else:
            for r in rows[:25]:
                qty = r["quantity"]
                status = "🟢" if qty > 10 else ("🟡" if qty > 0 else "🔴")
                embed.add_field(
                    name=f"{status} {r['item']}",
                    value=f"**{qty}** Stück",
                    inline=True
                )
        await interaction.followup.send(embed=embed)

    # ---------- Offene Bestellungen ----------
    @warehouse.command(name="offen", description="Alle offenen Bestellungen anzeigen")
    async def warehouse_offen(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM warehouse_orders WHERE status = 'offen' ORDER BY created_at DESC"
            ) as c:
                rows = await c.fetchall()

        if not rows:
            await interaction.followup.send("✅ Keine offenen Bestellungen.")
            return

        embed = discord.Embed(
            title="📦 Offene Warehouse-Bestellungen",
            color=0xE67E22,
            timestamp=discord.utils.utcnow()
        )
        for r in rows[:25]:
            user = interaction.guild.get_member(r["ordered_by"])
            name = user.display_name if user else str(r["ordered_by"])
            embed.add_field(
                name=f"#{r['id']} – {r['item']}",
                value=(
                    f"Menge: **{r['quantity']}** | {r['total_price']:,.0f} {CONFIG['currency']}\n"
                    f"Von: {name} | {r['created_at'][:16]}\n"
                    f"{'Notiz: ' + r['note'] if r['note'] else ''}"
                ),
                inline=False
            )
        embed.set_footer(text="Im Warehouse-Menü „Eingang“ auswählen.")
        await interaction.followup.send(embed=embed)

    # ---------- Bestell-Historie ----------
    @warehouse.command(name="historie", description="Letzte Bestellungen (auch erledigte)")
    async def warehouse_historie(self, interaction: discord.Interaction, limit: int = 10):
        await interaction.response.defer(ephemeral=True)

        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM warehouse_orders ORDER BY created_at DESC LIMIT ?", (limit,)
            ) as c:
                rows = await c.fetchall()

        if not rows:
            await interaction.followup.send("Noch keine Bestellungen vorhanden.")
            return

        embed = discord.Embed(title="📜 Warehouse Bestell-Historie", color=0x8E44AD)
        for r in rows[:25]:
            status = "✅ Erledigt" if r["status"] == "erledigt" else "🟡 Offen"
            embed.add_field(
                name=f"#{r['id']} {r['item']} × {r['quantity']}",
                value=f"{r['total_price']:,.0f} {CONFIG['currency']} | {status}",
                inline=False
            )
        await interaction.followup.send(embed=embed)

    # ---------- Lager manuell anpassen (Korrektur) ----------
    @warehouse.command(name="korrigieren", description="Lagerbestand manuell setzen (Korrektur)")
    @app_commands.describe(artikel="Artikel", neuer_bestand="Neuer Bestand (Stück)")
    @app_commands.choices(artikel=[
        app_commands.Choice(name="Trinken (Warehouse)", value="Trinken (Warehouse)"),
        app_commands.Choice(name="Essen (Warehouse)", value="Essen (Warehouse)"),
    ])
    async def warehouse_korrigieren(
        self,
        interaction: discord.Interaction,
        artikel: app_commands.Choice[str],
        neuer_bestand: int
    ):
        if not interaction.user.guild_permissions.manage_guild and not is_leitung(interaction.user):
            await interaction.response.send_message("❌ Nur Leitung/Admin.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)

        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                """INSERT INTO warehouse_stock (item, quantity, last_updated) VALUES (?, ?, ?)
                   ON CONFLICT(item) DO UPDATE SET quantity = ?, last_updated = ?""",
                (artikel.value, neuer_bestand, utcnow().isoformat(),
                 neuer_bestand, utcnow().isoformat())
            )
            await db.commit()

        await log_audit("warehouse_correct", interaction.user.id, details=f"{artikel.value} = {neuer_bestand}")
        await interaction.followup.send(
            f"✅ Lager von **{artikel.value}** auf **{neuer_bestand}** Stück gesetzt."
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(Warehouse(bot))
