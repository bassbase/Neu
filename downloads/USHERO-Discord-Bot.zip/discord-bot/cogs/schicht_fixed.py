"""Kompatibilitaet: Schicht wird ausschliesslich aus cogs.schicht geladen."""
from cogs.schicht import Schicht
