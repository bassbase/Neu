import discord
from discord import app_commands
from discord.ext import commands
from utils.menu_ui import open_home


class StartHilfe(commands.Cog):
    @app_commands.command(name='hilfe',description='Hauptmenü und Hilfe öffnen')
    async def hilfe(self,interaction: discord.Interaction):
        await open_home(interaction)


async def setup(bot): await bot.add_cog(StartHilfe())
