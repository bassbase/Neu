// USHERO Sheets Backend – Google Apps Script
// Optional: Script Property USHERO_SHARED_KEY setzen; derselbe Wert lokal in SHEETS_SHARED_KEY.
// Keine Daten ohne diesen Schluessel. Erst danach als eigene Web-App bereitstellen.

function doPost(e) {
  const data = JSON.parse(e.postData.contents);
  if (!authorized(data.shared_key)) return denied();
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const type = data.type || "";

  if (type === "verkauf") {
    const sheet = getOrCreateSheet(ss, "Verkäufe");
    sheet.appendRow([
      data.zeit || new Date(),
      data.mitarbeiter || "",
      data.artikel || "",
      data.gesamt || 0
    ]);
    return ContentService.createTextOutput(JSON.stringify({ok: true})).setMimeType(ContentService.MimeType.JSON);
  }

  if (type === "dienstzeit_start" || type === "dienstzeit_ende") {
    const sheet = getOrCreateSheet(ss, "Dienstzeiten");
    sheet.appendRow([
      data.datum || "",
      data.mitarbeiter || "",
      data.eingestempelt || data.ausgestempelt || "",
      data.status || ""
    ]);
    return ContentService.createTextOutput(JSON.stringify({ok: true})).setMimeType(ContentService.MimeType.JSON);
  }

  return ContentService.createTextOutput(JSON.stringify({ok: false, error: "unknown type"})).setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  const params = e.parameter;
  if (!authorized(params.shared_key)) return denied();
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const type = params.type || "";

  if (type === "verkaeufe") {
    const sheet = ss.getSheetByName("Verkäufe");
    if (!sheet) return ContentService.createTextOutput(JSON.stringify({ok: true, eintraege: []})).setMimeType(ContentService.MimeType.JSON);
    const rows = sheet.getDataRange().getValues().slice(1);
    const eintraege = rows.map(r => ({zeit: r[0], mitarbeiter: r[1], artikel: r[2], gesamt: r[3]}));
    return ContentService.createTextOutput(JSON.stringify({ok: true, eintraege})).setMimeType(ContentService.MimeType.JSON);
  }

  return ContentService.createTextOutput(JSON.stringify({ok: true, info: "USHERO Sheets"})).setMimeType(ContentService.MimeType.JSON);
}

function getOrCreateSheet(ss, name) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (name === "Verkäufe") sheet.appendRow(["Zeit", "Mitarbeiter", "Artikel", "Gesamt"]);
    if (name === "Dienstzeiten") sheet.appendRow(["Datum", "Mitarbeiter", "Zeit", "Status"]);
  }
  return sheet;
}

function authorized(key) {
  const expected = PropertiesService.getScriptProperties().getProperty("USHERO_SHARED_KEY");
  return !!expected && key === expected;
}
function denied() {
  return ContentService.createTextOutput(JSON.stringify({ok:false,error:"unauthorized"})).setMimeType(ContentService.MimeType.JSON);
}
