# ✦ USHERO · Nightclub – reparierte Menü-Version

Dein vorhandener Bot mit Neon-Farben, Artikeln und Bereichen als Grundlage. Die
Aktionen laufen über Buttons, Auswahllisten und Formulare. Die alten Slash-Befehle
bleiben als alternative Bedienung erhalten.

## Start auf deinem Windows-PC

1. Den bisherigen Bot mit **Strg+C** beenden. Den alten Ordner als Sicherung behalten.
2. Diese ZIP **in einen neuen Ordner entpacken**.
3. Deine bisherige **`.env`** neben `bot.py` in den neuen Ordner kopieren. Die ZIP
   enthält absichtlich keine Zugangsdaten. Ohne vorhandene `.env` fragt der Starter
   den Bot-Token verdeckt ab und speichert ihn nur lokal.
4. **`start.bat`** öffnen. Python 3.12 wird empfohlen; unterstützt sind 3.11–3.14.
   Python 3.15 wurde nicht geprüft und wird vom Starter abgelehnt. Beim ersten Mal
   die Paketinstallation mit `j` bestätigen. Das Bot-Fenster offen lassen.
5. In Discord als Leitung einmal **`/panel`** im gewünschten Kanal aufrufen.
   Danach direkt die **Menübuttons** verwenden. Für einzelne Kanäle steht im
   Leitungsmenü „Bereichsmenü posten“ bereit. Bereits gepostete alte Hauptbuttons
   öffnen ebenfalls die neuen Bereiche.

**Diese Download-Version enthält keine Zugangsdaten und keine private Datenbank.**
Kopiere vor dem ersten Start die bisherige `.env` und die aktuellste
`data/bot.db` aus deinem gestoppten alten Bot in den neuen Ordner. Lege die
Datenbank dabei wieder in `data/bot.db` ab. So bleiben deine Buchungen erhalten.
Ohne übernommene Datenbank beginnt der Bot mit leeren Tabellen. Den alten Ordner
unverändert als Sicherung behalten. Nie zwei Bots gleichzeitig mit derselben
Datenbank betreiben.

## Discord-Einstellungen

Beim bereits verwendeten Bot bleiben Token und Einladung bestehen. Im Developer
Portal muss **Server Members Intent** aktiviert sein; Message Content Intent ist
für die Menübedienung nicht erforderlich. Der Bot benötigt Nachrichten senden,
Nachrichtenverlauf lesen, Links einbetten und Zugriff auf die Zielkanäle.
Rollen/Kanäle verwalten braucht er nur für die bewusste Server-Einrichtung.

`GUILD_ID` in `.env` ist die numerische ID deines Discord-Servers. Mit dieser ID
werden die Befehle direkt auf diesen Server synchronisiert. Ohne ID ist bei genau
einem Server ebenfalls Betrieb möglich; globale Befehlsupdates können verzögert
erscheinen. Bei mehreren Servern muss die ID gesetzt sein. Eine Datenbank gehört
zu genau einem Server, um keine internen Daten zwischen Servern zu teilen.

## Das Menü

| Bereich | Funktionen |
| --- | --- |
| Verkauf & Kasse | Artikel auswählen, Menge eingeben, Warenkorb abschließen, Preisliste, eigene Verkäufe, Verkaufssumme |
| Warehouse | Bestellung, Lager, offene Bestellungen, Eingang, Historie, Bestandskorrektur |
| VIP | Service-Buchungen und Summen, Karten für 1–3 Laufzeitblöcke zu je 30 Tagen, Ablaufübersicht |
| Tänzer | Mitglied und Dauer auswählen, Session buchen, aktive Sessions, eigene Session beenden; Leitung kann alle beenden |
| Security | Dienst beginnen/beenden, aktive Dienste, eigene Lohnsumme |
| Dienst & Lohn | Ein-/Ausstempeln, persönliches Abrechnungspanel, offene Provisionen, eigene Abrechnungen, Rang |
| Dienstplan | Eigenen Dienst eintragen, Leitung plant andere Mitarbeiter, Tages- und persönliche Übersicht, Eintrag löschen |
| Buchhaltung | Firmenkasse, Firmenanteil, Abrechnungen |
| Leitung | Menüs posten, Verwarnungen, Bewerbungen, Berichte, Diagnose und bewusste Server-Einrichtung |
| KI & Berichte | Nur Inhaber: lokale Regelvorlagen/Auswertungen; externe KI optional |
| Info & Bewerbung | Informationen, Rollenübersicht, Bewerbung einreichen |

Ein Bereich zeigt nur die für deine Rolle freigegebenen Aktionen. Auch beim
Ausführen werden Rechte erneut geprüft. `VIP-Kunde` ist keine Mitarbeiterrolle.
Ein persönliches Formular gehört nur dem Nutzer, der es geöffnet hat. Bei
abgelaufenen Formularen das dauerhafte Hauptmenü erneut anklicken.

## Daten und Abrechnung

Vor der ersten Migration wird die vorhandene Datenbank nach
`data/backups/bot-vor-reparatur.db` gesichert. Alte Zeitspalten werden übernommen;
Buchungshistorien werden nicht gelöscht. Von mehreren gleichzeitig offenen alten
Schichten bleibt die neueste aktiv; ältere bleiben als `bereinigt` erhalten.
Neue Datenbankzeiten sind UTC. Alte gespeicherte Zeitwerte bleiben erhalten;
ihre ursprüngliche Zeitzone kann ohne weitere Angaben nicht rekonstruiert werden.

Verkauf, VIP und Tänzer-Umsätze werden lokalen Abrechnungen eindeutig zugeordnet.
Doppelklicks auf eine Abrechnung zahlen dieselben Buchungen nicht erneut aus.
Bei alten Abrechnungen gelten Umsätze bis zum letzten gespeicherten
Abrechnungszeitpunkt als bereits abgerechnet. Frühere fehlerhafte Zahlungen werden
nicht automatisch rückgängig gemacht; bestehende Historien bleiben prüfbar.

Der Firmenanteil bleibt standardmäßig 80 %. Der Dienstbonus ist 10 % des
Mitarbeiter-Basisanteils, wenn an diesem UTC-Tag eine regulär beendete Schicht
vorliegt. Er wird vom Firmenanteil abgezogen. Automatisch ausgeloggte Schichten
lösen den Bonus nicht aus. Alle Beträge sind die Spielwährung deines Bots.

Security-Dienstlöhne sind ein getrenntes Protokoll, keine Umsatzprovision. Der
Stundenlohn muss unter `security_hourly_rate` in `config.json` festgelegt werden;
Standard **0**, solange kein tatsächlicher Lohn vereinbart ist. Die Rangtabelle
enthält weiterhin die vorhandenen Lohn-Richtwerte, legt aber keine automatische
Security-Auszahlung fest.

## Optionale externe Dienste

OpenAI bleibt standardmäßig aus, auch wenn eine alte `.env` einen API-Key enthält.
Nur `ENABLE_OPENAI=true` aktiviert diese Aufrufe; Anbietertarife und Kontingente
gelten dann. `OPENAI_CHAT_MODEL` und `OPENAI_IMAGE_MODEL` bestimmen die Modelle.
Es werden weder Kostenfreiheit noch Bildmodell-Zugang versprochen. Ohne API
sind die lokalen KI-Funktionen **Regelvorlagen und Datenbankberichte**, kein
ChatGPT-Modell und keine generative Bild-KI. Fehlgeschlagene externe Aufrufe
nutzen die vorhandenen lokalen Vorlagen; ein Fehlschlag garantiert keine Kostenfreiheit.

Google Sheets ist eine optionale Kopie abgeschlossener Verkäufe. Zuerst in deinem
eigenen Apps Script die aktualisierte `sheets/Code.gs` verwenden und die Script
Property `USHERO_SHARED_KEY` setzen. Lokal denselben Schlüssel unter
`SHEETS_SHARED_KEY` und deine Web-App-URL unter `SHEETS_URL` hinterlegen. Erst
`ENABLE_SHEETS=true` schaltet den Export ein. Ohne passenden Schlüssel liefert
auch das neue Apps-Script-Beispiel keine Daten aus. Bei einem Exportfehler bleibt
die lokale Buchung gespeichert; **nicht erneut buchen**. Eine automatische
Nachlieferung fehlgeschlagener Sheets-Kopien ist nicht implementiert.

## Prüfen und Fehler finden

**`pruefen.bat`** führt die mitgelieferten Offline-Tests mit künstlichen Testdaten
aus. Es meldet sich nicht bei Discord an und ändert deine `data/bot.db` nicht.
Alternativ nach der Installation:

```sh
python -m unittest discover -s tests -v
```

Im Leitungsmenü steht die Diagnose bereit. Bei einem Fehler nach dem Start das
sichtbare Fenster lesen. Es gibt keine versteckten Serverstarts, keine endlose
Neustartschleife und keine PowerShell-Ausführungsrichtlinien-Änderung.

Die Prüfungen und Grenzen stehen in `PRUEFBERICHT.md`. Windows-Ausführung und
Live-Discord-Interaktionen wurden in der Cloud nicht bestätigt. Ein früherer
Defender-Fund ist damit nicht als Fehlalarm widerlegt; bei einer erneuten
Erkennung die Quarantäne beibehalten und den Schutz nicht deaktivieren.
