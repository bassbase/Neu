USHERO – REPARIERTE MENUE-VERSION

1. Alten Bot beenden (Strg+C), neuen ZIP-Ordner entpacken.
2. Bisherige .env neben bot.py in den neuen Ordner kopieren.
3. Eigene data/bot.db vom gestoppten alten Bot nach data/bot.db uebernehmen.
   Diese Download-Version enthaelt keine private Datenbank.
4. start.bat oeffnen. Python 3.12 empfohlen. Paketinstallation einmal mit j bestaetigen.
5. In Discord einmal /panel durch die Leitung posten. Danach Buttons verwenden.

Fenster offen lassen; Strg+C beendet den Bot.
pruefen.bat startet Offline-Tests mit Testdaten.
README.md und PRUEFBERICHT.md enthalten Details und Grenzen.
Diese ZIP und .env enthalten private Daten und gehoeren nicht in ein oeffentliches Repository.
