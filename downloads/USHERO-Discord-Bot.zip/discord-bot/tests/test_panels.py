"""Kanalverwaltung gegen simulierte Discord-Nachrichten und echte SQLite-Speicherung."""
import asyncio
from collections import OrderedDict
import copy
import itertools
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import discord
from test_repair import Interaction,rows,execute
from utils.database import DB_PATH,init_db,add_sale
from utils.panel_specs import SPECS,match_channel
from utils.managed_panels import PanelManager,MARKER
from utils.menu_ui import HomeView,allowed
from utils.logging_ch import send_audit
from cogs.channel_panels import AreaPanelView,ChannelPanels
from bot import UsheroBot

IDS=itertools.count(1000)


def http_error(kind):
    return kind(SimpleNamespace(status=404 if kind==discord.NotFound else 403,reason='Test'),{'message':'simuliert','code':10008})


class Member:
    def __init__(self,guild,ident=1,*,bot=False,roles=(),admin=True):
        self.guild=guild;self.id=ident;self.bot=bot
        self.roles=[SimpleNamespace(name=n) for n in roles]
        self.guild_permissions=discord.Permissions.all() if admin else discord.Permissions.none()
        self.display_name='Testmitglied';self.mention=f'<@{ident}>'
        self.top_role=SimpleNamespace(position=99)
        self.display_avatar=SimpleNamespace(url='https://example.invalid/avatar')
    async def send(self,*args,**kwargs):pass


class Role:
    def __init__(self,name):self.name=name


class Guild:
    def __init__(self):
        self.id=123;self.owner_id=1;self.name='Testclub'
        self.roles=[Role(n) for n in ('@everyone','Mitarbeiter','Leitung','Buchhaltung','Verkauf','VIP','Security','Tänzer/in','Warehouse')]
        self.default_role=self.roles[0];self.categories=[];self.text_channels=[]
        self.me=Member(self,999,bot=True)
    def get_member(self,ident):return self.me if ident==999 else Member(self,ident)
    async def create_text_channel(self,name,**kwargs):
        channel=Channel(self,name);channel.overwrites=kwargs.get('overwrites');return channel


class Message:
    def __init__(self,channel,author,*,embed=None,view=None,type=discord.MessageType.default,pinned=False):
        self.id=next(IDS);self.channel=channel;self.guild=channel.guild;self.author=author
        self.embeds=[embed] if embed else [];self.components=[];self.pinned=pinned;self.type=type;self.webhook_id=None
        self.set_view(view);self.deleted=False
    def set_view(self,view):
        if view:self.components=[SimpleNamespace(children=[SimpleNamespace(custom_id=c.custom_id) for c in view.children])]
    async def edit(self,*,embed,view):self.embeds=[embed];self.set_view(view);return self
    async def pin(self,**kwargs):
        if not self.channel.can_pin:raise http_error(discord.Forbidden)
        self.pinned=True
        if self.channel.emit_pin:
            await self.channel.add(self.channel.guild.me,type=discord.MessageType.pins_add)
    async def delete(self,**kwargs):
        if self.id not in self.channel.messages:raise http_error(discord.NotFound)
        if self.author.id!=999 and not self.channel.perms.manage_messages:raise http_error(discord.Forbidden)
        self.deleted=True;self.channel.messages.pop(self.id,None)
        if self.channel.event:self.channel.event.dirty.discard(-1);await self.channel.event.deleted(self.channel.id,self.id)


class Channel:
    def __init__(self,guild,name):
        self.id=next(IDS);self.guild=guild;self.name=name;self.messages=OrderedDict()
        self.perms=discord.Permissions.all();self.can_pin=True;self.emit_pin=False;self.event=None
        self.sent=0;self.overwrites={};guild.text_channels.append(self)
    async def edit(self,**kwargs):
        if "overwrites" in kwargs:self.overwrites=kwargs["overwrites"]
        return self
    def permissions_for(self,member):return self.perms
    async def fetch_message(self,ident):
        if not self.perms.read_message_history:raise http_error(discord.Forbidden)
        if ident not in self.messages:raise http_error(discord.NotFound)
        return self.messages[ident]
    async def add(self,author,**kwargs):
        message=Message(self,author,**kwargs);self.messages[message.id]=message
        if self.event:await self.event.received(message)
        return message
    async def send(self,content=None,*,embed=None,view=None,**kwargs):
        self.sent+=1
        return await self.add(self.guild.me,embed=embed,view=view)
    async def history(self,limit=50):
        if not self.perms.read_message_history:raise http_error(discord.Forbidden)
        for message in list(reversed(list(self.messages.values())))[:limit]:yield message


class PanelTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        for suffix in ('','-wal','-shm'):Path(DB_PATH+suffix).unlink(missing_ok=True)
        await init_db()
        self.bot=UsheroBot(sync_commands=False);await self.bot.__aenter__();await self.bot.setup_hook()
        self.guild=Guild();self.now=100.0
        self.client=SimpleNamespace(user=self.guild.me,guilds=[self.guild],tree=self.bot.tree,actions=self.bot.actions,get_cog=self.bot.get_cog)
        self.client.get_channel=lambda ident: next((c for c in self.guild.text_channels if c.id==ident),None)
        self.manager=PanelManager(self.client,AreaPanelView,clock=lambda:self.now);await self.manager.load()
        self.owner=Member(self.guild)
    async def asyncTearDown(self):await self.bot.close()
    def interaction(self,user=None,channel=None):
        result=Interaction(user or self.owner,self.client)
        if channel is not None:result.channel=channel
        return result
    async def managed(self,name='verkauf',key='verkauf',*,clean=True):
        channel=Channel(self.guild,name);channel.event=self.manager
        await self.manager.post(channel,key,clean=clean)
        return channel

    async def test_01_matching_handles_decorations_duplicates_and_explicit_ids(self):
        a=Channel(self.guild,'💰│Verkauf');v=Channel(self.guild,'⭐・VIP')
        self.assertIs(match_channel(self.guild,SPECS['verkauf']),a)
        self.assertIs(match_channel(self.guild,SPECS['vip']),v)
        Channel(self.guild,'verkauf')
        with self.assertRaises(ValueError):match_channel(self.guild,SPECS['verkauf'])
        self.assertIs(match_channel(self.guild,SPECS['verkauf'],{'verkauf':a.id}),a)
        with self.assertRaises(ValueError):match_channel(self.guild,SPECS['vip'],{'vip':'999999999'})

    async def test_02_installer_creates_and_registers_right_area_menus_idempotently(self):
        existing=Channel(self.guild,'Verkauf');history=await existing.add(Member(self.guild,2))
        cog=ChannelPanels(self.client);cog.manager=self.manager
        await cog.install(self.interaction())
        self.assertEqual(len(self.manager.records),len(SPECS))
        self.assertTrue(history.id in existing.messages)
        for key,spec in SPECS.items():
            record=next(r for r in self.manager.records.values() if r['panel_key']==key)
            channel=self.client.get_channel(record['channel_id'])
            message=await channel.fetch_message(record['message_id'])
            self.assertTrue(message.pinned)
            self.assertEqual(record['clean_chat'],int(spec.clean))
            self.assertEqual(len([m for m in channel.messages.values() if self.manager.owned_menu(m)]),1)
            if key!='home':
                view=AreaPanelView(key);self.assertTrue(view.is_persistent())
                for action,label,emoji in spec.actions:self.assertIn(f'ushero:work:{key}:{action}',[c.custom_id for c in view.children])
        ids={ident:r['message_id'] for ident,r in self.manager.records.items()}
        await cog.install(self.interaction())
        self.assertEqual(ids,{ident:r['message_id'] for ident,r in self.manager.records.items()})
        self.assertTrue(history.id in existing.messages)

    async def test_03_direct_area_buttons_open_private_cart_and_order_form(self):
        channel=await self.managed()
        before=channel.sent
        view=AreaPanelView('verkauf');button=next(c for c in view.children if c.label=='Warenkorb öffnen')
        interaction=self.interaction(channel=channel);await button.callback(interaction)
        self.assertEqual(interaction.messages[-1][1]['view'].__class__.__name__,'WarenkorbView')
        self.assertTrue(interaction.messages[-1][1]['ephemeral'])
        view=AreaPanelView('warehouse');button=next(c for c in view.children if c.label=='Bestellen')
        interaction=self.interaction(channel=channel);await button.callback(interaction)
        self.assertEqual(interaction.messages[-1][1]['view'].__class__.__name__,'ActionView')
        self.assertTrue(interaction.messages[-1][1]['ephemeral'])
        self.assertEqual(channel.sent,before)
        guest=Member(self.guild,5,admin=False)
        with self.assertRaises(discord.app_commands.CheckFailure):await button.callback(self.interaction(guest,channel))

    async def test_04_new_work_chat_is_removed_without_deleting_history_or_ledger(self):
        channel=Channel(self.guild,'verkauf');old=await channel.add(Member(self.guild,2))
        channel.event=self.manager;await self.manager.post(channel,'verkauf')
        menu_id=self.manager.records[channel.id]['message_id']
        await add_sale(2,'Testartikel',100)
        message=await channel.add(Member(self.guild,3))
        self.now+=9;await self.manager.drain();self.assertIn(message.id,channel.messages)
        self.now+=2;await self.manager.drain()
        self.assertNotIn(message.id,channel.messages);self.assertIn(old.id,channel.messages)
        self.assertEqual(self.manager.records[channel.id]['message_id'],menu_id)
        self.assertEqual(rows('SELECT SUM(amount*quantity) FROM sales'),[(100,)])
        self.assertEqual(channel.sent,1)

    async def test_05_other_bots_are_preserved_and_menu_moves_down_once(self):
        channel=await self.managed();first=self.manager.records[channel.id]['message_id']
        message=await channel.add(Member(self.guild,77,bot=True))
        self.now+=16
        await asyncio.gather(self.manager.refresh(channel.id),self.manager.refresh(channel.id))
        current=self.manager.records[channel.id]['message_id']
        self.assertNotEqual(current,first);self.assertNotIn(first,channel.messages)
        self.assertIn(message.id,channel.messages)
        self.assertEqual(len([m for m in channel.messages.values() if self.manager.owned_menu(m)]),1)
        self.assertEqual(channel.sent,2)
        await self.manager.drain();self.assertEqual(channel.sent,2)

    async def test_06_restart_reloads_menus_and_recovers_a_deleted_one(self):
        channel=await self.managed();message_id=self.manager.records[channel.id]['message_id']
        restored=PanelManager(self.client,AreaPanelView,clock=lambda:self.now)
        await restored.load();channel.event=restored
        self.assertEqual(restored.records[channel.id]['message_id'],message_id)
        await channel.messages[message_id].delete();await restored.drain()
        self.assertNotEqual(restored.records[channel.id]['message_id'],message_id)
        self.assertEqual(len([m for m in channel.messages.values() if restored.owned_menu(m)]),1)

    async def test_07_stopping_cancels_pending_deletions_and_sticky_updates(self):
        channel=await self.managed();message=await channel.add(Member(self.guild,3))
        await self.manager.unregister(channel.id)
        self.now+=30;await self.manager.drain()
        self.assertIn(message.id,channel.messages);self.assertEqual(channel.sent,1)
        self.assertEqual(rows('SELECT COUNT(*) FROM channel_panels'),[(0,)])

    async def test_08_pinned_user_messages_and_unmanaged_channels_are_preserved(self):
        channel=await self.managed();message=await channel.add(Member(self.guild,3))
        pinned=copy.copy(message);pinned.pinned=True;channel.messages[message.id]=pinned
        other=Channel(self.guild,'mitarbeiter-chat');other.event=self.manager
        other_message=await other.add(Member(self.guild,3))
        self.now+=20;await self.manager.drain()
        self.assertIn(message.id,channel.messages);self.assertIn(other_message.id,other.messages)

    async def test_09_pin_notifications_do_not_cause_menu_repost_loop(self):
        channel=Channel(self.guild,'hauptmenue');channel.emit_pin=True;channel.event=self.manager
        await self.manager.post(channel,'home',clean=False)
        self.assertEqual(len(channel.messages),2)
        self.now+=3;await self.manager.drain()
        self.assertEqual(len(channel.messages),1)
        self.now+=60;await self.manager.drain();self.assertEqual(channel.sent,1)

    async def test_10_missing_cleanup_or_pin_permissions_are_reported_and_safe(self):
        channel=Channel(self.guild,'verkauf');channel.event=self.manager
        channel.perms.manage_messages=False;channel.can_pin=False
        result=await self.manager.post(channel,'verkauf')
        self.assertFalse(result['clean']);self.assertFalse(result['pinned'])
        message=await channel.add(Member(self.guild,3))
        self.now+=30;await self.manager.drain()
        self.assertIn(message.id,channel.messages)
        # Wurden Rechte erst nach der Registrierung entzogen, ebenfalls stoppen.
        channel.perms.manage_messages=True;await self.manager.post(channel,'verkauf')
        message=await channel.add(Member(self.guild,4));channel.perms.manage_messages=False
        self.now+=20;await self.manager.drain()
        self.assertIn(message.id,channel.messages)
        self.assertFalse(self.manager.records[channel.id]['clean_chat'])

    async def test_11_logs_are_routed_outside_managed_channels_and_never_cleaned(self):
        channel=await self.managed();audit=Channel(self.guild,'audit-logs');audit.event=self.manager
        self.assertTrue(await send_audit(self.guild,'Buchung protokolliert',preferred=('verkauf',)))
        self.assertEqual(audit.sent,1);self.assertEqual(channel.sent,1)
        ident=next(iter(audit.messages));self.now+=30;await self.manager.drain()
        self.assertIn(ident,audit.messages)

    async def test_12_installer_permission_and_no_creation_mode(self):
        cog=ChannelPanels(self.client);cog.manager=self.manager
        await cog.install(self.interaction(Member(self.guild,5,admin=False)))
        self.assertEqual(len(self.guild.text_channels),0)
        await cog.install(self.interaction(),create_missing=False)
        self.assertEqual(len(self.guild.text_channels),0)
        channel=Channel(self.guild,'verkauf');await cog.install(self.interaction(),create_missing=False)
        self.assertEqual(len(self.manager.records),1)
        self.assertIn(channel.id,self.manager.records)

    async def test_13_unpin_repairs_without_extra_menu_and_foreign_saved_message_is_refused(self):
        channel=await self.managed();message_id=self.manager.records[channel.id]['message_id']
        channel.messages[message_id].pinned=False;self.manager.dirty.add(channel.id)
        self.now+=20;await self.manager.drain()
        self.assertTrue(channel.messages[message_id].pinned);self.assertEqual(channel.sent,1)
        foreign=await channel.add(Member(self.guild,22,bot=True))
        self.manager.records[channel.id]['message_id']=foreign.id
        with self.assertRaises(ValueError):await self.manager.post(channel,'verkauf')
        self.assertIn(foreign.id,channel.messages)

    async def test_14_employee_role_does_not_grant_other_departments_and_home_is_filtered(self):
        from utils.perms import can_use_area,is_leitung
        from utils.menu_ui import HomeView
        employee=Member(self.guild,2,roles=['Mitarbeiter'],admin=False)
        seller=Member(self.guild,3,roles=['Mitarbeiter','Verkauf'],admin=False)
        finance=Member(self.guild,4,roles=['Mitarbeiter','Buchhaltung'],admin=False)
        for area in ('verkauf','vip','warehouse','taenzer','security','buchhaltung','leitung','ki'):
            self.assertFalse(can_use_area(employee,area),area)
        self.assertTrue(can_use_area(seller,'verkauf'));self.assertFalse(can_use_area(seller,'vip'))
        self.assertTrue(can_use_area(finance,'buchhaltung'));self.assertFalse(is_leitung(finance))
        self.assertFalse(can_use_area(finance,'leitung'))
        public=HomeView();self.assertEqual(len(public.children),1)
        private=HomeView(employee)
        ids=[item.custom_id for item in private.children]
        self.assertIn('ushero:area:dienst',ids);self.assertNotIn('ushero:area:verkauf',ids)
        self.assertNotIn('ushero:area:vip',ids);self.assertNotIn('ushero:install-panels',ids)
        seller_ids=[item.custom_id for item in HomeView(seller).children]
        self.assertIn('ushero:area:verkauf',seller_ids);self.assertNotIn('ushero:area:vip',seller_ids)

    async def test_15_real_discord_channel_permissions_remove_broad_and_member_specific_allows(self):
        from utils.perms import channel_overwrites
        state=self.bot._connection
        roledata=[{'id':'123','name':'@everyone','permissions':str(discord.Permissions(view_channel=True,send_messages=True).value),'position':0,'color':0}]
        for ident,name in ((11,'Mitarbeiter'),(12,'Verkauf'),(13,'VIP'),(14,'Buchhaltung')):
            roledata.append({'id':str(ident),'name':name,'permissions':'0','position':1,'color':0})
        roledata.append({'id':'15','name':'Fremde Adminrolle','permissions':'8','position':2,'color':0})
        guild=discord.Guild(data={'id':'123','name':'Real test','owner_id':'1','roles':roledata},state=state)
        def member(ident,roles):
            result=discord.Member(data={'user':{'id':str(ident),'username':'Test','discriminator':'0','avatar':None},'roles':[str(r) for r in roles],'joined_at':'2026-01-01T00:00:00+00:00','flags':0},guild=guild,state=state)
            guild._add_member(result);return result
        ordinary=member(2,[11]);seller=member(3,[11,12]);vip=member(4,[11,13]);finance=member(5,[11,14]);native_admin=member(6,[11,15])
        existing={guild.get_role(11):discord.PermissionOverwrite(view_channel=True),vip:discord.PermissionOverwrite(view_channel=True)}
        with patch.object(state,'user',SimpleNamespace(id=999)):
            overwrites=await channel_overwrites(guild,'verkauf',existing)
        raw=[]
        for target,value in overwrites.items():
            allow,deny=value.pair();raw.append({'id':str(target.id),'type':0 if isinstance(target,discord.Role) else 1,'allow':str(allow.value),'deny':str(deny.value)})
        channel=discord.TextChannel(state=state,guild=guild,data={'id':'999','name':'verkauf','type':0,'position':0,'permission_overwrites':raw})
        self.assertFalse(channel.permissions_for(ordinary).view_channel)
        self.assertTrue(channel.permissions_for(seller).view_channel)
        self.assertFalse(channel.permissions_for(vip).view_channel)
        self.assertFalse(channel.permissions_for(finance).view_channel)
        self.assertFalse(channel.permissions_for(seller).send_messages)
        self.assertTrue(channel.permissions_for(native_admin).view_channel)  # Discord-Administrator umgeht Kanalverbote.

    async def test_16_existing_channel_overwrites_are_repaired_on_install(self):
        channel=Channel(self.guild,'verkauf')
        employee=next(r for r in self.guild.roles if r.name=='Mitarbeiter')
        seller=next(r for r in self.guild.roles if r.name=='Verkauf')
        vip=next(r for r in self.guild.roles if r.name=='VIP')
        channel.overwrites={employee:discord.PermissionOverwrite(view_channel=True),vip:discord.PermissionOverwrite(view_channel=True)}
        cog=ChannelPanels(self.client);cog.manager=self.manager
        await cog.install(self.interaction(),create_missing=False)
        self.assertFalse(channel.overwrites[employee].view_channel)
        self.assertTrue(channel.overwrites[seller].view_channel)
        self.assertFalse(channel.overwrites[vip].view_channel)
