"""Einmaliges Laden aller Module vor der Discord-Verbindung."""
import logging
import os
import discord
from discord.ext import commands
from dotenv import load_dotenv
from utils.config import ROOT
from utils.database import init_db

EXTENSIONS = (
    'admin', 'arbeit', 'buchhaltung', 'channel_panels', 'diagnose', 'dienstplan',
    'ki', 'logs_report', 'rang', 'schicht', 'security', 'setup_server',
    'start_hilfe_fixed', 'taenzer', 'verkauf', 'vip', 'warehouse', 'panel', 'menu', 'auto_tasks',
)


class UsheroTree(discord.app_commands.CommandTree):
    async def interaction_check(self, interaction):
        from utils.menu_ui import allowed, reply, validate, server_allowed
        if not server_allowed(self.client, interaction.guild):
            await reply(interaction, 'Bitte auf dem konfigurierten Server verwenden; bei mehreren Servern GUILD_ID in .env setzen.')
            return False
        command = interaction.command
        if command and not allowed(interaction.user, command):
            await reply(interaction, '❌ Deine Rolle darf diese Aktion nicht verwenden.')
            return False
        try:
            validate(vars(interaction.namespace))
        except ValueError as error:
            await reply(interaction,str(error))
            return False
        return True

    async def on_error(self, interaction, error):
        from utils.menu_ui import show_error
        await show_error(interaction, error)


class UsheroBot(commands.Bot):
    def __init__(self, *, sync_commands=True):
        intents = discord.Intents.default()
        intents.members = True
        super().__init__(command_prefix=commands.when_mentioned, intents=intents, tree_cls=UsheroTree,
                         allowed_mentions=discord.AllowedMentions.none())
        self.sync_commands = sync_commands

    async def setup_hook(self):
        await init_db()
        for module in EXTENSIONS:
            await self.load_extension(f'cogs.{module}')
            logging.info('Modul geladen: %s', module)
        if self.sync_commands:
            raw_id = os.getenv('GUILD_ID', '').strip()
            if raw_id:
                if not raw_id.isdecimal():
                    raise ValueError('GUILD_ID muss die numerische Discord-Server-ID sein.')
                guild = discord.Object(id=int(raw_id))
                self.tree.copy_global_to(guild=guild)
                await self.tree.sync(guild=guild)
            else:
                await self.tree.sync()
            logging.info('Menue und Befehle synchronisiert.')

    async def on_ready(self):
        logging.info('Online: %s. Einmal /panel posten, danach die Buttons verwenden.', self.user)


def main():
    load_dotenv(ROOT / '.env')
    token = os.getenv('DISCORD_TOKEN', '').strip()
    if not token or token == 'HIER_DEIN_BOT_TOKEN':
        raise SystemExit('DISCORD_TOKEN fehlt. Bestehende .env in diesen Ordner kopieren oder .env.example ausfuellen.')
    bot = UsheroBot()
    try:
        bot.run(token, log_level=logging.INFO)
    except discord.LoginFailure:
        raise SystemExit('Discord hat den Bot-Token abgelehnt. .env pruefen; Token nicht im Chat veroeffentlichen.')
    except discord.PrivilegedIntentsRequired:
        raise SystemExit('Im Discord Developer Portal fuer diesen Bot SERVER MEMBERS INTENT aktivieren.')


if __name__ == '__main__':
    main()
