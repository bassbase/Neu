# ✦ USHERO · Nightclub – reparierte Menü-Version

Dein vorhandener Bot mit Neon-Farben, Artikeln und Bereichen als Grundlage. Die
Aktionen laufen über Buttons, Auswahllisten und Formulare. In Discord bleiben nur **`/menu` und `/panel`** sichtbar. Alle Fachfunktionen
liegen im Menü; alte globale und serverbezogene Doppeleinträge dieses Bots
werden beim Start synchronisiert und entfernt.

## Start auf deinem Windows-PC

1. Den bisherigen Bot mit **Strg+C** beenden. Den alten Ordner als Sicherung behalten.
2. Diese ZIP **in einen neuen Ordner entpacken**.
3. Deine bisherige **`.env`** neben `bot.py` in den neuen Ordner kopieren. Die ZIP
   enthält absichtlich keine Zugangsdaten. Ohne vorhandene `.env` fragt der Starter
   den Bot-Token verdeckt ab und speichert ihn nur lokal.
4. **`start.bat`** öffnen. Python 3.12 wird empfohlen; unterstützt sind 3.11–3.14.
   Python 3.15 wurde nicht geprüft und wird vom Starter abgelehnt. Beim ersten Mal
   die Paketinstallation mit `j` bestätigen. Das Bot-Fenster offen lassen.
5. In Discord als Leitung einmal **`/panel`** aufrufen. Der Bot ordnet danach
   die Bereichsmenüs automatisch den passenden Kanälen zu und legt fehlende
   Arbeitskanäle an, sofern er die Rechte hat. Danach die Buttons im jeweiligen
   Kanal verwenden. „Kanalmenüs einrichten“ im Hauptmenü bietet Optionen für Kanalanlage und
   Chatbereinigung. Bereits gepostete alte Hauptbuttons bleiben erreichbar.

**Diese Download-Version enthält keine Zugangsdaten und keine private Datenbank.**
Vor dem Update den alten Bot beenden. Kopiere die bisherige `.env` und die
aktuellste `data/bot.db` aus deinem gestoppten Bot in den neuen Ordner. Die
Datenbank gehört wieder nach `data/bot.db`. Ohne übernommene Datenbank beginnt
der Bot mit leeren Tabellen. Den bisherigen Ordner unverändert als Sicherung
behalten. Nach dem Start einmal `/panel` für die neue Kanalzuordnung ausführen.

## Bereichsmenüs und aufgeräumte Arbeitskanäle

`/panel` oder „Kanalmenüs einrichten“ im Hauptmenü verteilt dauerhaft sichtbare
Menüs. Ein nur für dich sichtbares Hauptmenü ist dafür nicht ausreichend.

| Kanal | Dauerhafte Buttons |
| --- | --- |
| `hauptmenue` | Hauptmenü mit allen Bereichen |
| `verkauf` | Warenkorb, Preisliste, eigene Verkäufe, Summe |
| `warehouse-bestellungen` | Bestellen, offene Bestellungen, Lieferung, Historie |
| `warehouse-lager` | Lagerbestand und Korrektur |
| `vip` | VIP-Service, Karten und Laufzeiten |
| `taenzer` | Sessions und Timer |
| `security` | Security-Dienst und Lohnprotokoll |
| `stempeluhr` | Dienst starten/beenden, Verdienst und Abrechnung |
| `dienstplan` | Schichtplan und Eintragungen |
| `buchhaltung` | Firmenkasse und Abrechnungen |
| `bot-verwaltung` | Leitung, Menüverwaltung und Diagnose |
| `ki-panel` | Inhaber-Funktionen |
| `bot-info` | Informationen und Bewerbung |

Vorhandene passende Kanäle werden verwendet, auch mit üblichen Emoji-Präfixen.
Fehlende Kanäle werden mit vorhandenen Teamrollen neu angelegt; wenn eine passende
USHERO-Kategorie schon existiert, dort. Bestehende Kanäle werden nicht verschoben. Ihre Sichtrechte werden jetzt
gezielt auf zuständige Abteilungen korrigiert; breite Mitarbeiter- und alte
Einzelfreigaben werden dabei bereinigt. Rollen und Nachrichten werden nicht gelöscht. Bei gleichen Kanalnamen meldet der
Bot den Konflikt. Optional in `config.json` unter `panel_channels` die IDs zuordnen,
etwa `{"verkauf": 123456789012345678, "vip": 234567890123456789}`. Diese Zahlen sind
nur Beispiele. Registrierung und Menü-Nachrichten-ID bleiben in SQLite gespeichert.

Die Menüs werden angeheftet und bei Bedarf wieder als letzte Nachricht angezeigt.
Discord bietet kein frei schwebendes oder dauerhaft über anderen Beiträgen
liegendes Menü. Aktualisierungen erfolgen gebündelt, höchstens etwa einmal je
15 Sekunden und Kanal; das verhindert ständiges Neuposten. Beim Neustart lädt
der Bot seine gespeicherten Menüs; ein gelöschtes eigenes Menü wird ersetzt.

Verkauf, Bestellung und andere Aktionen antworten privat, damit keine öffentlichen
Bestätigungen den Kanal füllen. Einfache private Ergebnisse verschwinden nach
ungefähr zwei Minuten. Persönliche Formulare bleiben für ihre Bedienzeit offen.
Neue öffentliche Nachrichten in registrierten **Arbeitskanälen** werden nach
ungefähr zehn Sekunden entfernt, sofern „Nachrichten verwalten“ erlaubt ist.
Nur neue Beiträge nach der Einrichtung werden erfasst, kein alter Verlauf.
Angeheftete Nutzernachrichten, fremde Bots und Webhooks bleiben unberührt.
Das Hauptmenü und der Info-Kanal sind keine automatisch bereinigten Arbeitschats.

Verkaufs-, Lager-, Dienst- und Abrechnungsdaten werden nicht gelöscht. Protokolle
werden in getrennte Log-Kanäle geleitet; registrierte Menükanäle sind als
Protokollziele ausgeschlossen. Wenn kein geeigneter Log-Kanal existiert, bleibt
die Datenbank der Nachweis. Auch Protokollkanäle werden nicht automatisch bereinigt.

Der Bot braucht in Menükanälen **Kanal ansehen, Verlauf lesen, Nachrichten senden,
Links einbetten**, zusätzlich **Nachrichten anheften** und für Chatbereinigung
**Nachrichten verwalten**. Die Einrichtung meldet fehlende Rechte und schaltet
Bereinigung bei fehlenden Löschrechten nicht ein. Zum Anlegen fehlender Kanäle
braucht er „Kanäle verwalten“. Es werden keine Mitarbeiterrollen gelöscht.

Im Leitungsmenü zeigt „Kanalmenüs prüfen“ die Zuordnung. Über „Weitere
Bereichsaktionen“ sind Stoppen der Menüautomatik, bewusste Einzelzuordnung und
Chatbereinigung erreichbar. „Kanalmenüs einrichten“ hat eine Option, mit der die
Bereinigung abgeschaltet werden kann. Es werden keine zusätzlichen Slash-
Befehle für diese Aktionen benötigt.

## Discord-Einstellungen

Beim bereits verwendeten Bot bleiben Token und Einladung bestehen. Im Developer
Portal muss **Server Members Intent** aktiviert sein; Message Content Intent ist
für die Menübedienung nicht erforderlich. Der Bot benötigt Nachrichten senden,
Nachrichtenverlauf lesen, Links einbetten und Zugriff auf die Zielkanäle.
Rollen/Kanäle verwalten braucht er nur für die bewusste Server-Einrichtung.

`GUILD_ID` in `.env` ist die numerische ID deines Discord-Servers. Mit dieser ID
werden die beiden Navigationseinträge auf diesen Server synchronisiert. Ohne ID
werden sie nach der ersten Verbindung auf den einzigen verbundenen Server
synchronisiert. Frühere globale Einträge werden entfernt. Ein erneutes Öffnen
des Discord-Clients kann nötig sein, bis alte Anzeigeeinträge verschwinden. Bei mehreren Servern muss die ID gesetzt sein. Eine Datenbank gehört
zu genau einem Server, um keine internen Daten zwischen Servern zu teilen.

## Das Menü

| Bereich | Funktionen |
| --- | --- |
| Verkauf & Kasse | Artikel auswählen, Menge eingeben, Warenkorb abschließen, Preisliste, eigene Verkäufe, Verkaufssumme |
| Warehouse | Bestellung, Lager, offene Bestellungen, Eingang, Historie, Bestandskorrektur |
| VIP | Service-Buchungen und Summen, Karten für 1–3 Laufzeitblöcke zu je 30 Tagen, Ablaufübersicht |
| Tänzer | Mitglied und Dauer auswählen, Session buchen, aktive Sessions, eigene Session beenden; Leitung kann alle beenden |
| Security | Dienst beginnen/beenden, aktive Dienste, eigene Lohnsumme |
| Dienst & Lohn | Ein-/Ausstempeln, persönliches Abrechnungspanel, offene Provisionen, eigene Abrechnungen, Rang |
| Dienstplan | Eigenen Dienst eintragen, Leitung plant andere Mitarbeiter, Tages- und persönliche Übersicht, Eintrag löschen |
| Buchhaltung | Firmenkasse, Firmenanteil, Abrechnungen |
| Leitung | Menüs posten, Verwarnungen, Bewerbungen, Berichte, Diagnose und bewusste Server-Einrichtung |
| KI & Berichte | Nur Inhaber: lokale Regelvorlagen/Auswertungen; externe KI optional |
| Info & Bewerbung | Informationen, Rollenübersicht, Bewerbung einreichen |

Ein Bereich zeigt nur die für deine Rolle freigegebenen Aktionen. Auch beim
Ausführen werden Rechte erneut geprüft. `VIP-Kunde` ist keine Mitarbeiterrolle.
Ein persönliches Formular gehört nur dem Nutzer, der es geöffnet hat. Bei
abgelaufenen Formularen das dauerhafte Hauptmenü erneut anklicken.

## Strikte Abteilungstrennung

Die allgemeine Rolle **Mitarbeiter** öffnet nur den gemeinsamen Einstieg und
persönliche Dienst-/Planfunktionen. Für Verkauf, VIP, Warehouse, Tänzer oder
Security braucht man zusätzlich die jeweilige Abteilungsrolle. Buchhaltung ist
von der allgemeinen Leitung getrennt und erlaubt keine Server-/Menüverwaltung.
Leitung und Schichtleitung haben ihre festgelegten übergreifenden Aufgaben;
Geldverwaltung ist nicht allein durch eine Mitarbeiterrolle freigegeben.

Öffentliche Hauptmenüs zeigen nur „Meinen Arbeitsplatz öffnen“. Das persönliche
Menü enthält ausschließlich erlaubte Bereiche. In Fachkanälen bleiben die
passenden Bereichsbuttons, keine allgemeine Liste fremder Abteilungen. Normale
Mitarbeiter sehen im Dienstplan nur eigene Einträge. Bestehende Kanäle werden
bei `/panel` und gespeicherte Zuordnungen beim Neustart abgesichert; bekannte
USHERO-Protokollkanäle werden ebenfalls getrennt. Alte eigene Sammelmenüs im
Mitarbeiter-Chat werden entfernt, fremde Nachrichten bleiben erhalten.

Der Bot braucht zum Reparieren der Kanalrechte Rechte zur Kanal-/Rollenverwaltung.
Fehler werden bei der Einrichtung gemeldet. **Discord-Administrator und
Serverinhaber umgehen Kanalverbote.** Eine Mitarbeiterrolle mit Administrator
muss der Serverinhaber korrigieren; der Bot entzieht solche globalen Rechte
nicht eigenmächtig. Zum Prüfen ein normales Mitarbeiterkonto verwenden.

Individuelle Rollennamen können unter `roles` zugeordnet werden; für explizite
Abteilungsrollen sind `area_role_ids` in config.json verfügbar. Keine allgemeine
Mitarbeiter-/Everyone-Rolle dort als sämtliche Fachbereiche freigeben.

## Daten und Abrechnung

Vor der ersten Migration wird die vorhandene Datenbank nach
`data/backups/bot-vor-reparatur.db` gesichert. Alte Zeitspalten werden übernommen;
Buchungshistorien werden nicht gelöscht. Von mehreren gleichzeitig offenen alten
Schichten bleibt die neueste aktiv; ältere bleiben als `bereinigt` erhalten.
Neue Datenbankzeiten sind UTC. Alte gespeicherte Zeitwerte bleiben erhalten;
ihre ursprüngliche Zeitzone kann ohne weitere Angaben nicht rekonstruiert werden.

Verkauf, VIP und Tänzer-Umsätze werden lokalen Abrechnungen eindeutig zugeordnet.
Doppelklicks auf eine Abrechnung zahlen dieselben Buchungen nicht erneut aus.
Bei alten Abrechnungen gelten Umsätze bis zum letzten gespeicherten
Abrechnungszeitpunkt als bereits abgerechnet. Frühere fehlerhafte Zahlungen werden
nicht automatisch rückgängig gemacht; bestehende Historien bleiben prüfbar.

Der Firmenanteil bleibt standardmäßig 80 %. Der Dienstbonus ist 10 % des
Mitarbeiter-Basisanteils, wenn an diesem UTC-Tag eine regulär beendete Schicht
vorliegt. Er wird vom Firmenanteil abgezogen. Automatisch ausgeloggte Schichten
lösen den Bonus nicht aus. Alle Beträge sind die Spielwährung deines Bots.

Security-Dienstlöhne sind ein getrenntes Protokoll, keine Umsatzprovision. Der
Stundenlohn muss unter `security_hourly_rate` in `config.json` festgelegt werden;
Standard **0**, solange kein tatsächlicher Lohn vereinbart ist. Die Rangtabelle
enthält weiterhin die vorhandenen Lohn-Richtwerte, legt aber keine automatische
Security-Auszahlung fest.

## Optionale externe Dienste

OpenAI bleibt standardmäßig aus, auch wenn eine alte `.env` einen API-Key enthält.
Nur `ENABLE_OPENAI=true` aktiviert diese Aufrufe; Anbietertarife und Kontingente
gelten dann. `OPENAI_CHAT_MODEL` und `OPENAI_IMAGE_MODEL` bestimmen die Modelle.
Es werden weder Kostenfreiheit noch Bildmodell-Zugang versprochen. Ohne API
sind die lokalen KI-Funktionen **Regelvorlagen und Datenbankberichte**, kein
ChatGPT-Modell und keine generative Bild-KI. Fehlgeschlagene externe Aufrufe
nutzen die vorhandenen lokalen Vorlagen; ein Fehlschlag garantiert keine Kostenfreiheit.

**Google Sheets ist vollständig neu aufgebaut:** `sheets/USHERO-Dashboard.xlsx`
enthält 13 farbige Blätter und ein Dashboard. `sheets/Code.gs` gestaltet eine
Google-Tabelle und spiegelt Verkauf, VIP, Lager, Schichten, Abrechnungen und Team.
Der vollständige Datenstand wird etwa jede Minute abgeglichen, ohne neue Zeilen
bei jedem Wiederholungsversuch anzuhängen. Zurück nach Discord/Bot gehen nur
Lagerbestand und Dienstplan über das Blatt Änderungen; Geldbuchungen bleiben im Bot. Die lokale Datenbank bleibt die
Buchungsbasis; alte Tabellenlayouts werden vor einer Umstellung archiviert.

Die einmalige Einrichtung in Google steht in **`sheets/README.md`**. Anschließend
**`Sheets-verbinden.bat`** öffnen und URL/Schlüssel lokal eingeben, Bot neu starten
und unter **Buchhaltung → Sheets-Status / Sheets abgleichen** prüfen. Die Datei ist
eine Vorlage; Google-Autorisierung und Live-Verbindung sind nicht automatisch
bereits eingerichtet. Ohne ausdrückliche Aktivierung bleibt Sheets aus.

## Prüfen und Fehler finden

**`pruefen.bat`** führt die mitgelieferten Offline-Tests mit künstlichen Testdaten
aus. Es meldet sich nicht bei Discord an und ändert deine `data/bot.db` nicht.
Der Apps-Script-Offlinetest verwendet optional Node.js und wird ohne Node
übersprungen. Für den Bot selbst wird Node nicht benötigt. Alternativ nach der Installation:

```sh
python -m unittest discover -s tests -v
```

Im Leitungsmenü steht die Diagnose bereit. Bei einem Fehler nach dem Start das
sichtbare Fenster lesen. Es gibt keine versteckten Serverstarts, keine endlose
Neustartschleife und keine PowerShell-Ausführungsrichtlinien-Änderung.

Die Prüfungen und Grenzen stehen in `PRUEFBERICHT.md`. Windows-Ausführung und
Live-Discord-Interaktionen wurden in der Cloud nicht bestätigt. Ein früherer
Defender-Fund ist damit nicht als Fehlalarm widerlegt; bei einer erneuten
Erkennung die Quarantäne beibehalten und den Schutz nicht deaktivieren.
