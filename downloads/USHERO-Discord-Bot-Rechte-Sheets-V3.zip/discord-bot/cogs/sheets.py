"""Optionaler Sheets-Abgleich mit eigenem Timer und manuellen Menüaktionen."""
import discord
from discord import app_commands
from discord.ext import commands,tasks
from utils.sheet_sync import SheetSync
from utils.menu_ui import reply


class Sheets(commands.Cog):
    def __init__(self,bot):self.bot=bot;self.service=SheetSync(bot)
    async def cog_load(self):self.refresh.start()
    def cog_unload(self):self.refresh.cancel()

    @tasks.loop(seconds=60)
    async def refresh(self):
        if self.service.enabled():await self.service.sync()

    @refresh.before_loop
    async def before(self):await self.bot.wait_until_ready()

    @app_commands.command(name='sheets-status',description='Sheets-Verbindung und letzten Abgleich anzeigen')
    async def status(self,interaction: discord.Interaction):
        embed=discord.Embed(title='📊 USHERO · Google Sheets',color=0x00D9E8)
        embed.add_field(name='Betrieb',value='Aktiv · Abgleich etwa jede Minute' if self.service.enabled() else 'Deaktiviert · Verbindung einrichten',inline=False)
        embed.add_field(name='Letzter bestätigter Abgleich',value=self.service.last_ok or 'Noch nicht bestätigt',inline=False)
        if self.service.last_error:embed.add_field(name='Hinweis',value=self.service.last_error,inline=False)
        embed.add_field(name='Rückweg',value='Nur Lagerbestand und Dienstplan · Geldbuchungen nur im Bot',inline=False)
        embed.add_field(name='Zuletzt neu übernommen',value=str(self.service.last_imports),inline=True)
        if self.service.last_rejected:embed.add_field(name='Nicht übernommen',value=str(self.service.last_rejected)+' · Details im Sheets-Blatt Änderungen',inline=False)
        embed.set_footer(text='Die lokale Datenbank bleibt erhalten. Vorlage und Anleitung im Ordner sheets.')
        await reply(interaction,embed=embed)

    @app_commands.command(name='sheets-sync',description='Vollständigen Sheets-Spiegel jetzt aktualisieren')
    async def sync_now(self,interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        result=await self.service.sync(force=True)
        text='✅ Sheets-Datenstand bestätigt.' if result.get('ok') else '⚠️ '+result.get('error','Abgleich nicht bestätigt.')
        if result.get('ok') and self.service.last_rejected:text+=' '+str(self.service.last_rejected)+' Änderung(en) abgewiesen; Details im Blatt Änderungen.'
        await reply(interaction,text)


async def setup(bot):await bot.add_cog(Sheets(bot))
