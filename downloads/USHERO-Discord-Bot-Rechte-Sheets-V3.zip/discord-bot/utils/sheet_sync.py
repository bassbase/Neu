"""Konsistenter, wiederholbarer Sheets-Spiegel; Google ist nicht die Buchungsdatenbank."""
import asyncio
import hashlib
import json
import os
import uuid
from datetime import datetime,timezone
import aiosqlite
from utils.database import DB_PATH
from utils.sheet_schema import TABLES
from utils.sheets import sheets_post

MAX_ROWS=10000
MAX_PAYLOAD=7*1024*1024


async def build_snapshot(team=()):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT)')
        await db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('sheets_source_id',?)",(str(uuid.uuid4()),))
        await db.commit()
        await db.execute('BEGIN')
        source=(await (await db.execute("SELECT value FROM settings WHERE key='sheets_source_id'")).fetchone())[0]
        tables={}
        for spec in TABLES:
            if spec['sql']:
                rows=await (await db.execute(spec['sql']+' LIMIT 10001')).fetchall()
            else:rows=list(team)
            if len(rows)>MAX_ROWS:raise ValueError(f"{spec['name']}: mehr als 10000 Einträge. Kein unvollständiger Sheets-Abgleich ausgeführt.")
            converted=[]
            for row in rows:
                values=[]
                for column,value in enumerate(row,1):
                    if value is None:value=''
                    if column in spec['text']:value=str(value)
                    if isinstance(value,str) and len(value)>2000:value=value[:1960]+' … [gekürzt]'
                    values.append(value)
                converted.append(values)
            tables[spec['key']]={'columns':spec['headers'],'rows':converted}
    canonical=json.dumps({'source':source,'tables':tables},ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
    digest=hashlib.sha256(canonical.encode()).hexdigest()
    payload={'type':'snapshot','version':2,'source':source,'revision':digest,'tables':tables}
    if len(json.dumps(payload,ensure_ascii=False,allow_nan=False).encode())>MAX_PAYLOAD:
        raise ValueError('Datenumfang für einen vollständigen Sheets-Abgleich zu groß. Es wird kein Teilstand übertragen.')
    return payload


class SheetSync:
    def __init__(self,bot):
        self.bot=bot;self.lock=asyncio.Lock();self.last_attempt=None;self.last_ok=None;self.last_error=None;self.last_revision=None;self.last_imports=0;self.last_rejected=0

    def enabled(self):return os.getenv('ENABLE_SHEETS','false').lower()=='true'

    def team(self):
        from utils.menu_ui import server_allowed
        from utils.perms import is_staff
        result=[]
        for guild in self.bot.guilds:
            if not server_allowed(self.bot,guild):continue
            for member in guild.members:
                if not member.bot and is_staff(member):
                    result.append([str(member.id),member.display_name,', '.join(r.name for r in member.roles if r.name!='@everyone')])
        return sorted(result,key=lambda row:row[0])

    async def sync(self,*,force=False):
        if not self.enabled():return {'ok':False,'error':'Sheets ist deaktiviert. Anleitung im Ordner sheets.'}
        async with self.lock:
            self.last_attempt=datetime.now(timezone.utc).isoformat()
            try:
                health=await sheets_post({'type':'status'})
                if not health.get('ok'):raise ValueError(health.get('error','Web-App-Test nicht bestätigt.'))
                if not isinstance(health.get('version'),int) or health.get('version',0)<3:raise ValueError('Apps Script veraltet. Neues Code.gs einfügen und die Web-App als neue Version bereitstellen.')
                if not health.get('configured'):raise ValueError('In Google zuerst USHERO_einrichten ausführen und Deployment aktualisieren.')
                team=self.team()
                payload=await build_snapshot(team)
                incoming=await sheets_post({'type':'changes','source':payload['source']})
                if not incoming.get('ok'):raise ValueError(incoming.get('error','Rückweg nicht bestätigt.'))
                changes=incoming.get('changes',[])
                if not isinstance(changes,list) or len(changes)>50 or any(not isinstance(c,dict) for c in changes):raise ValueError('Ungültige Änderungsliste von Sheets.')
                acknowledgements=[];self.last_imports=0;self.last_rejected=0
                for change in changes:
                    ack,event=await apply_sheet_change(payload['source'],change,{row[0] for row in team})
                    acknowledgements.append(ack)
                    if not ack.get('ok'):self.last_rejected+=1
                    if event:
                        self.last_imports+=1
                        from utils.logging_ch import send_audit
                        for guild in self.bot.guilds:
                            from utils.menu_ui import server_allowed
                            if server_allowed(self.bot,guild):
                                await send_audit(guild,event[1],preferred=('warehouse-log' if event[0]=='warehouse' else 'dienstplan-logs','audit-logs'))
                if acknowledgements:
                    acknowledged=await sheets_post({'type':'ack_changes','source':payload['source'],'acks':acknowledgements})
                    if not acknowledged.get('ok'):raise ValueError('Änderungen lokal geprüft; Rückbestätigung fehlgeschlagen. Es wird nichts doppelt gebucht.')
                    payload=await build_snapshot(team)
                payload['force']=force or bool(acknowledgements)
                result=await sheets_post(payload)
                if not result.get('ok'):raise ValueError(str(result.get('error','Sheets-Abgleich nicht bestätigt.'))[:300])
                if result.get('revision')!=payload['revision']:
                    raise ValueError('Sheets hat den neuen Datenstand nicht bestätigt. Apps Script auf Version 3 aktualisieren und neu bereitstellen.')
                self.last_ok=self.last_attempt;self.last_error=None;self.last_revision=payload['revision']
                return result
            except (ValueError,aiosqlite.Error) as error:
                self.last_error=str(error)[:300]
                return {'ok':False,'error':self.last_error}


def _integer(value,label,minimum=0,maximum=1000000):
    import re
    if isinstance(value,bool) or not re.fullmatch(r'\d+',str(value)):raise ValueError(label+' muss eine ganze Zahl sein.')
    result=int(value)
    if not minimum<=result<=maximum:raise ValueError(label+' außerhalb des erlaubten Bereichs.')
    return result


def _plan_fields(values,staff):
    import re
    from datetime import date,time
    if not isinstance(values,dict):raise ValueError('Dienstplandaten fehlen.')
    member=str(values.get('member_id',''))
    if not re.fullmatch(r'\d{1,19}',member) or int(member)>2**63-1:raise ValueError('Ungültige Mitarbeiter-ID.')
    if member not in staff:raise ValueError('Mitarbeiter-ID nicht im aktuellen Team. ID aus dem Team-Blatt verwenden.')
    day=str(values.get('day',''));date.fromisoformat(day)
    area=str(values.get('area',''))
    if area not in ('Verkauf','Warehouse','VIP','Tänzer','Security','Leitung','Allgemein'):raise ValueError('Unbekannter Dienstplanbereich.')
    start=str(values.get('start',''));end=str(values.get('end',''))
    for value in (start,end):
        if not re.fullmatch(r'\d{2}:\d{2}',value):raise ValueError('Uhrzeiten als HH:MM eingeben.')
        time.fromisoformat(value)
    note=str(values.get('note',''))
    if len(note)>900:raise ValueError('Notiz zu lang.')
    return {'member_id':member,'day':day,'area':area,'start':start,'end':end,'note':note}


def _existing_plan(row):
    return {'member_id':str(row[0]),'day':row[1],'area':row[2],'start':row[3],'end':row[4],'note':row[5] or ''}


async def apply_sheet_change(source,change,staff):
    import re
    ident=str(change.get('id',''));kind=str(change.get('type',''));data=change.get('data')
    if not re.fullmatch(r'[A-Za-z0-9-]{24,64}',ident):return {'id':ident[:64],'ok':False,'message':'Ungültige Änderungs-ID.'},None
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('CREATE TABLE IF NOT EXISTS sheet_changes(id TEXT PRIMARY KEY,source TEXT,result TEXT)')
        await db.execute('CREATE TABLE IF NOT EXISTS sheet_plan_refs(source TEXT,ref TEXT,plan_id INTEGER,PRIMARY KEY(source,ref))')
        await db.commit();await db.execute('BEGIN IMMEDIATE')
        previous=await (await db.execute('SELECT source,result FROM sheet_changes WHERE id=?',(ident,))).fetchone()
        if previous:
            return (json.loads(previous[1]) if previous[0]==source else {'id':ident,'ok':False,'message':'Andere Datenquelle.'}),None
        event=None
        try:
            if not isinstance(data,dict):raise ValueError('Änderungsdaten fehlen.')
            if kind=='stock_set':
                item=str(data.get('item',''));quantity=_integer(data.get('quantity'),'Bestand')
                expected=_integer(data.get('expected'),'Vorheriger Bestand')
                row=await (await db.execute('SELECT quantity FROM warehouse_stock WHERE item=?',(item,))).fetchone()
                if not row:raise ValueError('Artikel nicht im Lager gefunden.')
                if row[0]!=expected:raise ValueError('Konflikt: Bestand wurde inzwischen im Bot geändert. Neu abgleichen und Änderung erneut eingeben.')
                await db.execute('UPDATE warehouse_stock SET quantity=?,last_updated=? WHERE item=?',(quantity,datetime.now(timezone.utc).replace(tzinfo=None).isoformat(),item))
                message=f'Lagerbestand übernommen: {item} = {quantity}';event=('warehouse',message)
            elif kind in ('plan_put','plan_delete'):
                ref=str(data.get('plan_id',''));plan_id=None
                if ref.startswith('neu-') and re.fullmatch(r'neu-[A-Za-z0-9-]{24,64}',ref):
                    linked=await (await db.execute('SELECT plan_id FROM sheet_plan_refs WHERE source=? AND ref=?',(source,ref))).fetchone()
                    if linked:plan_id=linked[0]
                else:plan_id=_integer(ref,'Plan-ID',1,2**31-1)
                row=await (await db.execute('SELECT user_id,tag,bereich,von,bis,note FROM dienstplan WHERE id=?',(plan_id,))).fetchone() if plan_id else None
                expected=data.get('expected')
                if row and (not isinstance(expected,dict) or _existing_plan(row)!=expected):raise ValueError('Konflikt: Dieser Dienstplaneintrag wurde inzwischen geändert. Neu abgleichen und erneut bearbeiten.')
                if kind=='plan_delete':
                    if row:await db.execute('DELETE FROM dienstplan WHERE id=?',(plan_id,))
                    message='Dienstplaneintrag gelöscht.' if row else 'Dienstplaneintrag bereits nicht mehr vorhanden.'
                else:
                    fields=_plan_fields(data.get('fields'),staff)
                    if not row:
                        if not ref.startswith('neu-'):raise ValueError('Plan-ID nicht gefunden. Neue Zeile ohne eigene ID anlegen.')
                        cursor=await db.execute('INSERT INTO dienstplan(user_id,tag,bereich,von,bis,note,created_by,created_at) VALUES(?,?,?,?,?,?,0,?)',
                            (int(fields['member_id']),fields['day'],fields['area'],fields['start'],fields['end'],fields['note'],datetime.now(timezone.utc).replace(tzinfo=None).isoformat()))
                        plan_id=cursor.lastrowid
                        await db.execute('INSERT INTO sheet_plan_refs(source,ref,plan_id) VALUES(?,?,?)',(source,ref,plan_id))
                    else:
                        await db.execute('UPDATE dienstplan SET user_id=?,tag=?,bereich=?,von=?,bis=?,note=? WHERE id=?',
                            (int(fields['member_id']),fields['day'],fields['area'],fields['start'],fields['end'],fields['note'],plan_id))
                    message=f'Dienstplan #{plan_id} übernommen.'
                event=('dienstplan',message)
            else:raise ValueError('Aus Sheets sind nur Lagerbestand und Dienstplan erlaubt. Geldbuchungen bleiben im Bot.')
            await db.execute('INSERT INTO audit_logs(action,user_id,details,created_at) VALUES(?,0,?,?)',
                ('sheets_'+kind,ident+' · '+message,datetime.now(timezone.utc).replace(tzinfo=None).isoformat()))
            result={'id':ident,'ok':True,'message':message}
        except (ValueError,TypeError,KeyError) as error:
            # Validierung erfolgt vor dem jeweiligen Daten-Write; keine Teilbuchung bestaetigen.
            result={'id':ident,'ok':False,'message':str(error)[:300]};event=None
        await db.execute('INSERT INTO sheet_changes(id,source,result) VALUES(?,?,?)',(ident,source,json.dumps(result,ensure_ascii=False)))
        await db.commit()
        return result,event
