USHERO – REPARIERTE MENUE-VERSION

1. Alten Bot beenden (Strg+C), neuen ZIP-Ordner entpacken.
2. Bisherige .env neben bot.py in den neuen Ordner kopieren.
3. Die aktuellste eigene data/bot.db vom gestoppten alten Bot nach data/bot.db
   uebernehmen. Diese Download-Version enthaelt keine private Datenbank.
4. start.bat oeffnen. Python 3.12 empfohlen. Paketinstallation einmal mit j bestaetigen.
5. In Discord einmal /panel durch die Leitung ausfuehren. Der Bot verteilt die
   Bereichsmenues auf die passenden Kanaele. Danach dort Buttons verwenden.

Fenster offen lassen; Strg+C beendet den Bot.
pruefen.bat startet Offline-Tests mit Testdaten.
README.md und PRUEFBERICHT.md enthalten Details und Grenzen.
Die lokalen Dateien .env und data/bot.db enthalten private Daten und gehoeren nicht auf GitHub.

Kanalmenues werden gespeichert, angeheftet und bei Bedarf unten angezeigt.
Neue Nachrichten in registrierten Arbeitskanaelen werden nach ca. 10 Sekunden
entfernt. Datenbank und getrennte Protokolle bleiben erhalten.
Die Automatik laesst sich im Leitungsmenue fuer den aktuellen Kanal ausschalten.

Neu: Nur /menu und /panel bleiben als Discord-Befehle sichtbar.
Sheets: sheets/USHERO-Dashboard.xlsx und sheets/Code.gs, Einrichtung siehe
sheets/README.md. Danach Sheets-verbinden.bat starten. Keine Live-Verbindung
wurde automatisch in deinem Google-Konto eingerichtet.

Abteilungstrennung: Mitarbeiter allein hat keine Fachbereichsrechte mehr.
Verkauf/VIP/Warehouse/usw. nur mit passender Abteilungsrolle. /panel repariert
auch alte Kanal-Freigaben. Administratorrechte umgehen Discord-Kanalverbote.
Sheets V3: Rueckweg nur fuer Lagerbestand und Dienstplan, keine Geldbuchungen.
AKfy ist die Bereitstellungs-ID, kein geheimer Verbindungsschluessel.
